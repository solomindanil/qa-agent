# Lead AQA design/code feasibility review

Reviewer: graph_consumer_aqa_design, fresh context, 14 September. Existing source pins passed sources:verify. Read-only review concluded the bounded proof is feasible without runtime changes.

Existing seams: Console tests/fixtures/nuanu-readonly/fixture.ts registerAuthoredFixture131–291 and rehashCompilation295–326; Kernel workspace-blueprint buildRegistrationKnowledgeRevision405, workspace-regenerator preview645/apply1186; registration dialect product-graph163/220; Console readCampaignWorkspace392; inventory only prepareCampaignDraft583; closure642–747/exact resolved oracle780; runner183/245; actual reader campaign-receipts1606.

Same root-independent productSlug/name/brief/baseUrl permits exact equality of graph/catalog/profile at B. Preserve initial and revised authority and managed public artifacts. Post edge publication only edge+graphdigest, graph-binding/catalogdigest, coverage freshness/digest, strategy bindings/digest and compilation/publication cascades may change. No arbitrary normalization to make differences disappear. Review generated managed artifacts separately.

Catalog carries identities/routes/oracle contracts, not executable operations; consumers must author supported V0 actions/assertions. V0 plan has graphDigest but no catalogDigest; draft/receipt binds catalog. Compare expectedBehavior/targets/operations separately to identify actor-authorship confounds. Omitted C must remain named in I's campaign blocker, without pretending automated coverage disappeared.

Fresh actors get same request/authority and no condition or expected-check answer key. If control independently chooses C, retain the useful exploration and report no observed selection divergence. Do not coach or resample until preferred outcome. A healthy target proves only execution/selection; same independently specified seeded fault with D insensitive and C sensitive can additionally demonstrate regression detection. Preserve every original first answer/plan/attempt and all corrections.

One relation comparison is not automatic risk-selection, full product QA or Stage4 completion. Instruction-scoped freshness is not a security-enforced blind benchmark.
