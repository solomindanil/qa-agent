import { writeFile } from 'node:fs/promises';
import { createInterface } from 'node:readline';
import { fileURLToPath } from 'node:url';
import { startGraphConsumerExercise } from './root/evals/graph-consumer-agent-cycle/prepare.mts';

// Owned eval caller, not a new runtime/publication policy. Parent reviews the
// exact proposal written below before acknowledging the two digests on stdin.
const proposalFile = fileURLToPath(new URL('./actual-proposal.json', import.meta.url));
const input = createInterface({ input: process.stdin, terminal: false });
const lines = input[Symbol.asyncIterator]();
const exercise = await startGraphConsumerExercise({
  beforeRelationApply: async (proposal) => {
    await writeFile(proposalFile, JSON.stringify(proposal, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
    const expected = `approve ${proposal.candidate.semanticDigest} ${proposal.preview.previewDigest}`;
    console.log(JSON.stringify({ status: 'awaiting_controller_review', proposalFile, expected }));
    const reply = await lines.next();
    if (reply.done || reply.value !== expected) throw new Error('Exact controller approval not supplied');
    return {
      approved: true, kind: 'controller-agent-review',
      candidateDigest: proposal.candidate.semanticDigest,
      previewDigest: proposal.preview.previewDigest,
      reviewedAt: new Date().toISOString(),
      basis: 'Read exact candidate, source-backed relation, preserved common base and pre-apply delta; independently source-reviewed owned eval.',
      limitation: 'Agent-authored task approval, not a cryptographic human attestation or a product verdict.',
    };
  },
});
input.close();
let stopping = false;
const stop = async () => {
  if (stopping) return;
  stopping = true;
  await exercise.close();
  console.log(JSON.stringify({ status: 'stopped', journalPath: exercise.journalPath }));
};
process.once('SIGINT', () => void stop().catch(error => { console.error(error); process.exitCode = 1; }));
process.once('SIGTERM', () => void stop().catch(error => { console.error(error); process.exitCode = 1; }));
console.log(JSON.stringify({ status: 'ready', pid: process.pid, exerciseRoot: exercise.exerciseRoot, baseUrl: exercise.baseUrl, packetPaths: exercise.actors.map(actor => actor.packetPath) }));
