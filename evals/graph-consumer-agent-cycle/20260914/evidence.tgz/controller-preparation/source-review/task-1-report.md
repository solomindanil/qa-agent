# Task 1 report — controlled graph comparison preparation

## Result

Implemented the eval-only Stage Four graph-consumer fixture and preparation. It
uses one deterministic loopback GET server and two independent
`registerAuthoredFixture` roots with the same slug, registration brief, and
base URL. Both workspaces are published to an exactly equal common base B. B
contains journey J, invariant I, resolved D→J and C→I checks, and retains the
initial surface/discovery blockers and coverage targets. No campaign plan is
written.

Only actor 2 receives the reviewed J `requires` I relation. Preparation uses the
exact Kernel `buildRegistrationKnowledgeRevision`,
`previewRegistrationPublication`, `applyRegistrationPublication`, and
`validateWorkspace` APIs. The relation-only semantic delta is checked before
apply; a caller may inspect the exact candidate, preview, relation, and delta in
`beforeRelationApply`. The persisted pre-apply decision states whether that hook
was supplied and does not claim an independent review when it was not.

## Owned files

- `evals/graph-consumer-agent-cycle/fixture.mjs`
- `evals/graph-consumer-agent-cycle/fixture.test.mjs`
- `evals/graph-consumer-agent-cycle/prepare.mts`
- `evals/graph-consumer-agent-cycle/prepare.test.mts`
- `evals/graph-consumer-agent-cycle/product-brief.md`
- `evals/graph-consumer-agent-cycle/evidence/fixture-red.tap`
- `evals/graph-consumer-agent-cycle/evidence/fixture-green.tap`
- `evals/graph-consumer-agent-cycle/evidence/preparation-red.tap`
- `evals/graph-consumer-agent-cycle/evidence/preparation-green.tap`
- `.superpowers/sdd/execution-plan/task-1-report.md`

No component/runtime, manifest, package, installed-skill, product environment,
registration outside the owned temporary roots, or tracker file was changed.

## TDD evidence

Fixture RED command (exit 1, 0/2 pass; both real assertions reported the missing
fixture function):

```sh
node --test evals/graph-consumer-agent-cycle/fixture.test.mjs
```

Raw output: `evals/graph-consumer-agent-cycle/evidence/fixture-red.tap`.

Fixture GREEN command (exit 0, 2/2 pass):

```sh
node --test evals/graph-consumer-agent-cycle/fixture.test.mjs
```

Raw output: `evals/graph-consumer-agent-cycle/evidence/fixture-green.tap`.

Preparation RED command (exit 1, 0/1 pass; real assertion reported the missing
preparation function):

```sh
node --import ./components/console/node_modules/tsx/dist/loader.mjs --test evals/graph-consumer-agent-cycle/prepare.test.mts
```

Raw output: `evals/graph-consumer-agent-cycle/evidence/preparation-red.tap`.

Preparation GREEN command (exit 0, 1/1 pass in 75.596 seconds):

```sh
QA_STARTER_REPO="$PWD/components/kernel" node --import ./components/console/node_modules/tsx/dist/loader.mjs --test evals/graph-consumer-agent-cycle/prepare.test.mts
```

Raw output: `evals/graph-consumer-agent-cycle/evidence/preparation-green.tap`.

Two intermediate integration runs reached the same over-strict preparation
guard: the first retained the causal error only as `Error.cause`; diagnostic
wording in the second exposed it directly. The initial generated registration
has no journey-bound catalog entry, a state the existing Console helper supports.
Removing only the false nonempty requirement allowed the owned D/C catalog to be
composed; no runtime contract or architecture changed. The failed trees are
`/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-graph-consumer-uVwn7G`
and `/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-graph-consumer-tNLXyR`;
both stop after the first initial-authority snapshot and retain no applied common
or relation publication.

## Actual publication and equality evidence

The GREEN integration run retained its closed qualification tree at
`/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-graph-consumer-Vee7Zt`.
Its `controller/preparation.json` reports:

- identical initial authority digest:
  `sha256:ead0fda9acd72d07553c3193c43293e9b4bbde230c126031ccbf7b731b18b2d5`;
- identical common B authority digest:
  `sha256:36ba789ddca8e232d59ac5d2efca2b90844e4fe33e33d762be96e3c9ee848034`;
- relation candidate authority digest:
  `sha256:458d924c0761fa08590a1ab278eab3799246c445c4671ce22edeb8e610aaa0c7`;
- actual preview digest:
  `sha256:dc2adf287bcb9c0bb989fa7713d935da3aca1ecdb0cfdfc583b21cce2c70fc75`;
- applied/read-back workspace digest:
  `sha256:25256e1cd353eacad703e4656220ad4c2c9bdb979a8781796e089d438afb58fc`;
- validator `valid:true` and publication authority digest equal to the candidate.

Equality is not inferred from matching IDs alone. Preparation compares both full
initial authorities and both full common-B authorities with Kernel canonical
JSON. The pre-apply delta checker then proves exact registration context and
profile equality; exact graph nodes/unresolved and retained edges; exactly one
added reviewed J→I `requires` edge; unchanged coverage denominator/content except
every required `freshness.graphDigest`; unchanged catalog entries/identity; and
unchanged strategy content. It separately verifies the graph→coverage/catalog→
strategy→compilation digest cascade and binding consistency. Both workspaces are
validated after common publication, and the changed workspace is validated again
after relation publication against the actual apply receipt.

The controller evidence directory preserves initial authorities, both common
candidates/previews/apply receipts/readbacks, common comparison, proposed
relation, relation candidate, pre-apply delta, exact preview, caller decision,
apply receipt, final readback, and post-apply delta copy. The request journal
contains the two real GETs made by the integration test and survives server stop.

## Actor packet readiness

Each actor gets only its own root/store/workspace, the same source/runtime paths,
same base URL, copied brief, requested journey name, and standard managed graph
and catalog paths. Packets contain no condition label, relation hint, expected
selection, catalog duplicate, answer key, or campaign plan. The product brief asks
both actors to reuse existing managed checks/oracles for the named journey,
independently author supported V0 operations/assertions, and retain every omitted
or unresolved target as a blocker. The exact D/C normative text is also in the
original registration brief bytes used by inherited provenance.

The GREEN integration packets belong to a closed qualification server. The parent
must start the final actor exercise, use `beforeRelationApply` to inspect/approve
the exact candidate and preview, and keep that server alive through both consumer
runs. Preparation prints packet paths only when invoked as the long-lived driver.

## Limitations

- This is preparation and harness qualification, not the requested fresh-agent
  consumer run, automatic risk selection, Stage Four acceptance, or product QA.
- One graph relation and one literal seeded defect cannot establish general graph
  consumption. If the control independently selects C, preserve that useful
  exploration; do not resample or coach a preferred divergence.
- D is insensitive to the seeded defect. C is sensitive to the unchanged literal
  `{invariantSatisfied:false, unlabeledItemCount:1}` response against the exact
  resolved true/zero oracle. A later agent diagnosis is still required before a
  product-issue claim.
- Actor isolation is instruction-scoped, not a security boundary. Temporary
  artifacts are intentionally retained; server stop does not delete them.
- No external network, browser, credentials, mutation, purchase, database,
  tracker action, or authored campaign plan was exercised by this task.
