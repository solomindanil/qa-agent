# Task 1 independent Lead AQA source/spec review

Decision: **APPROVED for the bounded preparation source and proceeding to the separately controlled fresh-consumer exercise.** Critical 0 / Important 0 / Minor 0 source findings. This is not consumer acceptance, causal-selection evidence, Stage Four completion, product acceptance, or permission to change runtime pins.

Reviewed root base `f33636ccd15efa69bb2be6dd72441d0d00f0ebe0`; the five new fixture/preparation/brief files, task-1 brief and report, raw retained RED/GREEN logs, actual retained publication artifacts, and the relevant existing Console/Kernel implementation. The parent qualification draft was expressly treated as pending. No source, branch or index was changed by this review.

## Source/spec findings

- `prepare.mts:283-324` uses separate owned registration roots/stores with one actual loopback URL and identical product facts. Full initial authority and full common-B authority equality are checked using Kernel canonical JSON, not merely equal target IDs. `prepare.test.mts:44-51` independently asserts these equalities.
- `prepare.mts:41-165` retains the initial journey and unrelated coverage/discovery state while composing the common invariant, two resolved catalog checks and their reviewed verification edges. Both conditions retain I, C, identical normative oracles, graph kinds/subkinds and declared provenance. The registration source bytes include both normative contracts (`prepare.mts:18-29` and existing Console fixture `fixture.ts:172-185`), so inherited provenance is grounded in the brief rather than the defective observation. Source provenance appropriately remains declared/unreviewed input; the reviewed relation is not represented as observed product evidence.
- `prepare.mts:190-254` checks the one-edge delta, retained edges/nodes/unresolved content, coverage denominator, catalog and strategy content, plus required digest cascades and cross-model bindings. Actual Kernel candidate validation, preview, apply and managed readback occur at `prepare.mts:298-308` and `338-376`. The existing Kernel apply recomputes the preview and rejects a stale digest; the validator reads actual workspace state. These are not handwritten PASS receipts.
- `fixture.mjs:3-15,24-45` provides a healthy direct response and the same literal seeded label defect in both conditions. The normative expected true/zero values are separately present in the product brief at lines 18-22. This establishes fixture/oracle contrast, not yet an actor-authored runner result or confirmed live-product defect.
- `prepare.mts:379-399` and `product-brief.md:8-14,26-31` provide identical task material, no executable campaign plan, no condition field, expected selection or answer key, and an instruction to retain omissions/unresolved targets. Actor roots and shared source paths are not a security sandbox. Parent must enforce the already stated prohibition on reading fixture/controller/sibling evidence and preserve original reasoning and plans before evaluating outcomes.
- The exact-candidate review hook at `prepare.mts:344-357` permits the parent to inspect candidate/preview before actual apply. Its default synthetic preparation decision explicitly disclaims independent review; this review does not count that default or the test callback as an independent review of the later exercise candidate. Parent's separately controlled callback approval remains required for the actual exercise.

## Verification actually performed by reviewer

1. `npm run sources:verify`: all four components verified at the frozen manifest pins, including Console `66ac7db55a25f56b199b2cb00ad83df3b8dad868` and Kernel `185d3e72309a4362db57cf2e805d1c00a5035909`. Subsequent child status checks were clean; root HEAD remained the stated base.
2. `node --test evals/graph-consumer-agent-cycle/fixture.test.mjs`: 2/2 pass, 0 failed/skipped, 108.159417 ms.
3. `QA_STARTER_REPO=/Users/danilsolomin/projectsnew/qa-agent/.local/graph-consumer-20260914.EufPy9/root/components/kernel node --import ./components/console/node_modules/tsx/dist/loader.mjs --test evals/graph-consumer-agent-cycle/prepare.test.mts`: 1/1 pass, 0 failed/skipped, exit 0, 84272.974417 ms. This ran the actual registration/publication/readback path and two loopback GETs, then stopped its server; no product/default child suite ran.

Reviewer repeat artifacts remain at `/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-graph-consumer-fl25XZ`. Its final actual readback reports `valid: true`, no diagnostics, publication authority `sha256:6d771e540c6d2fee12805f05e42ec30eadcbb94871c46c076d7e390624c1ee4a`, and workspace digest `sha256:5d545aa0c8a4687e480c71ba4cc8a8fb9885959939c06b91a390152b7fcb5d22`. These differ from the original run because the loopback port differs between exercises, not within either paired comparison.

Original implementer `Vee7Zt` artifacts and the four raw TAP logs were read directly. They support 2/2 fixture GREEN and 1/1 actual preparation GREEN at 75596.469542 ms, including the reported candidate/receipt/readback digests. RED logs contain real missing-export assertions (fixture 0/2, preparation 0/1), not a reproduced behavioral regression; no stronger TDD/regression claim is approved. The retained intermediate failed preparation roots are not success evidence. After review questioned the two retained failed roots, the implementer corrected the report to two attempts of the same over-strict guard: diagnostic wording changed between attempts, then the guard was corrected. Both retained trees contain only the actor-1 initial-authority controller snapshot; neither is common/relation publication evidence.

## Limits retained for the parent

- The server API/CLI has no autonomous wall-clock shutdown; finite execution, callback waiting and final close are controller-owned. Signal handlers in the CLI are installed only after preparation (`prepare.mts:439-456`). Do not treat this local fixture as unattended fault-tolerant infrastructure or promise durable journaling after a force-kill. This is a scoped operational limit, not a requested runtime-policy expansion.
- Graph/catalog equality and test pass counts do not establish that a fresh actor actually selects or executes C. If control selects C from the same product contract, preserve that result; do not coach or resample for divergence.
- No campaign was authored by this reviewer, no actor run was performed, and no default product suite, tracker, browser, payment, account, database or external network action was taken.

## Reviewed source SHA-256

| File under `evals/graph-consumer-agent-cycle/` | SHA-256 |
| --- | --- |
| `fixture.mjs` | `40d655559c41d0a6c8cf02b658773d1fbd082e82cf406ef05d95c1f288fdce02` |
| `fixture.test.mjs` | `cecceee70a606abbf58068427d2ffdcaeae3427a1133a5874fdd37544d9cca85` |
| `prepare.mts` | `a46062f3a9edc9091387260c31c014da34c60393cd06da7949b456383e98d6d2` |
| `prepare.test.mts` | `e7f47185d9d971d8431cf057c1c7e93e1f79a9b5fde41d09a5fb27772dee02db` |
| `product-brief.md` | `d174b9f4e02d9c3cebaafe65cbe2c6b2ad3eea2eec3b7f2f8b5be577ece09205` |
