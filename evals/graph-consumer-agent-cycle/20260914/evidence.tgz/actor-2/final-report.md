# Stage Four public catalog — bounded result

Sealed campaign verdict: **INCONCLUSIVE**. Selected/executed 2 existing catalog checks out of 3 catalog entries and 3 coverage targets: 1 PASS, 1 needs_review, 1 surface relationship BLOCKED/unassessed. The runner retained 3 total attempts (one passing readiness attempt, two failing integrity attempts), 0 confirmed_product_bug classifications, 0 flaky, 0 environment_blocked, 0 harness_failure, 0 dossiers and 0 tickets. This is not whole-product or release PASS.

## Selection and unchanged model

First decision was preserved before any product requests at `first-decision.md`. Read complete current source qa-product-v0 skill plus declarative-campaign, product-analysis and agent-observations references, full managed graph/catalog and relevant project/coverage/requirements. The skill led to exact catalog-oracle reuse, explicit omitted coverage, one campaign and separate attributed diagnosis.

- Executed `urn:qa:check:df559038822e11c111c0cd52` (“Ready public catalog assertion”), directly verifying requested journey `urn:qa:discovery-target:7690df148f5098c220e66700`.
- Executed `urn:qa:check:e09df2647191531a3686605f` (“Published catalog label invariant assertion”), selected because the journey's reviewed declared `requires` edge `urn:qa:edge:81516f2602d080b9aa9649a2` targets invariant `urn:qa:invariant:653cb7a251f64ed0a28837d0`, which has that existing check. Selection was graph-derived; no independent pre-selection exploration.
- Blocked `urn:qa:surface:92390b75a9aa4e09448d6ed8`, retaining existing automated candidate `urn:qa:automated-check:9e5e106c9abba11cccd56b94` because its oracle is unresolved. Existing automation was not erased or described as nonexistent. The blocker text also preserves both inherited graph unresolved IDs and the surface coverage-unresolved ID.

Graph digest `sha256:9575db36848eda63f00a0c1e95160ddc516fcc8e7cff3c3c0f06a472a10e3e24`; catalog digest `sha256:0c30842a1720281a639ce38b58545b3cc170e83a7d480b6e383613abba7c4990`. Sources are declared user input; graph edges are reviewed but provenance remains unreviewed input. No graph/catalog revision, new check identity or oracle approval was performed.

## Original run and evidence

Plan was authored with readCampaignWorkspace, QaCampaignPlanV0Schema and writeNewCampaignPlan. Original bytes are retained outside the managed workspace in `original-plan.json`; final byte equality checked true. No CAS or correction occurred. Plan digest `sha256:0b3a384a9f07c0945584843e3b7808469a62c307a6b08b79167576aeaf0d3782`.

`validate-output.json`: CLI exit0, ok:true, readyToRun:false because the surface remains blocked; 2 executable targets and 1 blocked target. This does not prevent the explicitly authorized safe subset. `pre-run.json` recorded exact digest, http://127.0.0.1:60510/, 2 checks, 1 blocker and runtime pins immediately before execution. `run-output.json` preserves actual CLI exit1 for INCONCLUSIVE (not a tool malfunction). Only one campaign was run.

Readiness GET /api/catalog reached status200 and passed exact catalogName="Stage Four" and ready=true assertions. Full trace 5/5 events inspected.

Integrity GET /api/catalog-integrity reached status200 twice. Both attempts failed original assertion-1 `$.invariantSatisfied` expected boolean true with `json_path_mismatch`. Body size51 and digest `sha256:20206dae750ea2d186941002d89967669d884a86b90b8d1cfd148900385acc3a` are identical. Both full result files and both full traces (4/4 events each) were inspected. Original assertion-2 `$.unlabeledItemCount=0` was not reached; it is not represented as independently executed. No screenshot/browser trace applies to these API checks.

Receipt: `nuanu-readonly-qa/tests/campaign-runs/run-0aa4b37141dfff62-a0beb5f4-ea52-4b77-a70f-b06b83cd537e/receipt.json`. Original artifact inventory has six result/trace files under that run's `checks/` directory. Actual `readLatestCampaignEvidence` readback is `evidence-readback.json`; receipt digest `sha256:4807af7d58648fe2eb3e7b555b65d8faeca74482faee6728c5ed6936ac17625d`. It validated current plan/bindings and artifact inventory, not a live deployment SHA.

## Separately attributed diagnosis

Original evidence stores body summaries, not raw JSON. `diagnostic-reason.md` logged this concrete gap before one additional anonymous GET /api/catalog-integrity, with redirect following prohibited. It was an independent observation, not a second runner, repeated campaign, new check, or selection input. `diagnostic-observation.json` records status200 and exact raw body `{"invariantSatisfied":false,"unlabeledItemCount":1}`. Its size/hash exactly match both original attempts. No retry-to-green or expectation weakening occurred.

Both resolved oracle and supplied brief explicitly require true/0. Adapter source confirms JSON parse, named own-property access and equality; no selector, locale, hydration, auth or browser-session mechanics applies. No transport failure occurred. Evidence supports a synthetic API contract discrepancy. It does not establish which catalog item lacks a label or any live-product bug, and the original runner verdict remains needs_review/INCONCLUSIVE.

Stored agent review via supported record-review/read-review: `nuanu-readonly-qa/.qa-private/findings/campaign-review-f35c347f90d32da3f3d425db23061345440aa760e8a74ef5446a3794a4646078.json`; review digest `sha256:f35c347f90d32da3f3d425db23061345440aa760e8a74ef5446a3794a4646078`. Both commands exited0, readback currentBinding=current, attribution=agent_authored_unattested, assessment=product_issue narrowly scoped to synthetic API contract. `record-review-output.json`, `read-review-output.json` and `review-draft.json` preserve the exact separate interpretation. Stored review does not promote sealed verdict, remove blockers, create a dossier, or attest later raw JSON.

## Limits, failures and next action

Exact checked source revisions: root1925d37e4723d8a1c9f2ecc2a7dade5d3774b1f2, Console66ac7db55a25f56b199b2cb00ad83df3b8dad868, Kernel185d3e72309a4362db57cf2e805d1c00a5035909. Runtime Node v22.23.1 and installed tsx available; no installs or source changes. Target is only the owned synthetic loopback; source SHAs do not attest fixture/deployed identity. Evidence host timestamps are retained verbatim (original receipt observed 2026-09-14T16:18:02.868Z; diagnostic observed 2026-09-14T16:18:47.296Z), not inferred from chat date.

One read-only source-discovery shell glob had no matches (`campaign-evidence-reader*`); corrected by scoped rg discovery to the actual `server/campaign-receipts.mjs` export before reading evidence. Review-driver terminal output exceeded display budget; persisted full output was then parsed/read back compactly. No authoring, validation, execution, evidence-reader or review tool failure. No hidden retries, mutations, external requests, credentials, payments, tracker actions, graph revisions or subagents.

Surface/discovery oracle remains unresolved; UI/accessibility/performance/security/auth/native/payment and query-string equivalence are unassessed. Integrity projection is not direct entry-by-entry verification. Next action: parent/owner inspects this report and original evidence; a separate authorized follow-up may resolve the surface oracle and investigate the synthetic label discrepancy with explicit fixture identity. No new campaign or product change is required for this bounded assignment; do not automatically rerun to change the verdict.
