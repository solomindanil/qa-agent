import { readFile, copyFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const actor = '/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-graph-consumer-EGSI1n/actor-2';
const context = JSON.parse(await readFile(path.join(actor, 'actor-context.json'), 'utf8'));
const files = await import(pathToFileURL(path.join(context.consolePath, 'src/node/qa-campaign-files.ts')).href);
const schema = await import(pathToFileURL(path.join(context.consolePath, 'src/lib/qa-campaign-v0.ts')).href);
const digest = await import(pathToFileURL(path.join(context.consolePath, 'src/lib/canonical-digest.ts')).href);
const workspace = await files.readCampaignWorkspace(context.workspacePath);
const selected = ['urn:qa:check:df559038822e11c111c0cd52', 'urn:qa:check:e09df2647191531a3686605f'];
const checks = selected.map((checkId, index) => {
  const entry = workspace.catalog.entries.find((entry: any) => entry.checkId === checkId);
  if (!entry || entry.oracle.state !== 'resolved') throw new Error('Current resolved catalog check is required');
  const endpoint = index === 0 ? '/api/catalog' : '/api/catalog-integrity';
  return {
    checkId, title: workspace.graph.nodes.find((node: any) => node.id === checkId).name,
    targetIds: entry.targetIds, disposition: 'executable', sideEffectClass: 'read_only',
    preconditions: ['Owned anonymous synthetic loopback origin; no credentials or product mutations.'],
    reproductionSteps: [`GET ${endpoint} on the registered origin.`, 'Compare status and parsed JSON values with the exact resolved catalog oracle.'],
    expectedBehavior: entry.oracle.description, severity: 'medium',
    severityJustification: 'Incorrect readiness or missing published labels obstructs reliable anonymous catalog reading.',
    kind: 'api', surface: 'api', method: 'GET', path: endpoint,
    assertions: index === 0 ? [
      {kind: 'status', value: 200}, {kind: 'json_path', path: '$.catalogName', value: 'Stage Four'}, {kind: 'json_path', path: '$.ready', value: true},
    ] : [
      {kind: 'status', value: 200}, {kind: 'json_path', path: '$.invariantSatisfied', value: true}, {kind: 'json_path', path: '$.unlabeledItemCount', value: 0},
    ],
  };
});
const plan = schema.QaCampaignPlanV0Schema.parse({
  schemaVersion: 'qa-campaign.v0', productSlug: context.productSlug, graphDigest: workspace.graph.semanticDigest,
  baseUrl: context.baseUrl, checks, blockers: [{
    targetId: 'urn:qa:surface:92390b75a9aa4e09448d6ed8',
    catalogCheckIds: ['urn:qa:automated-check:9e5e106c9abba11cccd56b94'], disposition: 'blocked',
    reason: 'Existing automated surface candidate is unassessed because its oracle is unresolved. Retain inherited discovery gaps urn:qa:graph-unresolved:985eaa19ea536fc4b3316ea0 (no honest generated runnable check), urn:qa:graph-unresolved:23f8b8f2b20938ffb1a19d23 (generated candidate lacks approved oracle), and urn:qa:coverage-unresolved:8825d1042a9ed8efe0458825. These do not negate the two existing resolved automated checks.',
    recovery: 'Separately resolve the surface candidate expected outcome and review current discovery coverage through the authorized product knowledge/oracle path; no approval or graph revision in this campaign.',
  }],
});
const planPath = path.join(context.workspacePath, 'tests/qa-campaign.v0.json');
await files.writeNewCampaignPlan(context.workspacePath, planPath, plan);
await copyFile(planPath, path.join(actor, 'original-plan.json'));
const readback = schema.QaCampaignPlanV0Schema.parse(await files.readCampaignPlan(context.workspacePath, planPath));
if (digest.digestCanonical(readback) !== digest.digestCanonical(plan)) throw new Error('Plan readback differs');
const output = {planPath, planDigest: digest.digestCanonical(readback), baseUrl: readback.baseUrl, executableCount: readback.checks.length, blockerCount: readback.blockers.length};
await writeFile(path.join(actor, 'authored-plan-readback.json'), JSON.stringify(output, null, 2), {flag: 'wx'});
console.log(JSON.stringify(output, null, 2));
