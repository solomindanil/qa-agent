# Current checkpoint — actor-2

Owned root: /private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-graph-consumer-EGSI1n/actor-2

Bounded campaign finished; no campaign is paused/running. Report: `final-report.md`. Only origin http://127.0.0.1:60510/ was accessed. No further execution or mutations planned.

Selected and executed IDs: `urn:qa:check:df559038822e11c111c0cd52` PASS (1 attempt); `urn:qa:check:e09df2647191531a3686605f` needs_review (2 oracle_failure attempts). 3 catalog entries / 3 coverage targets total, 2 executed, 1 blocked/unassessed existing automated surface candidate `urn:qa:automated-check:9e5e106c9abba11cccd56b94` on surface `urn:qa:surface:92390b75a9aa4e09448d6ed8`. 0 confirmed bug dossiers/tickets. Sealed verdict INCONCLUSIVE, not whole-product PASS.

Graph-derived selection preserved in `first-decision.md` before requests. Two resolved existing checks selected via journey verifies and journey requires invariant edges. No graph revisions. `original-plan.json` remains byte-identical to `nuanu-readonly-qa/tests/qa-campaign.v0.json`. Plan digest sha256:0b3a384a9f07c0945584843e3b7808469a62c307a6b08b79167576aeaf0d3782. Validation, exact pre-run record and CLI result are `validate-output.json`, `pre-run.json`, `run-output.json`.

Receipt: `nuanu-readonly-qa/tests/campaign-runs/run-0aa4b37141dfff62-a0beb5f4-ea52-4b77-a70f-b06b83cd537e/receipt.json`; actual reader output `evidence-readback.json`; receipt digest sha256:4807af7d58648fe2eb3e7b555b65d8faeca74482faee6728c5ed6936ac17625d. Six original artifacts preserved and inspected, both non-pass traces complete 4/4 events. Integrity assertion-2 was not reached.

Original-versus-final: one original campaign only, unchanged oracles/plan/receipt. The receipt records body hash/size, not raw JSON. A separately logged one-GET diagnosis (`diagnostic-reason.md`, `diagnostic-observation.json`) returned false/1 with exact body hash matching both failures, supporting synthetic API discrepancy. It is agent-authored unattested supplemental evidence, not a new sealed verdict.

Review record/readback succeeded, currentBinding=current (local evidence only), assessment product_issue, attribution agent_authored_unattested. Review digest sha256:f35c347f90d32da3f3d425db23061345440aa760e8a74ef5446a3794a4646078. Path `nuanu-readonly-qa/.qa-private/findings/campaign-review-f35c347f90d32da3f3d425db23061345440aa760e8a74ef5446a3794a4646078.json`; saved outputs `record-review-output.json`, `read-review-output.json`.

Tool corrections: one source-discovery unmatched glob corrected with rg; display-truncated review output was read from full saved output. Actual run CLI exit1 represents INCONCLUSIVE, not harness failure. No retry or assertion correction.

Identity limitations: exact source root1925d37 / Console66ac7db / Kernel185d3e7 checked; fixture/deployed build identity not independently attested. Target remains owned synthetic anonymous loopback. Source declared/user-supplied contract agrees with resolved catalog; no external release claim. Surface/discovery oracle, per-item label confirmation, UI/accessibility/performance/security/auth/native/payment and query-string equivalence remain unassessed.

Next action: parent/owner inspect report and immutable evidence. Separate scoped authority/context is needed to resolve surface oracle or investigate fixture identity/source; do not automatically rerun or mutate product/graph/tracker. No human capability gap blocked the selected read-only checks.
