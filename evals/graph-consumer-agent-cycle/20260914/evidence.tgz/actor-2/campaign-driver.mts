import { readFile, writeFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const actor = '/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-graph-consumer-EGSI1n/actor-2';
const ctx = JSON.parse(await readFile(path.join(actor, 'actor-context.json'), 'utf8'));
const mode = process.argv[2];
const planPath = path.join(ctx.workspacePath, 'tests/qa-campaign.v0.json');
const files = await import(pathToFileURL(path.join(ctx.consolePath, 'src/node/qa-campaign-files.ts')).href);
const { digestCanonical } = await import(pathToFileURL(path.join(ctx.consolePath, 'src/lib/canonical-digest.ts')).href);
if (mode === 'validate' || mode === 'run') {
  if (mode === 'run') {
    const plan = await files.readCampaignPlan(ctx.workspacePath, planPath);
    if (!(await readFile(planPath)).equals(await readFile(path.join(actor, 'original-plan.json')))) throw new Error('Original plan changed');
    const preRun = {at: new Date().toISOString(), planDigest: digestCanonical(plan), baseUrl: plan.baseUrl, executableCount: plan.checks.length, blockerCount: plan.blockers.length, authorization: 'Current actor protocol bounded anonymous GET campaign on owned exact loopback origin', consoleRevision: '66ac7db55a25f56b199b2cb00ad83df3b8dad868', kernelRevision: '185d3e72309a4362db57cf2e805d1c00a5035909'};
    await writeFile(path.join(actor, 'pre-run.json'), JSON.stringify(preRun, null, 2), {flag: 'wx'});
    console.log(JSON.stringify(preRun));
  }
  const result = spawnSync('npm', ['run', 'qa-campaign', '--', mode, '--workspace', ctx.workspacePath, '--plan', planPath, '--approval-store', ctx.storeRoot], {
    cwd: ctx.consolePath, encoding: 'utf8', maxBuffer: 16 * 1024 * 1024,
    env: {...process.env, QA_STARTER_REPO: ctx.kernelPath, QA_STARTER_EXPECTED_SHA: '185d3e72309a4362db57cf2e805d1c00a5035909'},
  });
  const output = {command: mode, exitCode: result.status, stdout: result.stdout, stderr: result.stderr, error: result.error?.message};
  await writeFile(path.join(actor, `${mode}-output.json`), JSON.stringify(output, null, 2), {flag: 'wx'});
  console.log(JSON.stringify(output, null, 2));
} else if (mode === 'read') {
  const workspace = await files.readCampaignWorkspace(ctx.workspacePath);
  const reader = await import(pathToFileURL(path.join(ctx.consolePath, 'server/campaign-receipts.mjs')).href);
  const evidence = await reader.readLatestCampaignEvidence({workspaceDir: ctx.workspacePath, workspaceRoots: [ctx.workspacePath], productSlug: ctx.productSlug, graph: workspace.graph, catalog: workspace.catalog, project: workspace.project, allowedBaseUrls: [ctx.baseUrl], oracleApprovalStoreRoot: ctx.storeRoot});
  await writeFile(path.join(actor, 'evidence-readback.json'), JSON.stringify(evidence, null, 2), {flag: 'wx'});
  console.log(JSON.stringify(evidence, null, 2));
} else throw new Error('Expected validate, run, or read');
