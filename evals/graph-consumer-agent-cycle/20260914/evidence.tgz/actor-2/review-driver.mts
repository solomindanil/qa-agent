import { readFile, writeFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
const actor = '/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-graph-consumer-EGSI1n/actor-2';
const ctx = JSON.parse(await readFile(path.join(actor, 'actor-context.json'), 'utf8'));
const evidence = JSON.parse(await readFile(path.join(actor, 'evidence-readback.json'), 'utf8'));
const check = evidence.plan.checks.find((c: any) => c.checkId === 'urn:qa:check:e09df2647191531a3686605f');
const draft = {
  expectedReceiptDigest: evidence.receiptDigest, checkId: check.checkId, attempt: 1, expectedBehavior: check.expectedBehavior,
  artifacts: evidence.receipt.artifacts.filter((a: any) => a.path.includes('check-2b4149d881fdb392d1875656148217d8dafd49e942b2ed4a03d99e6d0cc6ac92/attempt-1/')),
  author: {agent: 'Codex actor-2 fresh registered-product consumer', host: 'codex', authoredAt: new Date().toISOString()},
  assessment: {
    kind: 'product_issue', scope: 'Owned synthetic loopback /api/catalog-integrity contract at original campaign capture; no live-product or release claim.',
    actual: 'Both original attempts reached status200 and failed assertion-1 $.invariantSatisfied=true with identical 51-byte body digest sha256:20206dae750ea2d186941002d89967669d884a86b90b8d1cfd148900385acc3a. One separately logged diagnostic GET returned {"invariantSatisfied":false,"unlabeledItemCount":1} with the same bytes/hash.',
    reasoning: 'Exact resolved oracle agrees with supplied product contract. Both complete traces retain 4/4 events, no request failures, and no selector/hydration/auth/locale dependency. Adapter source parses JSON and compares the named own-property value. Matching diagnostic body digest supports an observed synthetic API contract discrepancy rather than assertion tuning. The sealed needs_review/INCONCLUSIVE verdict is unchanged; assertion-2 was not reached in the original run.',
    expectationBasis: 'actor-2 product-brief.md; managed catalog urn:qa:catalog-entry:d34c8792f361f7ea96e016a8, source urn:qa:source:3260b412adf6e84447bd51cf contentDigest sha256:53ccd4a3f750f7d7d8a9c8a76189ba68f1c6497b7c959281756e557214db7b43; graph requested-journey requires invariant edge urn:qa:edge:81516f2602d080b9aa9649a2.',
    limitations: ['Agent-authored interpretation, not a changed runner verdict or automatic confirmed bug dossier.', 'Raw JSON is a later separately attributed diagnostic observation, not stored inside original campaign artifacts; its hash and length match both original attempts.', 'Fixture/source/deployed build identity not independently attested; contract sources remain declared user input.', 'Integrity API projection checked, not individual published entries. Surface candidate remains blocked; other quality dimensions and query equivalence unassessed.'],
  },
};
await writeFile(path.join(actor, 'review-draft.json'), JSON.stringify(draft, null, 2), {flag: 'wx'});
function cli(command: string, args: string[], input?: string) {
  const result = spawnSync('npm', ['run', 'qa-campaign', '--', command, '--workspace', ctx.workspacePath, '--approval-store', ctx.storeRoot, ...args], {
    cwd: ctx.consolePath, encoding: 'utf8', input, maxBuffer: 16 * 1024 * 1024,
    env: {...process.env, QA_STARTER_REPO: ctx.kernelPath, QA_STARTER_EXPECTED_SHA: '185d3e72309a4362db57cf2e805d1c00a5035909'},
  });
  return {exitCode: result.status, stdout: result.stdout, stderr: result.stderr};
}
const saved = cli('record-review', [], JSON.stringify(draft));
await writeFile(path.join(actor, 'record-review-output.json'), JSON.stringify(saved, null, 2), {flag: 'wx'});
if (saved.exitCode !== 0) { console.log(JSON.stringify(saved)); process.exit(1); }
const record = JSON.parse(saved.stdout.trim().split('\n').at(-1)!);
const checked = cli('read-review', ['--review-digest', record.reviewDigest]);
await writeFile(path.join(actor, 'read-review-output.json'), JSON.stringify(checked, null, 2), {flag: 'wx'});
console.log(JSON.stringify({record, readbackExitCode: checked.exitCode, readback: checked.stdout, stderr: checked.stderr}, null, 2));
