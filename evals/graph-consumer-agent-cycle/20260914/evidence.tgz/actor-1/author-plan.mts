import { readFile, copyFile, constants } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
const actor = '/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-graph-consumer-EGSI1n/actor-1';
const context = JSON.parse(await readFile(`${actor}/actor-context.json`, 'utf8'));
const api = await import(pathToFileURL(`${context.consolePath}/src/node/qa-campaign-files.ts`).href);
const schema = await import(pathToFileURL(`${context.consolePath}/src/lib/qa-campaign-v0.ts`).href);
const { digestCanonical } = await import(pathToFileURL(`${context.consolePath}/src/lib/canonical-digest.ts`).href);
const w = await api.readCampaignWorkspace(context.workspacePath);
const selections = [
  {id:'urn:qa:check:df559038822e11c111c0cd52', path:'/api/catalog', fields:[['$.catalogName','Stage Four'],['$.ready',true]]},
  {id:'urn:qa:check:e09df2647191531a3686605f', path:'/api/catalog-integrity', fields:[['$.invariantSatisfied',true],['$.unlabeledItemCount',0]]},
];
const plan = schema.QaCampaignPlanV0Schema.parse({
  schemaVersion:'qa-campaign.v0', productSlug:context.productSlug, graphDigest:w.graph.semanticDigest, baseUrl:context.baseUrl,
  checks:selections.map(s => {
    const e=w.catalog.entries.find(e=>e.checkId===s.id);
    const node=w.graph.nodes.find(n=>n.id===s.id);
    if(!e || e.oracle.state!=='resolved')throw new Error('Expected resolved registered check absent');
    return {checkId:e.checkId,title:node.name,targetIds:e.targetIds,disposition:'executable',sideEffectClass:'read_only',
      preconditions:['Owned anonymous synthetic loopback API; no credentials or mutation.'],
      reproductionSteps:[`GET ${s.path}`, 'Compare response status and exact JSON fields with the resolved registered oracle.'],
      expectedBehavior:e.oracle.description,severity:'medium',severityJustification:'A failed contract would impair anonymous catalog consumption; synthetic scope does not establish live severity.',
      kind:'api',surface:'api',method:'GET',path:s.path,
      assertions:[{kind:'status',value:200},...s.fields.map(([path,value])=>({kind:'json_path',path,value}))]};
  }),
  blockers:[{targetId:'urn:qa:surface:92390b75a9aa4e09448d6ed8',catalogCheckIds:['urn:qa:automated-check:9e5e106c9abba11cccd56b94'],disposition:'blocked',
    reason:'Existing automated surface candidate has unresolved oracle and remains unassessed. Retain graph discovery gaps urn:qa:graph-unresolved:985eaa19ea536fc4b3316ea0 (no honest runnable generated check from initial inputs) and urn:qa:graph-unresolved:23f8b8f2b20938ffb1a19d23 (generated candidate has no approved oracle); these do not erase the two resolved checks.',
    recovery:'Owner resolves exact surface expectation through authorized knowledge/oracle workflow in a later scoped task; no approval or graph revision in this campaign.'}]
});
schema.validateCampaignClosure({graph:w.graph,catalog:w.catalog,expectedProductSlug:context.productSlug,allowedBaseUrls:[context.baseUrl],plan});
const planPath=`${context.workspacePath}/tests/qa-campaign.v0.json`;
await api.writeNewCampaignPlan(context.workspacePath,planPath,plan);
await copyFile(planPath,`${actor}/original-plan.json`,constants.COPYFILE_EXCL);
const persisted=schema.QaCampaignPlanV0Schema.parse(await api.readCampaignPlan(context.workspacePath,planPath));
console.log(JSON.stringify({planPath,planDigest:digestCanonical(persisted),baseUrl:persisted.baseUrl,executable:persisted.checks.length,blockers:persisted.blockers.length},null,2));
