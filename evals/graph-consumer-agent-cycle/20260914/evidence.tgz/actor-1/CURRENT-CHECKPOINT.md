# Current checkpoint

Bounded actor-1 campaign finished; sealed verdict INCONCLUSIVE, not whole-product PASS. No automatic execution pending.

Owner directory: /private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-graph-consumer-EGSI1n/actor-1
Workspace: owner/nuanu-readonly-qa. Exact authorized origin http://127.0.0.1:60510/. Root1925d37 / Console66ac7db / Kernel185d3e7 observed; target deployment SHA unknown.

Selected/executed: urn:qa:check:df559038822e11c111c0cd52 pass (1 attempt); urn:qa:check:e09df2647191531a3686605f needs_review (2 oracle_failure attempts). Total catalog 3, executed 2, pass 1, needs_review 1, blocked/unassessed automated candidate urn:qa:automated-check:9e5e106c9abba11cccd56b94 = 1. Zero dossiers/tickets/runner-confirmed bugs. Graph has 3 coverage targets; all accounted. Surface/discovery gaps retained.

Original plan preserved owner/original-plan.json; unchanged canonical workspace/tests/qa-campaign.v0.json. PlanDigest sha256:8aa10b54ca980e08cbb075ce28d1af7c8016ee902f126ea84089ac342b749cad. validate-output.json ok true/readyToRun false. pre-run-boundary.json records baseUrl/executable2/blockers1 immediately before one CLI run. No corrected/final plan differs; no CAS or campaign rerun.

Receipt: workspace/tests/campaign-runs/run-243ac2e2df9b4998-b8060771-480a-416c-90ac-3871ad8f1edc/receipt.json; sha256:73fe1a850c8751d4890bde6b3c04bda84d9abf13f00da91d8ed106d6c0e7c94a. Actual reader output owner/actual-evidence-readback.json. All six original artifact bytes/hashes verified. Both failure traces inspected (4/4 events); $.unlabeledItemCount assertion was not reached.

One separately justified diagnostic GET (diagnostic-reason.md written first) captured false/1 body with exact same 51-byte SHA-256 as both original failed responses. owner/diagnostic-observation.json is later, agent-authored/unattested evidence. Supports synthetic endpoint-contract issue, not direct entry inspection or live-product bug. Original sealed verdict unchanged.

Review digest sha256:c6845469e51c843a6f6e3a2b2c8619790f59db533cdaba967a30c6b889188459; workspace/.qa-private/findings/campaign-review-c6845469e51c843a6f6e3a2b2c8619790f59db533cdaba967a30c6b889188459.json. owner/review-read-output.json confirms current local binding and unchanged INCONCLUSIVE verdict, exit0.

Tool correction: nonexistent evidence-reader source filename lookup exit2 corrected to campaign-receipts.mjs; no execution retry. Independence concern: manifest pin read unintentionally exposed inline qualification history metadata after frozen first-decision; no linked history/preparation/controller/sibling roots read and no selection change. See final-report.md for exact attribution and omissions.

Unassessed/outside scope: unresolved surface oracle, query-string equivalence, individual entries, UI/accessibility/performance/security, auth/native/payment/mutations. No human help needed for completed bounded diagnosis. Next: parent artifact review; later owner-scoped oracle resolution or investigation only. Do not rerun the completed run-and-read.mts script automatically (exclusive artifact writes and no duplicate campaign authority).
