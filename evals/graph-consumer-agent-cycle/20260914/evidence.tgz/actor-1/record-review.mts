import {readFile} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
const actor='/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-graph-consumer-EGSI1n/actor-1';
const c=JSON.parse(await readFile(`${actor}/actor-context.json`,'utf8'));
const evidence=JSON.parse(await readFile(`${actor}/actual-evidence-readback.json`,'utf8'));
const {writeCampaignArtifact}=await import(pathToFileURL(`${c.consolePath}/src/node/qa-campaign-files.ts`).href);
const {AgentReviewDraftV0Schema}=await import(pathToFileURL(`${c.consolePath}/src/lib/qa-agent-review-v0.ts`).href);
const {campaignCheckArtifactToken}=await import(pathToFileURL(`${c.consolePath}/src/lib/qa-campaign-v0.ts`).href);
const check=evidence.plan.checks[1];
const draft=AgentReviewDraftV0Schema.parse({expectedReceiptDigest:evidence.receiptDigest,checkId:check.checkId,attempt:1,expectedBehavior:check.expectedBehavior,
  artifacts:evidence.receipt.artifacts.filter(a=>a.path.includes(`/checks/${campaignCheckArtifactToken(check.checkId)}/attempt-1/`)),
  author:{agent:'catalog_reader_one',host:'codex',authoredAt:new Date().toISOString()},
  assessment:{kind:'product_issue',scope:'Owned synthetic GET /api/catalog-integrity contract only.',actual:'Original attempt 1 status 200; $.invariantSatisfied expected true fails. Attempt 2 has identical outcome and body hash. Independent later diagnostic GET body is {"invariantSatisfied":false,"unlabeledItemCount":1}, 51 bytes, with exact matching original body SHA-256.',
    reasoning:'Brief and resolved catalog oracle agree on true and zero. Both complete 4-event traces show transport/status success and exact own-property JSON assertion failure, not browser readiness, locale, authentication or selector ambiguity. The later body hash matches both original attempts, supporting a synthetic endpoint contract violation. No inference that actual catalog entries were directly inspected.',
    expectationBasis:'Owned product-brief.md and catalog check urn:qa:check:e09df2647191531a3686605f; preserved original plan uses exact resolved description.',
    limitations:['Agent-authored interpretation; immutable campaign verdict remains INCONCLUSIVE and check remains needs_review.','Direct later observation is separate from this original-artifact review and is saved in actor diagnostic-observation.json.','Original assertion-2 on count was not reached; later observation supplies that count only.','Source/deployment target identity and fixture implementation unknown; no live-product defect or release acceptance claim.','One unresolved automated surface candidate remains blocked.']}});
await writeCampaignArtifact(actor,'review-draft.json',JSON.stringify(draft,null,2));
const env={...process.env,QA_STARTER_REPO:c.kernelPath,QA_STARTER_EXPECTED_SHA:'185d3e72309a4362db57cf2e805d1c00a5035909',QA_REGISTRATION_STORE:c.storeRoot};
const invoke=(args,input)=>spawnSync('npm',['run','qa-campaign','--',...args],{cwd:c.consolePath,env,encoding:'utf8',input,timeout:60000,maxBuffer:4*1024*1024});
const saved=invoke(['record-review','--workspace',c.workspacePath],JSON.stringify(draft));
await writeCampaignArtifact(actor,'review-write-output.json',JSON.stringify({status:saved.status,stdout:saved.stdout,stderr:saved.stderr},null,2));
const record=JSON.parse(saved.stdout.trim().split('\n').at(-1));
console.log('WRITE',JSON.stringify(record));
if(saved.status!==0 || !record.reviewDigest)throw new Error('Review write did not return digest');
const read=invoke(['read-review','--workspace',c.workspacePath,'--review-digest',record.reviewDigest]);
await writeCampaignArtifact(actor,'review-read-output.json',JSON.stringify({status:read.status,stdout:read.stdout,stderr:read.stderr},null,2));
console.log('READ',read.stdout);
