# First decision — before target requests or execution

Product intent: anonymously read the Stage Four public catalog at the packet's exact loopback origin, http://127.0.0.1:60510/. This is synthetic API QA, not live product/release acceptance.

Read completely: packet, product brief, current Console qa-product-v0 skill and declarative-campaign/product-analysis references, managed product.graph.json and test-catalog.json.

Source basis: packet-selected root1925d37, Console66ac7db, Kernel185d3e7 (local identity verification next); graph semantic digest sha256:39ed43cd723bcf506f2d7dffcb9b8e3ba37c4d23002b54cfa4795c2be362fab7; catalog semantic digest sha256:2721691ae306ba328fac94fdd11f780bcf3e6a917f880f125b536878a1a78a87.

Selected existing checks:
- urn:qa:check:df559038822e11c111c0cd52, Ready public catalog assertion. Direct graph verifies edge facfe6539bb86aef3be518a8 binds requested journey urn:qa:discovery-target:7690df148f5098c220e66700. Preserve exact catalog oracle: GET /api/catalog returns status 200, catalogName Stage Four, and ready true.
- urn:qa:check:e09df2647191531a3686605f, Published catalog label invariant assertion. Graph verifies edge 232afa86fa3cfbcd3ddb8de7 binds invariant urn:qa:invariant:653cb7a251f64ed0a28837d0. The graph has no journey-to-invariant dependency edge. Selection is independently inferred from the supplied brief's rule that every published entry has a nonblank displayLabel, materially relevant to reading the public catalog; it is NOT graph-derived dependency traversal or an observed discovery. Preserve exact catalog oracle: GET /api/catalog-integrity returns status 200, invariantSatisfied true, and unlabeledItemCount 0.

Omissions/blockers: surface urn:qa:surface:92390b75a9aa4e09448d6ed8 has existing automated candidate urn:qa:automated-check:9e5e106c9abba11cccd56b94, but unresolved oracle, so it remains blocked (automation exists, not absent). Preserve both graph discovery gaps 985eaa19ea536fc4b3316ea0 and 23f8b8f2b20938ffb1a19d23 in plan blockers. No new IDs, knowledge revision or oracle approval. UI/rendering, accessibility, performance, security, authenticated/mutation/payment behaviors are outside this bounded API request. Query-string equivalence is declared in brief but no separate existing check oracle selected to establish it; no extra check is created.

Known unknowns: no requests yet, so current API behavior and independently attested deployment identity unknown. Graph is draft with declared/unreviewed source provenance; resolved catalog oracles supply test semantics without upgrading provenance. No existing plan per brief; inspect actual workspace next. Catalog integrity projects the label invariant; an endpoint match alone is not a direct inspection of every catalog entry.

Next action: inspect owned workspace and selected source schema/API/CLI/pins; author both existing resolved checks using V0 supported API assertions and account for all uncovered graph/catalog relations as blockers. Preserve original plan bytes outside managed workspace, validate, record exact digest/baseUrl/executable/blocker counts immediately before one authorized run, and inspect actual evidence and both attempts for any non-pass result. No independent exploration performed or planned before selection.
