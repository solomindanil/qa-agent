# Stage Four public catalog — bounded result

Sealed campaign verdict: **INCONCLUSIVE**. Selected/executed 2 existing checks: 1 pass, 1 needs_review; 1 existing automated candidate blocked/unassessed. Total catalog denominator 3; graph coverage-target denominator 3 (journey, invariant, surface). No confirmed runner product bugs, dossiers or tickets. This is not whole-product PASS or release acceptance.

## Scope and source

Owned anonymous synthetic origin: http://127.0.0.1:60510/. Requested journey: Read the public catalog. Runtime observed root 1925d37e4723d8a1c9f2ecc2a7dade5d3774b1f2; Console 66ac7db55a25f56b199b2cb00ad83df3b8dad868; Kernel 185d3e72309a4362db57cf2e805d1c00a5035909, matching manifest and Console pin. Product deployment/source identity remains unknown; runtime source pins do not attest target version. Tool timestamps were 2026-09-14 UTC; no claim is made from the conversational date.

Read complete packet/brief, selected current qa-product-v0 and required declarative-campaign, product-analysis and agent-observations references, full managed graph/catalog, project profile and journey/invariant declarations. Used schema and existing file APIs, original CLI and actual evidence reader. Existing generated workspace scaffold warning does not grant execution authority; explicit packet authority covered this one exact safe campaign.

First decision saved before any target requests/execution in first-decision.md. Graph sha256:39ed43cd723bcf506f2d7dffcb9b8e3ba37c4d23002b54cfa4795c2be362fab7; catalog sha256:2721691ae306ba328fac94fdd11f780bcf3e6a917f880f125b536878a1a78a87. Graph has only two verifies edges and no declared journey→invariant dependency. Ready check selection is directly graph-derived; integrity selection was explicitly independently inferred from the supplied brief's label invariant, not claimed as dependency traversal. No exploratory response influenced initial selection. Graph/catalog remain unchanged.

## Original selection and actual results

- urn:qa:check:df559038822e11c111c0cd52 — pass, 1 attempt. GET /api/catalog status 200; assertions catalogName = Stage Four and ready = true passed. Original trace complete: 5/5 events.
- urn:qa:check:e09df2647191531a3686605f — needs_review, 2 built-in attempts. Each GET /api/catalog-integrity returned 200; assertion-1 expecting $.invariantSatisfied = true failed as json_path_mismatch. Original traces complete: 4/4 events each. Assertion-2 expecting $.unlabeledItemCount = 0 was not reached in either attempt, not independently passed or executed.
- urn:qa:automated-check:9e5e106c9abba11cccd56b94 — blocked/unassessed, not absent automation. Surface urn:qa:surface:92390b75a9aa4e09448d6ed8 has unresolved catalog oracle. The single target blocker also retains both graph discovery gaps 985eaa19ea536fc4b3316ea0 and 23f8b8f2b20938ffb1a19d23; V0 blocker schema only accepts actual coverage targets, so gap IDs are preserved in its reason rather than invented targets.

Three campaign HTTP requests total (one readiness, two integrity); one separately justified diagnostic GET afterward. No second campaign, plan correction/CAS, oracle weakening, retries to obtain green, installs, product/graph/source changes, external network or tracker writes.

## Diagnosis, separate from sealed verdict

Both original failures retained only response summary: 51 bytes, sha256:20206dae750ea2d186941002d89967669d884a86b90b8d1cfd148900385acc3a. Original plan assertions and every result/trace artifact were inspected. Brief and resolved oracle agree; selected adapter uses JSON parse and exact own-property path equality. Transport/status succeeds; browser hydration, locators, locale and authenticated session assumptions do not explain this API failure. No evidence of harness failure or wrong origin in these traces.

diagnostic-reason.md records the concrete hypothesis and additional observation purpose BEFORE the request. At 2026-09-14T16:18:17.395Z one anonymous redirect-disabled GET returned 200 and body {"invariantSatisfied":false,"unlabeledItemCount":1}, exactly matching the original attempts' size/hash. diagnostic-observation.json is agent-authored, unattested later evidence, not an added campaign attempt. It supports a synthetic endpoint-contract issue; it does not inspect individual catalog entries, prove why fixture data is wrong, or establish a live-product bug. No fixture/preparation source inspected. Original runner needs_review/INCONCLUSIVE remains unchanged.

Attributed review kind product_issue is limited to that synthetic endpoint contract. It is stored and read back current against local campaign evidence, not attested against current deployment. The debugging skill guided evidence-first diagnosis; verification-before-completion guided artifact and original-plan readback. No fix implemented.

## Artifacts and validation

All following paths are owned and relative to this report's directory unless prefixed workspace:

- first-decision.md; author-plan.mts; original-plan.json (exact original plan bytes outside managed workspace).
- workspace = nuanu-readonly-qa. Canonical plan: workspace/tests/qa-campaign.v0.json.
- validate-output.json: CLI exit 0, ok true, readyToRun false, 2 executable targets and 1 blocked target. Safe subset execution remains authorized despite retained gap.
- pre-run-boundary.json: recorded immediately before run, exact planDigest sha256:8aa10b54ca980e08cbb075ce28d1af7c8016ee902f126ea84089ac342b749cad, baseUrl http://127.0.0.1:60510/, executable 2, blockers 1.
- run-output.json: actual CLI exit 1, INCONCLUSIVE (expected non-pass result, not unexpected tool failure).
- workspace/tests/campaign-runs/run-243ac2e2df9b4998-b8060771-480a-416c-90ac-3871ad8f1edc/receipt.json. Receipt digest sha256:73fe1a850c8751d4890bde6b3c04bda84d9abf13f00da91d8ed106d6c0e7c94a.
- actual-evidence-readback.json: successful existing readLatestCampaignEvidence result, containing exact receipt, plan and six artifact inventory entries. Original JSON traces, not screenshots, are the applicable API evidence; no screenshots/tickets/dossiers exist.
- review-draft.json, review-write-output.json, review-read-output.json. Review digest sha256:c6845469e51c843a6f6e3a2b2c8619790f59db533cdaba967a30c6b889188459; workspace/.qa-private/findings/campaign-review-c6845469e51c843a6f6e3a2b2c8619790f59db533cdaba967a30c6b889188459.json. Both review commands exited 0, currentBinding.state=current, campaign verdict still INCONCLUSIVE.
- Final verification reread all 6 original artifacts and matched bytes/SHA-256; canonical plan is byte-identical to original-plan.json.

## Omissions, tool issues and independence concern

Surface oracle remains unresolved; query-string equivalence, individual catalog-entry data, UI/rendering, accessibility, performance/security, authenticated/native/payment/mutation behaviors remain unassessed or outside scope. Existing automation coverage is preserved for all three entries. No missing human capability prevents diagnosis; resolving the unrelated surface oracle needs a later scoped owner knowledge/oracle decision, not redundant permission for this run.

One read-only source lookup guessed nonexistent server/campaign-evidence-reader.mjs and returned exit 2. Corrected by source filename inventory to server/campaign-receipts.mjs before execution; no campaign failure or rerun resulted. Some long source/tool displays were truncated; required instruction references and full graph/catalog were not truncated, and relevant API regions were subsequently read directly.

Independence limitation: reading sources/manifest.v1.json for exact current pins also displayed its inline historical qualification annotations and other component metadata. This was unintended exposure beyond pin facts; no linked history, global planning, controller, fixture-preparation or sibling-actor files were read. First decision had already been written and selection did not change. Parent notified; do not present the execution as perfectly history-blind.

Next action: parent independently inspects these original artifacts and attributed diagnosis. Any further product investigation, graph revision, oracle resolution or additional campaign requires its concrete new scope/reason; no automatic rerun is pending.
