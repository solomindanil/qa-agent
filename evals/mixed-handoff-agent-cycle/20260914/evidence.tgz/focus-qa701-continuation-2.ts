import assert from "node:assert/strict";
import path from "node:path";
import { digestCanonical } from "/Users/danilsolomin/projectsnew/qa-agent/.local/mixed-execution-20260914.uzce9U/root/components/console/src/lib/canonical-digest.ts";
import { QaCampaignPlanV0Schema } from "/Users/danilsolomin/projectsnew/qa-agent/.local/mixed-execution-20260914.uzce9U/root/components/console/src/lib/qa-campaign-v0.ts";
import { readCampaignPlan, readCampaignWorkspace, writeCampaignPlan } from "/Users/danilsolomin/projectsnew/qa-agent/.local/mixed-execution-20260914.uzce9U/root/components/console/src/node/qa-campaign-files.ts";

const workspacePath = "/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-mixed-agent-LAqLDG/nuanu-readonly-qa";
const planPath = path.join(workspacePath, "tests", "qa-campaign.v0.json");
const expectedCurrentDigest = "sha256:0bfd6395e1b0ce61493cc1ead41ff9e1c75a9e5fa952feb0cf11ec6bbabc251e";
const qa701CheckId = "urn:qa:check:461f28eebf3521e4b55df683";
const original = {
  subscription: { id: "subscription-original-17", status: "expired" },
  assignment: { id: "assignment-original-17", status: "retained" },
};

async function main(): Promise<void> {
  const workspace = await readCampaignWorkspace(workspacePath);
  const current = QaCampaignPlanV0Schema.parse(await readCampaignPlan(workspacePath, planPath));
  assert.equal(digestCanonical(current), expectedCurrentDigest, "Frozen predecessor plan changed");
  assert.equal(current.baseUrl, "http://127.0.0.1:49160/");
  assert.equal(workspace.graph.semanticDigest, "sha256:433f8c5f766bb459f89b2012fed7f0d2a3bc740bfa7f67977cd378d193706fdf");
  assert.equal(workspace.catalog.semanticDigest, "sha256:a12ba94fc87c998049f4c4ccf5aba26b011f9bbb72a7f1f2318476057ea3d5d0");
  const entry = workspace.catalog.entries.find(item => item.checkId === qa701CheckId)!;
  assert.equal(entry.oracle.state, "resolved");
  assert.equal(entry.targetIds.length, 1);
  const qa701Target = entry.targetIds[0]!;
  const blockedById = new Map(current.blockers.map(item => [item.targetId, item]));
  const gapTargets = new Set([
    "urn:qa:discovery-target:dc36d493fca0d42e372b196a",
    "urn:qa:discovery-target:cfba0c34a560165af5b6d622",
  ]);
  const blockers = workspace.graph.nodes.filter(node => node.coverageTarget && node.id !== qa701Target).map(node => {
    if (gapTargets.has(node.id)) {
      const retained = blockedById.get(node.id);
      assert.ok(retained, "Separate capability gap must remain represented");
      return retained;
    }
    const isQa707 = node.id === "urn:qa:discovery-target:6c19eafe1851c1afc1a4738b";
    const receipt = isQa707
      ? "run-c60e8a070260ab77-8c7facac-ff76-4c90-b5ff-29bf8e13d080 (sha256:89b0957ceb891824d5b96d4b644c3be8e41b57b63a1b698d1e6d2df1c25cefc1)"
      : "run-1dd8b96b2dbddf89-3724e0b5-158e-48ff-b35d-8ab0d6e1a8c8 (sha256:34fb391c1cc5431c239e18a344dd34e71a18dc539f6eed088f59b2da2683f8ba)";
    return {
      targetId: node.id,
      catalogCheckIds: workspace.catalog.entries.filter(item => item.targetIds.includes(node.id)).map(item => item.checkId).sort(),
      disposition: "blocked" as const,
      reason: `Not re-executed in continuation 2, which resolves QA-701 only. Retain ${receipt} and its separate agent diagnoses in cumulative accounting.`,
      recovery: "Do not repeat completed independent checks merely because QA-701 help arrived. Recheck only for a concrete relevant change or scoped diagnostic need; historical evidence is not re-attested by this focused run.",
    };
  }).sort((a, b) => a.targetId.localeCompare(b.targetId));
  const next = QaCampaignPlanV0Schema.parse({
    ...current,
    checks: [{
      checkId: qa701CheckId,
      title: "QA-701 original VPN replacement projection",
      targetIds: [qa701Target],
      disposition: "executable",
      sideEffectClass: "read_only",
      preconditions: [
        "Same authorized loopback origin, account rel-17 and synthetic candidate label cccccccccccccccccccccccccccccccccccccccc; originalEvidenceReady true observed after operator reply 2.",
        "Only original operation op-vpn-17; no operation creation, purchase, SQL access, replay or network VPN action.",
        "Witness IDs and original baseline records were observed from the supplied API projection; preservation and 30-day expectations come from the original product brief, not from operator acceptance claims.",
      ],
      reproductionSteps: ["GET /api/vpn/original-evidence and compare identity, original operation, 30-day grant, exactly one reservation-assignment link, expired original subscription and identical before/after original records."],
      expectedBehavior: entry.oracle.description,
      severity: "high",
      severityJustification: "Incorrect replacement duration, linkage or loss of original records would violate the supported original-operation evidence criterion.",
      kind: "api",
      surface: "api",
      method: "GET",
      path: "/api/vpn/original-evidence",
      assertions: [
        { kind: "status", value: 200 },
        { kind: "json_path", path: "$.candidateSha", value: "cccccccccccccccccccccccccccccccccccccccc" },
        { kind: "json_path", path: "$.accountId", value: "rel-17" },
        { kind: "json_path", path: "$.operationId", value: "op-vpn-17" },
        { kind: "json_path", path: "$.durationDays", value: 30 },
        { kind: "json_path", path: "$.links", value: [{ reservationId: "res-17", assignmentId: "assign-17", operationId: "op-vpn-17" }] },
        { kind: "json_path", path: "$.originalRecordsBefore", value: original },
        { kind: "json_path", path: "$.originalRecordsAfter", value: original },
      ],
    }],
    blockers,
  });
  assert.equal(next.checks.length, 1);
  assert.equal(next.blockers.length, 8);
  const mode = process.argv.includes("--apply") ? "apply" : "preview";
  if (mode === "apply") {
    await writeCampaignPlan(workspacePath, planPath, next, expectedCurrentDigest);
    const readback = QaCampaignPlanV0Schema.parse(await readCampaignPlan(workspacePath, planPath));
    assert.equal(digestCanonical(readback), digestCanonical(next), "Owning plan API readback mismatch");
  }
  console.log(JSON.stringify({ mode, priorPlanDigest: expectedCurrentDigest, planDigest: digestCanonical(next), planPath, plan: next }, null, 2));
}

void main().catch(error => { console.error(error); process.exitCode = 1; });
