import path from "node:path";

import { digestCanonical } from "/Users/danilsolomin/projectsnew/qa-agent/.local/mixed-execution-20260914.uzce9U/root/components/console/src/lib/canonical-digest.ts";
import { QaCampaignPlanV0Schema } from "/Users/danilsolomin/projectsnew/qa-agent/.local/mixed-execution-20260914.uzce9U/root/components/console/src/lib/qa-campaign-v0.ts";
import {
  readCampaignPlan,
  readCampaignWorkspace,
  writeCampaignPlan,
} from "/Users/danilsolomin/projectsnew/qa-agent/.local/mixed-execution-20260914.uzce9U/root/components/console/src/node/qa-campaign-files.ts";

const workspacePath = "/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-mixed-agent-LAqLDG/nuanu-readonly-qa";
const planPath = path.join(workspacePath, "tests", "qa-campaign.v0.json");
const priorRunId = "run-1dd8b96b2dbddf89-3724e0b5-158e-48ff-b35d-8ab0d6e1a8c8";
const priorReceiptDigest = "sha256:34fb391c1cc5431c239e18a344dd34e71a18dc539f6eed088f59b2da2683f8ba";
const qa707CheckId = "urn:qa:check:f21f112a1a4164a60c91abcc";

async function main(): Promise<void> {
  const workspace = await readCampaignWorkspace(workspacePath);
  const current = QaCampaignPlanV0Schema.parse(await readCampaignPlan(workspacePath, planPath));
  const expectedCurrentDigest = digestCanonical(current);
  const qa707 = current.checks.find((check) => check.checkId === qa707CheckId);
  if (qa707?.kind !== "browser") throw new Error("Current QA-707 browser check is missing");
  const corrected = {
    ...qa707,
    assertions: qa707.assertions.map((assertion, index) => index === 0
      ? { kind: "visible" as const, locator: { kind: "text" as const, text: "No numbers yet" } }
      : assertion),
  };
  const qa707Target = qa707.targetIds[0]!;
  const currentBlockers = new Map(current.blockers.map((blocker) => [blocker.targetId, blocker]));
  const blockers = workspace.graph.nodes
    .filter((node) => node.coverageTarget && node.id !== qa707Target)
    .map((node) => {
      const retained = currentBlockers.get(node.id);
      if (retained !== undefined) return retained;
      const catalogCheckIds = workspace.catalog.entries
        .filter((entry) => entry.targetIds.includes(node.id))
        .map((entry) => entry.checkId)
        .sort();
      return {
        targetId: node.id,
        catalogCheckIds,
        disposition: "blocked" as const,
        reason: `Not repeated in the focused QA-707 harness correction; retain ${priorRunId} (${priorReceiptDigest}) in cumulative coverage accounting.`,
        recovery: "Use the prior validated receipt and agent reviews; re-execute only after a concrete product/environment change or another scoped diagnostic need.",
      };
    })
    .sort((left, right) => left.targetId.localeCompare(right.targetId));
  const focused = QaCampaignPlanV0Schema.parse({
    ...current,
    checks: [corrected],
    blockers,
  });
  await writeCampaignPlan(workspacePath, planPath, focused, expectedCurrentDigest);
  const readback = QaCampaignPlanV0Schema.parse(await readCampaignPlan(workspacePath, planPath));
  console.log(JSON.stringify({
    priorPlanDigest: expectedCurrentDigest,
    planDigest: digestCanonical(readback),
    planPath,
    executableCheckIds: readback.checks.map((check) => check.checkId),
    blockedTargetIds: readback.blockers.map((blocker) => blocker.targetId),
  }, null, 2));
}

void main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
