# Первый отчёт QA: Relay — controlled mixed-ticket retest

Дата фиксации: 2026-09-14T15:11:27Z. Это исходный отчёт первой фазы; его не следует переписывать по результатам последующей истории.

## Итог первой фазы

Проверка выполнена только на разрешённом synthetic loopback `http://127.0.0.1:49160/`, для account `rel-17` и fixture label `cccccccccccccccccccccccccccccccccccccccc`. Этот label не является attestation реального deployment SHA.

Знаменатель сохранён полностью: 7/7 тикетов. Кумулятивный QA-диагноз первой фазы:

- соответствуют доступному критерию: 3/7 — QA-704, QA-705, QA-707;
- выявлено несоответствие: 1/7 — QA-702;
- ожидают недостающей capability/evidence: 3/7 — QA-701, QA-703, QA-706.

Это частичный результат, не PASS продукта или релиза. Покупок, платежей, повторного создания операции, изменений account/provider, внешних вызовов и записей в tracker не было.

## Классификации runner и отдельный QA-диагноз

Первый CLI run `run-1dd8b96b2dbddf89-3724e0b5-158e-48ff-b35d-8ab0d6e1a8c8` завершён с immutable runner verdict `INCONCLUSIVE`: 5 `pass`, 2 `needs_review`, 3 blocked targets, 0 dossiers. Receipt: `sha256:34fb391c1cc5431c239e18a344dd34e71a18dc539f6eed088f59b2da2683f8ba`.

Runner не классифицировал QA-702 как подтверждённый дефект: обе попытки остались `needs_review`. Отдельный agent review `sha256:d2a3eb3519d41dbea70f14f1183ecebe511959651ae4dce997b7d0896146a2b5` диагностировал `product_issue`, потому что brief однозначен, identity/provider совпадают, а свежий response совпал с runner body hash.

Первичный QA-707 также получил `needs_review`, но screenshot показывал ожидаемый текст. Agent review `sha256:af53870d278ed8bd7396e7861c7eb2ac32cd3efc90d5889e6854084ed24d2f5c` диагностировал `harness_issue`: `role=status` с accessible name был негрунтованным locator и остановил последующие assertions. После CAS-ревизии только этого check второй CLI run `run-c60e8a070260ab77-8c7facac-ff76-4c90-b5ff-29bf8e13d080` дал 1 `pass`; общий runner verdict остался `NEEDS_HUMAN`, поскольку остальные 8 graph targets намеренно не повторялись и были удержаны как blocked. Receipt: `sha256:89b0957ceb891824d5b96d4b644c3be8e41b57b63a1b698d1e6d2df1c25cefc1`.

## Все семь тикетов

### QA-701 — BLOCKED / NEEDS_HELP

В финальной проверке identity неизменна: candidate `cccccccccccccccccccccccccccccccccccccccc`, account `rel-17`, `originalEvidenceReady=false`. `GET /api/vpn/original-evidence` отвечает HTTP 503 `{"error":"original_evidence_not_ready"}`. Check опубликован в catalog, но не запускался. Нельзя делать вывод о 30 днях, единственной reservation→assignment связи или сохранённых before/after original records.

Нужная помощь: оператору/разработчику включить уже предусмотренную original-evidence capability и сообщить о готовности. После ответа QA должен заново прочитать `/api/environment`, убедиться в той же identity и `originalEvidenceReady=true`, прочитать response schema/values и выполнить только QA-701. Секреты, VPN credentials или реальная network-проверка не нужны.

### QA-702 — PRODUCT ISSUE по agent review; runner `needs_review`

Для одного provider `number-provider-1`:

- `/api/provider` — `supportsRenewal=false` (runner PASS);
- `/api/renewal` — `renewalAvailable=true` и quote `{amount:3,currency:"TEST"}`.

Обе runner-попытки получили один и тот же 97-byte body hash `sha256:4fd35dba1d9aae66fece4120f9db78ce1dc6b666ddbf6cd7d3f506b902174c8c`; свежий разрешённый GET дал те же 97 bytes и hash. Это противоречит критерию «quote доступен только при поддержке renewal». Tracker не изменялся.

### QA-703 — BLOCKED / CAPABILITY GAP

PostgreSQL и replay capability не предоставлены. Public history и mocked unit tests не использовались как замена. Нет доказательства ровно одной fee-ledger row, отсутствия дополнительной строки при replay и неизменности amount. Это не классифицировано как дефект разработки.

Нужная помощь: read-only PostgreSQL evidence для одной и той же qualifying card event до/после отдельно авторизованного replay, с row identity, count и amount. Сам QA replay не инициирует без отдельной authority.

### QA-704 — PASS в точном synthetic API scope

Root-object assertion на полный `/api/card` response прошёл: объект содержит только `accountId:"rel-17"` и `last4:"1074"`. Полного PAN, security code и дополнительных полей в полном response нет. UI-критерий не добавлялся.

### QA-705 — PASS в точном synthetic API scope

Root-object assertion на полный `/api/history` response прошёл: ровно одна операция `op-vpn-17`, `amount:12`, `currency:"TEST"`, `status:"completed"`, account `rel-17`. Новая операция или оплата не создавалась.

### QA-706 — BLOCKED / CAPABILITY GAP

Именованные original treasury, settlement, resulting card-credit references и financial evidence не предоставлены. Обычная purchase history не использовалась как замена. Linkage, reconciliation и ровно один fee posting не оценены; это не классифицировано как дефект.

Нужная помощь: предоставить named original references и read-only evidence их связи, сумм/reconciliation и единственного fee posting.

### QA-707 — PASS после сфокусированной коррекции harness

Финальный browser check на Chromium 1280×720 прошёл полностью: rendered text `No numbers yet` видим, locator `data-testid=number-card` имеет count 0, `/numbers` вернул 200, console errors и failed requests отсутствуют. Trace содержит 10/10 событий; screenshot сохранён.

## Evidence и bindings

Pinned sources при завершении:

- source root: `2416baca49d811127bb3d1451ba66eee6db94192`;
- Console: `66ac7db55a25f56b199b2cb00ad83df3b8dad868`;
- Kernel: `185d3e72309a4362db57cf2e805d1c00a5035909`.

Publication authority: `sha256:f733f69dae599c63d00b89ac55cd832be6021fa346dda27754340c95f3d4f8b1`; graph: `sha256:433f8c5f766bb459f89b2012fed7f0d2a3bc740bfa7f67977cd378d193706fdf`; catalog: `sha256:a12ba94fc87c998049f4c4ccf5aba26b011f9bbb72a7f1f2318476057ea3d5d0`.

Основные пути:

- initial receipt: `/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-mixed-agent-LAqLDG/nuanu-readonly-qa/tests/campaign-runs/run-1dd8b96b2dbddf89-3724e0b5-158e-48ff-b35d-8ab0d6e1a8c8/receipt.json` — `sha256:34fb391c1cc5431c239e18a344dd34e71a18dc539f6eed088f59b2da2683f8ba`;
- focused QA-707 receipt: `/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-mixed-agent-LAqLDG/nuanu-readonly-qa/tests/campaign-runs/run-c60e8a070260ab77-8c7facac-ff76-4c90-b5ff-29bf8e13d080/receipt.json` — `sha256:89b0957ceb891824d5b96d4b644c3be8e41b57b63a1b698d1e6d2df1c25cefc1`;
- current focused plan: `/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-mixed-agent-LAqLDG/nuanu-readonly-qa/tests/qa-campaign.v0.json` — `sha256:0bfd6395e1b0ce61493cc1ead41ff9e1c75a9e5fa952feb0cf11ec6bbabc251e`;
- QA-702 review: `/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-mixed-agent-LAqLDG/nuanu-readonly-qa/.qa-private/findings/campaign-review-d2a3eb3519d41dbea70f14f1183ecebe511959651ae4dce997b7d0896146a2b5.json` — `sha256:d2a3eb3519d41dbea70f14f1183ecebe511959651ae4dce997b7d0896146a2b5`;
- QA-707 harness review: `/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-mixed-agent-LAqLDG/nuanu-readonly-qa/.qa-private/findings/campaign-review-af53870d278ed8bd7396e7861c7eb2ac32cd3efc90d5889e6854084ed24d2f5c.json` — `sha256:af53870d278ed8bd7396e7861c7eb2ac32cd3efc90d5889e6854084ed24d2f5c`;
- final availability observation: `/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-mixed-agent-LAqLDG/final-availability-observation.json` — `sha256:ec9a03ae55807d3fb08a2a99a092bb066117ed3b862a7d5bc5afd1e339f17d27`.

Ticket-specific artifacts:

- QA-702 provider PASS trace: `/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-mixed-agent-LAqLDG/nuanu-readonly-qa/tests/campaign-runs/run-1dd8b96b2dbddf89-3724e0b5-158e-48ff-b35d-8ab0d6e1a8c8/checks/check-65aeaf14cf5f257811a057b0b9cc2d196e3f62627dc437cfcf8c22f0a5648a6f/attempt-1/trace.json` — `sha256:8ac7d981b5e0ce693c5e43bf82fd3a6e84b99fa5de02cdc15f2408f52c33c4a8`;
- QA-702 renewal failed traces: `/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-mixed-agent-LAqLDG/nuanu-readonly-qa/tests/campaign-runs/run-1dd8b96b2dbddf89-3724e0b5-158e-48ff-b35d-8ab0d6e1a8c8/checks/check-5f750bfb9a8aebbb15f5865d11331f82c92baada2f9ed0a241a93afaf9b23b3f/attempt-1/trace.json` — `sha256:94037fce366160dee42132e5a71a0e56e6c28342e57a4580b338942664d507a3`; `/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-mixed-agent-LAqLDG/nuanu-readonly-qa/tests/campaign-runs/run-1dd8b96b2dbddf89-3724e0b5-158e-48ff-b35d-8ab0d6e1a8c8/checks/check-5f750bfb9a8aebbb15f5865d11331f82c92baada2f9ed0a241a93afaf9b23b3f/attempt-2/trace.json` — `sha256:30d7b160efcf603ba68f3d20e2f948145143458e631d8f8f691ec4fd0dcea89d`;
- QA-704 trace: `/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-mixed-agent-LAqLDG/nuanu-readonly-qa/tests/campaign-runs/run-1dd8b96b2dbddf89-3724e0b5-158e-48ff-b35d-8ab0d6e1a8c8/checks/check-aefa4ae4313b8991f9e48c95727a770d10ce1debceec0128dd2d33610a397aa4/attempt-1/trace.json` — `sha256:fbe3d4266b328da95e3f348c8ad5537b4883bc5f623ee49088e4622472cd685b`;
- QA-705 trace: `/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-mixed-agent-LAqLDG/nuanu-readonly-qa/tests/campaign-runs/run-1dd8b96b2dbddf89-3724e0b5-158e-48ff-b35d-8ab0d6e1a8c8/checks/check-dbf498fde7545848d02bd1d510068aedda3e801247c220a4681d590562469e7c/attempt-1/trace.json` — `sha256:94c926e3a26adcd49ffdf742a0cfe78e370d2f5a6228c6cf4d7ec015276b441f`;
- QA-707 focused trace: `/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-mixed-agent-LAqLDG/nuanu-readonly-qa/tests/campaign-runs/run-c60e8a070260ab77-8c7facac-ff76-4c90-b5ff-29bf8e13d080/checks/check-cb35b9f00c503bf96acd66d467db09b7d2f51f261770a560abe70f70c296ef59/attempt-1/trace.json` — `sha256:cd381bb7f34b5b4d4a461fcb74b9d6adbff8202be149425a9e9e30d61abae58d`;
- QA-707 focused screenshot: sibling `final.png` — `sha256:ecc1a22e11d0923faf732d2ad784c53c3a853527f8fff224afe3196efb707946`.

## Механическая история authoring

До успешной публикации были три fail-closed ошибки, не затронувшие managed workspace: внешний `.ts` сначала исполнялся как CJS и отклонил top-level await; затем Kernel отверг multi-target check, потому что registration dialect требует ровно один verifies target и совпадающий subkind; после разделения checks Kernel потребовал дословно сохранить 9 исходных discovery blockers. Все три причины исправлены через caller-owned scripts и owning APIs; managed graph/catalog вручную не редактировались.

## Точка продолжения

Независимые безопасные проверки завершены. Следующая зависимая работа начинается только после конкретной помощи для QA-701, QA-703 или QA-706. При готовности QA-701 нельзя автоматически повторять уже завершённые checks: нужно CAS-обновить current plan из digest `sha256:0bfd6395e1b0ce61493cc1ead41ff9e1c75a9e5fa952feb0cf11ec6bbabc251e`, сделать исполнимым только catalog check `urn:qa:check:461f28eebf3521e4b55df683`, а prior receipts и diagnoses сохранить в кумулятивном checkpoint. Новый receipt сам по себе не является кумулятивным.
