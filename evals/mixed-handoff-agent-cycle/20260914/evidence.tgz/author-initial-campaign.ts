import { readFile } from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";

import {
  QaCampaignPlanV0Schema,
} from "/Users/danilsolomin/projectsnew/qa-agent/.local/mixed-execution-20260914.uzce9U/root/components/console/src/lib/qa-campaign-v0.ts";
import { digestCanonical } from "/Users/danilsolomin/projectsnew/qa-agent/.local/mixed-execution-20260914.uzce9U/root/components/console/src/lib/canonical-digest.ts";
import {
  readCampaignWorkspace,
  writeNewCampaignPlan,
} from "/Users/danilsolomin/projectsnew/qa-agent/.local/mixed-execution-20260914.uzce9U/root/components/console/src/node/qa-campaign-files.ts";
import {
  publishAuthoredCompilation,
  rehashCompilation,
} from "/Users/danilsolomin/projectsnew/qa-agent/.local/mixed-execution-20260914.uzce9U/root/components/console/tests/fixtures/nuanu-readonly/fixture.ts";

type JsonRecord = Record<string, any>;

async function main(): Promise<void> {
const workspacePath = "/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-mixed-agent-LAqLDG/nuanu-readonly-qa";
const baseUrl = "http://127.0.0.1:49160/";
const productSlug = "relay-mixed-retest";
const expectedCandidateSha = "cccccccccccccccccccccccccccccccccccccccc";
const expectedAccountId = "rel-17";

const kernelRoot = process.env.QA_STARTER_REPO;
if (kernelRoot === undefined || !path.isAbsolute(kernelRoot)) {
  throw new Error("QA_STARTER_REPO must name the accepted Kernel checkout");
}
const kernel = await import(pathToFileURL(path.join(kernelRoot, "src", "index.ts")).href) as JsonRecord;
const authority = JSON.parse(await readFile(
  path.join(workspacePath, ".qa-private", "registration-publication.json"),
  "utf8",
)) as JsonRecord;
const workspaceDependencies = kernel.createDefaultWorkspaceKernelDependencies();
const fixture = { workspacePath, kernel, workspaceDependencies, authority } as any;

const next = structuredClone(authority.compilation) as JsonRecord;
const targetByName = new Map<string, JsonRecord>(next.graph.nodes
  .filter((node: JsonRecord) => node.coverageTarget === true)
  .map((node: JsonRecord) => [node.name, node]));
const target = (name: string): JsonRecord => {
  const found = targetByName.get(name);
  if (found === undefined) throw new Error(`Missing registered target: ${name}`);
  return found;
};

const names = {
  api: "Public ticket evidence API",
  numbers: "Numbers page",
  qa701: "QA-701 Original VPN replacement evidence",
  qa702: "QA-702 Supported number renewal",
  qa703: "QA-703 PostgreSQL fee persistence",
  qa704: "QA-704 Masked card API",
  qa705: "QA-705 Original payment history",
  qa706: "QA-706 Original financial chain",
  qa707: "QA-707 Empty numbers UI",
} as const;

interface Definition {
  key: string;
  title: string;
  targetNames: string[];
  executionKind: "automated" | "manual";
  candidatePath: string;
  expectedEvidenceTypes: string[];
  expectation: string;
  handoff?: { reason: string; requiredCapability: string };
}

const definitions: Definition[] = [
  {
    key: "environment-identity",
    title: "Controlled candidate and account identity",
    targetNames: [names.api],
    executionKind: "automated",
    candidatePath: "tests/api/generated/registration.candidates.spec.ts",
    expectedEvidenceTypes: ["http_response"],
    expectation: `The environment identifies candidate ${expectedCandidateSha} and account ${expectedAccountId}.`,
  },
  {
    key: "qa-702-provider-declaration",
    title: "QA-702 provider renewal declaration",
    targetNames: [names.qa702],
    executionKind: "automated",
    candidatePath: "tests/api/generated/registration.candidates.spec.ts",
    expectedEvidenceTypes: ["http_response"],
    expectation: "The current provider number-provider-1 declares supportsRenewal false.",
  },
  {
    key: "qa-702-renewal-response",
    title: "QA-702 unsupported provider has no renewal quote",
    targetNames: [names.qa702],
    executionKind: "automated",
    candidatePath: "tests/api/generated/registration.candidates.spec.ts",
    expectedEvidenceTypes: ["http_response"],
    expectation: "For the same provider number-provider-1, renewalAvailable is false and no quote is present because supportsRenewal is false.",
  },
  {
    key: "qa-701-original-vpn-evidence",
    title: "QA-701 original VPN replacement projection",
    targetNames: [names.qa701],
    executionKind: "automated",
    candidatePath: "tests/api/generated/registration.candidates.spec.ts",
    expectedEvidenceTypes: ["http_response"],
    expectation: "For original operation op-vpn-17 on candidate cccccccccccccccccccccccccccccccccccccccc and account rel-17, durationDays is 30, exactly one reservation-to-assignment link is projected, and the original before/after subscription and assignment records are preserved.",
  },
  {
    key: "qa-703-postgresql-fee-replay",
    title: "QA-703 PostgreSQL fee persistence and replay idempotency",
    targetNames: [names.qa703],
    executionKind: "manual",
    candidatePath: "tests/manual/generated/registration.candidates.md",
    expectedEvidenceTypes: ["database_rows", "replay_trace"],
    expectation: "One qualifying card event persists exactly one PostgreSQL fee-ledger row; replay creates no additional row and does not change its amount.",
    handoff: {
      reason: "The supplied public fixture has no PostgreSQL or event-replay access; public history and mocked tests are not acceptance evidence.",
      requiredCapability: "Read-only PostgreSQL row evidence plus an authorized replay/idempotency observation for the same qualifying event.",
    },
  },
  {
    key: "qa-704-card-details-projection",
    title: "QA-704 card details expose only last4",
    targetNames: [names.qa704],
    executionKind: "automated",
    candidatePath: "tests/api/generated/registration.candidates.spec.ts",
    expectedEvidenceTypes: ["http_response"],
    expectation: "The complete card-details response for rel-17 contains only accountId and last4, with no full PAN or security code field or value.",
  },
  {
    key: "qa-705-original-payment-history",
    title: "QA-705 original operation appears exactly once",
    targetNames: [names.qa705],
    executionKind: "automated",
    candidatePath: "tests/api/generated/registration.candidates.spec.ts",
    expectedEvidenceTypes: ["http_response"],
    expectation: "History for rel-17 contains exactly one operation, the original op-vpn-17, with amount 12, currency TEST, and status completed.",
  },
  {
    key: "qa-706-original-financial-chain",
    title: "QA-706 original treasury and settlement chain",
    targetNames: [names.qa706],
    executionKind: "manual",
    candidatePath: "tests/manual/generated/registration.candidates.md",
    expectedEvidenceTypes: ["financial_ledger", "operation_links"],
    expectation: "The named original treasury, settlement and resulting card-credit operations link and reconcile, including exactly one fee posting.",
    handoff: {
      reason: "The named original references and treasury/settlement/card-credit evidence are not supplied; ordinary purchase history cannot substitute.",
      requiredCapability: "Named original operation references with read-only linkage, amounts, reconciliation and one-fee-posting evidence.",
    },
  },
  {
    key: "qa-707-empty-numbers-rendered-ui",
    title: "QA-707 rendered no-number state",
    targetNames: [names.qa707],
    executionKind: "automated",
    candidatePath: "tests/web/generated/registration.candidates.spec.ts",
    expectedEvidenceTypes: ["screenshot", "trace"],
    expectation: "The rendered Numbers page for the no-number account visibly shows “No numbers yet” and renders zero number cards.",
  },
  {
    key: "numbers-page-surface",
    title: "Numbers page surface is rendered",
    targetNames: [names.numbers],
    executionKind: "automated",
    candidatePath: "tests/web/generated/registration.candidates.spec.ts",
    expectedEvidenceTypes: ["screenshot", "trace"],
    expectation: "The Numbers web surface returns HTTP 200 and renders the Numbers heading.",
  },
];

const authored = definitions.map((definition) => {
  const targets = definition.targetNames.map(target);
  const checkId = kernel.stableId("check", { productSlug, key: definition.key });
  const entryFields = {
    checkId,
    targetIds: targets.map((item) => item.id),
    executionKind: definition.executionKind,
    runnerId: definition.executionKind === "automated" ? "playwright" : "manual-handoff",
    candidatePath: definition.candidatePath,
    requiredSecretRefs: [],
    sideEffectClasses: ["read_only"],
    expectedEvidenceTypes: definition.expectedEvidenceTypes,
    oracle: { state: "resolved", description: definition.expectation },
    provenance: targets[0]!.provenance,
  };
  return {
    definition,
    targets,
    checkId,
    entry: {
      entryId: kernel.stableId("test-catalog-entry", entryFields),
      ...entryFields,
    },
  };
});

next.graph.nodes = next.graph.nodes.filter((node: JsonRecord) => (
  node.kind !== "automated_check" && node.kind !== "manual_check"
));
next.graph.edges = next.graph.edges.filter((edge: JsonRecord) => edge.kind !== "verifies");
next.graph.unresolved = [];
next.catalog.entries = [];
next.strategy.proposedAutomatedChecks = [];
next.strategy.manualHandoffs = [];
next.strategy.unresolvedOracles = [];
next.strategy.blockers = structuredClone(authority.compilation.strategy.blockers);
for (const item of next.coverage.items as JsonRecord[]) {
  item.checkIds = [];
  item.verificationMode = "none";
  item.status = "coverage_gap";
  item.applicability = "applicable";
  item.reason = "Awaiting authored target binding.";
}
next.coverage.unresolved = [];

for (const item of authored) {
  const kind = item.definition.executionKind === "automated" ? "automated_check" : "manual_check";
  next.graph.nodes.push({
    ...item.targets[0],
    id: item.checkId,
    kind,
    coverageTarget: false,
    name: item.definition.title,
  });
  for (const targetNode of item.targets) {
    next.graph.edges.push({
      id: kernel.stableId("edge", { checkId: item.checkId, targetId: targetNode.id }),
      kind: "verifies",
      from: item.checkId,
      to: targetNode.id,
      reviewStatus: "reviewed",
      assuranceLevel: "declared",
      provenance: targetNode.provenance,
      semanticDigest: kernel.digestCanonical("pending"),
    });
    const coverage = next.coverage.items.find((candidate: JsonRecord) => candidate.targetId === targetNode.id);
    if (coverage === undefined) throw new Error(`Missing coverage item for ${targetNode.id}`);
    coverage.checkIds.push(item.checkId);
    coverage.verificationMode = item.definition.executionKind;
    coverage.status = item.definition.executionKind;
    coverage.reason = item.definition.executionKind === "automated"
      ? "Bound to a resolved read-only authored check."
      : item.definition.handoff!.reason;
  }
  next.catalog.entries.push(item.entry);
  if (item.definition.executionKind === "automated") {
    next.strategy.proposedAutomatedChecks.push({
      proposalId: kernel.stableId("proposal", { entryId: item.entry.entryId }),
      catalogEntryId: item.entry.entryId,
      checkId: item.checkId,
      targetIds: item.entry.targetIds,
      reason: `Resolved read-only check for ${item.definition.title}.`,
    });
  } else {
    for (const targetNode of item.targets) {
      next.strategy.manualHandoffs.push({
        handoffId: kernel.stableId("manual-handoff", { entryId: item.entry.entryId, targetId: targetNode.id }),
        catalogEntryId: item.entry.entryId,
        checkId: item.checkId,
        targetId: targetNode.id,
        reason: item.definition.handoff!.reason,
        requiredCapability: item.definition.handoff!.requiredCapability,
      });
    }
  }
}

const authoredByKey = new Map(authored.map((item) => [item.definition.key, item]));
const getAuthored = (key: string) => {
  const item = authoredByKey.get(key);
  if (item === undefined) throw new Error(`Missing authored check ${key}`);
  return item;
};
const addStrategyBlocker = (key: string, code: string, reason: string, recovery: string) => {
  next.strategy.blockers.push({
    blockerId: kernel.stableId("blocker", { productSlug, key }),
    code,
    reason,
    recovery: [recovery],
  });
};
addStrategyBlocker(
  "qa-701-original-evidence-unavailable",
  "ORIGINAL_EVIDENCE_NOT_READY",
  "The original VPN projection currently returns HTTP 503 and cannot yet be executed.",
  "Operator enables the existing original-evidence capability; QA rechecks identity/readiness before executing only the dependent check.",
);
addStrategyBlocker(
  "qa-703-postgresql-replay-unavailable",
  "DATABASE_REPLAY_CAPABILITY_UNAVAILABLE",
  getAuthored("qa-703-postgresql-fee-replay").definition.handoff!.reason,
  getAuthored("qa-703-postgresql-fee-replay").definition.handoff!.requiredCapability,
);
addStrategyBlocker(
  "qa-706-financial-chain-evidence-unavailable",
  "ORIGINAL_FINANCIAL_EVIDENCE_UNAVAILABLE",
  getAuthored("qa-706-original-financial-chain").definition.handoff!.reason,
  getAuthored("qa-706-original-financial-chain").definition.handoff!.requiredCapability,
);
next.strategy.requiredSecretRefs = [];
next.strategy.sideEffectClasses = ["read_only"];
next.strategy.expectedEvidenceTypes = [...new Set(next.catalog.entries.flatMap(
  (entry: JsonRecord) => entry.expectedEvidenceTypes,
))];

const compilation = rehashCompilation(kernel as any, next);
for (const [name, validate] of [
  ["coverage", () => kernel.validateCoverageAgainstGraph(compilation.coverage, compilation.graph)],
  ["catalog", () => kernel.validateTestCatalogAgainstGraph(compilation.catalog, compilation.graph, compilation.coverage)],
  ["strategy", () => kernel.validateTestStrategyDraftAgainstArtifacts(compilation.strategy, compilation)],
] as const) {
  try {
    validate();
  } catch (error) {
    console.error(`Authored ${name} validation failed`, error);
    throw error;
  }
}
const publication = await publishAuthoredCompilation(fixture, compilation, authority);
const workspace = await readCampaignWorkspace(workspacePath);

const executableKeys = [
  "environment-identity",
  "qa-702-provider-declaration",
  "qa-702-renewal-response",
  "qa-704-card-details-projection",
  "qa-705-original-payment-history",
  "qa-707-empty-numbers-rendered-ui",
  "numbers-page-surface",
];
const common = (key: string, severity: "critical" | "high" | "medium" | "low", justification: string) => {
  const item = getAuthored(key);
  return {
    checkId: item.checkId,
    title: item.definition.title,
    targetIds: item.entry.targetIds,
    disposition: "executable" as const,
    sideEffectClass: "read_only" as const,
    preconditions: ["Use only the registered synthetic loopback origin and account rel-17."],
    expectedBehavior: item.definition.expectation,
    severity,
    severityJustification: justification,
  };
};
const checks = [
  {
    ...common("environment-identity", "high", "Candidate/account drift invalidates dependent ticket observations."),
    reproductionSteps: ["GET /api/environment without changing product state."],
    kind: "api" as const,
    surface: "api" as const,
    method: "GET" as const,
    path: "/api/environment",
    assertions: [
      { kind: "status" as const, value: 200 },
      { kind: "json_path" as const, path: "$.candidateSha", value: expectedCandidateSha },
      { kind: "json_path" as const, path: "$.accountId", value: expectedAccountId },
    ],
  },
  {
    ...common("qa-702-provider-declaration", "high", "Provider capability must be the basis for renewal availability."),
    reproductionSteps: ["GET /api/provider and inspect the complete declaration."],
    kind: "api" as const,
    surface: "api" as const,
    method: "GET" as const,
    path: "/api/provider",
    assertions: [
      { kind: "status" as const, value: 200 },
      { kind: "json_path" as const, path: "$", value: { providerId: "number-provider-1", supportsRenewal: false } },
    ],
  },
  {
    ...common("qa-702-renewal-response", "high", "Offering an unsupported renewal can lead users into an invalid purchase flow."),
    reproductionSteps: ["GET /api/renewal for the same declared provider without submitting a purchase."],
    kind: "api" as const,
    surface: "api" as const,
    method: "GET" as const,
    path: "/api/renewal",
    assertions: [
      { kind: "status" as const, value: 200 },
      { kind: "json_path" as const, path: "$", value: { providerId: "number-provider-1", renewalAvailable: false } },
    ],
  },
  {
    ...common("qa-704-card-details-projection", "critical", "A leaked PAN or security code is sensitive payment data exposure."),
    reproductionSteps: ["GET /api/card and compare the complete JSON object, not selected fields only."],
    kind: "api" as const,
    surface: "api" as const,
    method: "GET" as const,
    path: "/api/card",
    assertions: [
      { kind: "status" as const, value: 200 },
      { kind: "json_path" as const, path: "$", value: { accountId: expectedAccountId, last4: "1074" } },
    ],
  },
  {
    ...common("qa-705-original-payment-history", "high", "Duplicate or incorrect completed history misstates the original financial operation."),
    reproductionSteps: ["GET /api/history; do not create or pay for another operation."],
    kind: "api" as const,
    surface: "api" as const,
    method: "GET" as const,
    path: "/api/history",
    assertions: [
      { kind: "status" as const, value: 200 },
      {
        kind: "json_path" as const,
        path: "$",
        value: {
          accountId: expectedAccountId,
          operations: [{ id: "op-vpn-17", amount: 12, currency: "TEST", status: "completed" }],
        },
      },
    ],
  },
  {
    ...common("qa-707-empty-numbers-rendered-ui", "medium", "An incorrect empty state misleads an account that owns no numbers."),
    reproductionSteps: ["Open /numbers in a fresh browser context and inspect the rendered page."],
    kind: "browser" as const,
    surface: "web" as const,
    viewport: { width: 1280, height: 720 },
    operations: [{ kind: "navigate" as const, path: "/numbers" }],
    assertions: [
      { kind: "visible" as const, locator: { kind: "role" as const, role: "status", name: "No numbers yet" } },
      { kind: "count" as const, locator: { kind: "testId" as const, testId: "number-card" }, value: 0 },
      { kind: "response_status" as const, path: "/numbers", value: 200 },
      { kind: "no_console_errors" as const },
    ],
  },
  {
    ...common("numbers-page-surface", "low", "The registered web surface must remain reachable and visibly identifiable."),
    reproductionSteps: ["Open /numbers in a fresh browser context and inspect the rendered heading."],
    kind: "browser" as const,
    surface: "web" as const,
    viewport: { width: 1280, height: 720 },
    operations: [{ kind: "navigate" as const, path: "/numbers" }],
    assertions: [
      { kind: "visible" as const, locator: { kind: "role" as const, role: "heading", name: "Numbers" } },
      { kind: "response_status" as const, path: "/numbers", value: 200 },
      { kind: "no_console_errors" as const },
    ],
  },
];
if (checks.length !== executableKeys.length) throw new Error("Executable check accounting changed");

const blockedKeys = [
  {
    key: "qa-701-original-vpn-evidence",
    reason: "GET /api/vpn/original-evidence currently returns 503 original_evidence_not_ready.",
    recovery: "After the operator confirms readiness, re-read /api/environment and the exact original-evidence route, then execute this check without repeating completed independent checks.",
  },
  {
    key: "qa-703-postgresql-fee-replay",
    reason: "PostgreSQL row and replay capability are not supplied; public history and mocked tests do not prove persistence/idempotency.",
    recovery: "Developer supplies read-only PostgreSQL evidence and an authorized replay observation for the same qualifying event.",
  },
  {
    key: "qa-706-original-financial-chain",
    reason: "Named original treasury, settlement, card-credit and fee-posting evidence is not supplied.",
    recovery: "Developer supplies the named original references and read-only reconciliation evidence including exactly one fee posting.",
  },
];
const blockers = blockedKeys.map(({ key, reason, recovery }) => {
  const item = getAuthored(key);
  return {
    targetId: item.entry.targetIds[0],
    catalogCheckIds: [item.checkId],
    disposition: "blocked" as const,
    reason,
    recovery,
  };
});
const plan = QaCampaignPlanV0Schema.parse({
  schemaVersion: "qa-campaign.v0",
  productSlug,
  graphDigest: workspace.graph.semanticDigest,
  baseUrl,
  checks,
  blockers,
});
const planPath = path.join(workspacePath, "tests", "qa-campaign.v0.json");
await writeNewCampaignPlan(workspacePath, planPath, plan);

console.log(JSON.stringify({
  publicationAuthorityDigest: publication.semanticDigest,
  graphDigest: workspace.graph.semanticDigest,
  catalogDigest: workspace.catalog.semanticDigest,
  planPath,
  planDigest: digestCanonical(plan),
  executableCheckIds: checks.map((check) => check.checkId),
  blockedTargetIds: blockers.map((blocker) => blocker.targetId),
}, null, 2));
}

void main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
