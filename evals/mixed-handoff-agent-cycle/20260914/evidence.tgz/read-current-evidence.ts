import path from "node:path";
import { pathToFileURL } from "node:url";

import { readLatestCampaignEvidence } from "/Users/danilsolomin/projectsnew/qa-agent/.local/mixed-execution-20260914.uzce9U/root/components/console/server/campaign-receipts.mjs";
import { readCampaignWorkspace } from "/Users/danilsolomin/projectsnew/qa-agent/.local/mixed-execution-20260914.uzce9U/root/components/console/src/node/qa-campaign-files.ts";

const workspacePath = "/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-mixed-agent-LAqLDG/nuanu-readonly-qa";

async function main(): Promise<void> {
  const kernelRoot = process.env.QA_STARTER_REPO;
  if (kernelRoot === undefined || !path.isAbsolute(kernelRoot)) {
    throw new Error("QA_STARTER_REPO must name the accepted Kernel checkout");
  }
  const kernel = await import(pathToFileURL(path.join(kernelRoot, "src", "index.ts")).href) as any;
  const workspace = await readCampaignWorkspace(workspacePath);
  const project = workspace.project as any;
  const productSlug = project.product?.slug;
  const allowedBaseUrls = (project.environments ?? []).map((item: any) => item.baseUrl);
  const evidence = await readLatestCampaignEvidence({
    workspaceDir: workspacePath,
    workspaceRoots: [workspacePath],
    project,
    productSlug,
    graph: workspace.graph,
    catalog: workspace.catalog,
    allowedBaseUrls,
    validateDependencyWorkspace: () => kernel.validateWorkspace(
      workspacePath,
      kernel.createDefaultWorkspaceKernelDependencies(),
    ),
  });
  console.log(JSON.stringify(evidence, null, 2));
}

void main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
