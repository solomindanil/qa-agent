# Relay: продолжение 2

Зафиксировано: 2026-09-14T15:30:22Z. **QA-701 теперь проверен: PASS в разрешённом synthetic API-projection scope.** Передача принята после собственной проверки, а не по одному сообщению оператора. Кумулятивно: 4 PASS, 1 ранее установленный agent diagnosis `product_issue`, 2 capability gaps; все 7/7 тикетов сохранены.

## Что изменилось

На `http://127.0.0.1:49160/` наблюдались прежние account `rel-17` и fixture label `cccccccccccccccccccccccccccccccccccccccc`, теперь `originalEvidenceReady=true`. До запуска и после него identity/readiness повторно подтверждены.

Через owning plan API с CAS выполнено только изменение плана: `0bfd6395…` → `sha256:131f367e17639058c53e677eab3f5fbfc11fd56f7023bcba9e30bfcb3cdfabbe`. Существующий catalog oracle не менялся. CLI validation: `ok=true`, 1 исполнимый check, 8 blocked targets, `readyToRun=false` из-за частичного общего покрытия. `qa-product-v0` определил узкий безопасный запуск и отдельное кумулятивное сохранение прежних результатов.

Новый run `run-a6ac25a7eab23115-593f658a-c3ac-4ea7-b453-2b1a074b8abe`: один QA-701 PASS за одну попытку, 8/8 assertions, trace 10/10 событий, 0 dossiers. Immutable runner verdict — `NEEDS_HUMAN` (CLI exit 1), не whole-product PASS. Восемь blocked targets в этом receipt — шесть намеренно не повторённых исторических targets и два реальных capability gaps.

## Полные семь итоговых статусов

| Тикет | Итог и точная область доказательства |
| --- | --- |
| QA-701 | Новый PASS: HTTP 200; `op-vpn-17`, `durationDays=30`; ровно одна `res-17`→`assign-17` связь для этой операции. Before/after содержат одинаковые original subscription `subscription-original-17` со status `expired` и assignment `assignment-original-17` со status `retained`. |
| QA-702 | Сохранён прежний `product_issue` по agent review: provider не поддерживает renewal, но quote предлагается. Runner ранее оставил обе попытки `needs_review`; исправление не заявлено и не ретестировалось. |
| QA-703 | BLOCKED отдельно от QA-706: нет PostgreSQL evidence/replay. Заявленный mocked unit test не предоставлен и не выполнялся QA; не доказывает единственную fee-ledger row и неизменность count/amount после replay. |
| QA-704 | Сохранён прежний API PASS полного ответа: только accountId/last4; без PAN/security code. UI-критерий не добавлялся. |
| QA-705 | Сохранён прежний PASS: исходная `op-vpn-17` ровно один раз, 12 TEST, completed. Новых операций/оплат не было. |
| QA-706 | BLOCKED: нет named original treasury/settlement/card-credit references, linkage/reconciliation и evidence ровно одного fee posting. History не подставлялась вместо них. |
| QA-707 | Сохранён прежний rendered-UI PASS после harness correction: видимый `No numbers yet`, 0 number cards. Первоначальная harness diagnosis также сохранена. |

QA-701 доказывает только оговорённую публичную проекцию. IDs взяты из наблюдаемого synthetic witness; требования 30 дней, одной связи и сохранения records взяты из исходного brief. SQL-атомарность, concurrency, PostgreSQL persistence/replay, реальная покупка и VPN network behavior не проверялись. Fixture label не является attestation реального deployment SHA.

## Evidence и сохранённая история

Actual artifact reader прочитал новый receipt: `sha256:321f0899b6cba35fc896b351bda31b7fd19e2f839a8eaab2ea7ba2dc6c5ebe7e`. [Reader readback](/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-mixed-agent-LAqLDG/continuation-2-evidence-reader-output.json) содержит точный план, receipt и inventory. Trace digest: `sha256:47569371b83fd5a4ea00e3bcb4a48dcadabf461de2e3926175989296dd4ccafc`.

Связь с прежними результатами сохранена в [checkpoint delta](/private/var/folders/wb/zqtxc1qs7sqgspnt3vwlmr640000gn/T/qa-mixed-agent-LAqLDG/CONTINUATION-2-CHECKPOINT-DELTA.json): initial receipt `sha256:34fb391c1cc5431c239e18a344dd34e71a18dc539f6eed088f59b2da2683f8ba` и QA-707 receipt `sha256:89b0957ceb891824d5b96d4b644c3be8e41b57b63a1b698d1e6d2df1c25cefc1` неизменны. Новый receipt сам по себе не является кумулятивным и не переаттестует прежние проверки.

Все 26 inventory artifacts трёх runs проверены по hash/size; frozen original/continuation-1 файлы совпадают с hash. Сохранены 9 graph targets, 10 catalog checks и прежняя публикация. Дополнительных прогонов, source/skill/fixture изменений, tracker writes, DB/replay, финансовых или account/provider действий не было.

## Остаток и следующий шаг

Безопасная независимая работа завершена. Через supervising actor нужны: для QA-703 — read-only PostgreSQL row identity/count/amount до/после того же qualifying event и отдельно авторизованного replay; для QA-706 — named original references с read-only linkage/reconciliation и одним fee posting. Это два отдельных недостающих доказательства, не development defects и не разрешение выполнять финансовые действия. QA-702 остаётся отдельным product issue до исправления и обоснованного ретеста.
