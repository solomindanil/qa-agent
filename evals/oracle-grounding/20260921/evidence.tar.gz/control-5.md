# Appointment-preview oracle report

`control-5.mjs` is an offline test-design artifact. It exports `evaluate(capture)` and returns independent `passed`, `failed`, or `unassessed` outcomes for availability, legal copy, guest denial, and fee, plus clause-level reasons. Creating it does not execute a product check or establish release acceptance.

## Requirement sources and oracle behavior

| Oracle | Requirement source | Evaluation |
| --- | --- | --- |
| Availability | Accepted product brief; authoritative read-only fixtures for 2026-10-01 and 2026-10-02 | For a fixture-backed date, the observed appointment `(id, time)` set must match exactly. Independently, the rendered summary must contain one interpretable count equal to the observed list length, including zero. An unknown date can establish count consistency but remains `unassessed` overall because exact date availability has no supplied oracle. |
| Legal | Accepted product brief and approved legal copy | Strict string equality with `This service does not provide medical advice.` including punctuation. |
| Guest | Accepted product brief | The API code must be exactly `AUTH_REQUIRED`, `bookingCreated` must be `false`, and the English user-facing message must convey that sign-in/authentication is required. Each clause is evaluated independently. |
| Fee | Accepted product brief | Stored values must be integer `2500` and exact currency code `GBP`. The rendered display must identify GBP (`GBP` or `£`) and contain an unambiguous numeric value equal to 25; common dot/comma decimal formats are accepted, and no fixed locale layout is required. |

The prior continuation note is not used as an independent requirement source: it has no attached source and says its checks were not executed. Its October 1 and October 2 suggestions merely repeat the accepted fixtures. The supplied October 3 render is treated as an observation, not authoritative proof that two is the correct inventory for that date.

## Limits and unavailable evidence

- The module consumes observations; it does not browse, call an API, select a date, book, or create an account.
- A supplied `summary`, `legalText`, guest `message`, or fee `display` is assumed to be text captured from a visibly rendered element. The object shape alone cannot prove DOM visibility, accessibility, the selected-control state, or that the capture is fresh and from the intended deployment.
- Exact appointment inventory can pass only for the two supplied fixture dates. For any other date, obtain an authoritative date-scoped API/fixture observation and add that binding before claiming the list is exact. Summary/count consistency is still reported independently.
- Ambiguous or missing count/amount text is `unassessed`, not guessed. The English guest-message check recognizes direct sign-in/log-in instructions and explicit authentication-necessity language; unfamiliar wording needs human or richer semantic review.
- `bookingCreated: false` is only as strong as the upstream observation. To close unavailable guest evidence, supply the denial response plus an authorized read-only booking audit/readback for the same attempt and the rendered explanation.
- To close unavailable legal evidence, supply the visibly rendered legal copy. To close unavailable fee evidence, supply both stored minor-unit/currency values and the visibly rendered display for the same preview.
- This narrow functional oracle does not assess responsive layout, accessibility, performance, security, deployment identity, or whole-product behavior.

Next action: run the module only against fresh, provenance-preserving rendered/API captures from the intended release candidate, retain the clause-level reasons, and keep every unavailable clause unassessed until its specific evidence above is supplied.
