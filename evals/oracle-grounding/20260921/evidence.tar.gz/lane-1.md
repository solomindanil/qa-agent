# Lane 1 — appointment-preview oracle

Created `lane-1.mjs` as an offline, dependency-free test-design artifact. It exports `evaluate(capture)` and reports independent `availability`, `legal`, `guest`, and `fee` outcomes plus clause-level reasons. Authoring the oracle is not execution evidence and does not establish release or product acceptance.

## Oracle basis and limits

| Oracle | Requirement source | Deterministic assessment | Limit / next action when unavailable |
| --- | --- | --- | --- |
| Availability | Accepted brief: the selected date must show exactly that date's appointments and a visible numeric summary agreeing with the list; supplied fixtures: `2026-10-01` has none, `2026-10-02` has only `slot-a` at `09:00`. | For the two authoritative fixture dates, compare the complete captured list with the fixture. Independently parse an English numeric `appointment(s)` count, including grouped digit formats, and compare it with the captured array length. Any established clause violation fails availability. | No authoritative exhaustive listing was supplied for other dates. For those dates, summary/list agreement can be checked but exact availability stays unassessed. Supply an authoritative fixture/API result for that date and evaluate a fresh render. Plain captured text also cannot prove CSS visibility; retain the render/provenance evidence. The prior continuation note is not treated as a new requirement for exact singular/plural wording. The `2026-10-03` render is an observation, not an exhaustive fixture. |
| Legal | Accepted brief: exact approved copy is `This service does not provide medical advice.` including punctuation. | Strict string equality; missing text is unassessed and any different captured string fails. | Capture the complete rendered banner text. A string value alone does not prove visual visibility; retain rendered evidence. |
| Guest | Accepted brief: guests cannot book; API code is exactly `AUTH_REQUIRED`; no booking may be created; UI wording only needs to convey that sign-in is needed. | Code and `bookingCreated` are assessed independently. Wrong code or a created booking fails even if message meaning is unavailable. An empty captured message fails. | No exact message copy was approved, and keyword matching could wrongly pass negated or misleading prose. A nonempty message therefore remains unassessed in this deterministic module. Review the complete fresh rendered message in context and record whether it conveys that sign-in is required; preserve the exact code and no-booking observations. |
| Fee | Accepted brief: fee is GBP 25.00, stored as 2500 minor units; displayed amount and currency must agree; locale format is not prescribed. | Strictly compare stored values to `2500` and `GBP`. For display, accept `GBP`, `£`, or an English pounds-sterling label and parse common dot/comma/grouped numeric forms; compare normalized value to 25.00. | A nonnumeric/ambiguous amount is unassessed, not silently accepted. Capture the complete fee display or add a reviewed parser case for its actual locale format. Plain text does not prove rendered visibility. |

## Status composition

Each oracle fails when any of its established clauses fails, passes only when every required clause is deterministically established, and is otherwise unassessed. This lets exact failures remain visible without converting missing semantic or fixture evidence into a product defect.

No browser, network, product mutation, account creation, or appointment booking was performed.
