# Appointment-preview oracle report

`guided-4.mjs` is an offline, dependency-free test-design oracle. It evaluates each area independently and does not run the product, create an account, book an appointment, or establish release acceptance.

## Oracle grounding

| Oracle | Requirement source | What is evaluated |
| --- | --- | --- |
| Availability | Accepted product brief plus the supplied read-only fixtures | For `2026-10-01`, the rendered set must be empty. For `2026-10-02`, it must contain exactly `slot-a` at `09:00`. The visible English summary is interpreted as a count and must agree with the rendered array, including zero. Summary wording is not required to match the prior agent note. |
| Legal | Accepted product brief's approved legal copy | Rendered text must equal `This service does not provide medical advice.` exactly, including punctuation and spacing. |
| Guest | Accepted product brief | The API code must equal `AUTH_REQUIRED`, `bookingCreated` must be `false`, and the English user-facing message must convey that sign-in/authentication is required. The message oracle accepts several equivalent phrasings and rejects explicit contradictions such as “sign-in is optional” even though they contain the same keywords. |
| Fee | Accepted product brief | Stored amount must be `2500`, currency must be `GBP`, and the rendered display must unambiguously represent GBP 25.00. `GBP` or `£`, currency-before/after-amount, decimal comma/point, and omission of trailing fractional zeros are accepted; locale copy is otherwise unconstrained. |

The prior continuation note is not treated as a requirement source. In particular, it does not make the literal strings `0 appointments` or `1 appointment` mandatory. The statement about the current `2026-10-03` render is an observation, not an accepted complete fixture for that date.

## Result behavior and limits

Each top-level oracle returns `passed`, `failed`, or `unassessed`. Its `reasons` entry separates passed, failed, and unavailable clauses. An observed contradiction makes that oracle `failed`; otherwise any unavailable required clause keeps it `unassessed`; only complete supported evidence produces `passed`.

- `summary`, `legalText`, and `fee.display` are treated as visible rendered-text observations under the input contract. The shape has no independent visibility metadata, so hidden-DOM text cannot be distinguished from visible text.
- Full appointment-set correctness can pass only for `2026-10-01` and `2026-10-02`, whose accepted fixture data is supplied. On another date, a count mismatch can fail, but a matching rendered list and summary remain `unassessed` because no independent expected set proves completeness. Therefore the supplied `2026-10-03` observation is not promoted into a normative oracle.
- Summary parsing covers unambiguous English digit counts (including common grouping separators), zero expressed as “no appointments,” and number words zero through ten. Ambiguous or non-interpretable visible copy fails the summary clause; missing copy is unassessed.
- Guest-message assessment is a bounded English semantic rule, not general natural-language understanding. A non-empty but unclear explanation fails because it does not demonstrably convey the required sign-in meaning; missing message evidence is unassessed.
- The fee display parser supports the expected amount and common GBP locale forms. It does not infer currency from an amount alone and rejects conflicting currency markers.

## Next actions for unavailable evidence

- For an unsupported date, supply an accepted read-only API/fixture appointment set for that exact date, then add it to `AVAILABILITY_FIXTURES` through the product-owned revision process before treating completeness as assessable.
- If rendered visibility must be proven separately, capture a visibility/interactability signal alongside the text; do not reinterpret a DOM-only string as visible evidence.
- For a missing guest clause, capture the denial response, read-only post-attempt booking state, and rendered explanation from the same guest attempt. Do not retry an outcome whose booking state is uncertain.
- For missing fee evidence, capture both the read-only stored/API fee and the visible rendered fee from the same preview/version.
- If valid product copy falls outside the bounded English parsers, review that exact copy against the accepted requirement and revise the oracle deliberately; do not weaken it merely to obtain a pass.

No check in this report has been executed against a live product. Writing this module is test design only and is not a product or release verdict.
