# Appointment-preview oracle contract

`contract-1.mjs` exports `evaluate(capture)` and evaluates the four concerns independently. It is an offline test-design artifact; creating or exercising it is not evidence about a deployed product and does not establish release acceptance.

## Oracle grounding

| Oracle | Requirement source | Deterministic assessment | Limits and next action when unavailable |
| --- | --- | --- | --- |
| Availability | Accepted product brief plus its read-only fixtures: 2026-10-01 has no appointments; 2026-10-02 has exactly `slot-a` at `09:00`. The brief requires a visible summary agreeing with the selected date's count. | A known fixture mismatch fails. A missing/empty summary is respectively unassessed/failed. Each deterministic clause is evaluated before summary interpretation. | The brief does not prescribe summary copy or grammar. The continuation note's `0 appointments` and `1 appointment` strings are not an additional source, so the module does not turn them into exact-copy requirements or a regex classifier. For a nonempty summary, an agent must compare the complete rendered text with the observed array length. For any other date, obtain an authoritative fixture before judging the appointment list. The supplied 2026-10-03 render is an observation, not a normative slot fixture or deployment attestation. |
| Legal | Accepted product brief: approved copy is exactly `This service does not provide medical advice.` including punctuation. | Exact string equality passes; any available mismatch fails. | If rendered banner text is unavailable, capture it from the authorized current preview and evaluate again. |
| Guest | Accepted product brief: a guest receives exact API code `AUTH_REQUIRED`, no booking is created, and the UI conveys that sign-in is needed. | A wrong code, a created booking, or an observed empty explanation fails. Exact code plus `bookingCreated: false` is preserved even when message meaning remains unresolved. | User-facing wording is unrestricted. A nonempty message therefore remains unassessed until an agent reads the complete rendered text and records whether it conveys the sign-in requirement. Do not synthesize keyword matching, create an account, or retry a booking. |
| Fee | Accepted product brief: fee is GBP 25.00, stored as 2500 minor units, and displayed amount/currency agree; locale formatting is not prescribed. | Stored values are exact. The display parser accepts one conservative, unambiguous numeric rendering of 25 (integer, one decimal, or two decimals using `.` or `,`) with `GBP` or `£`; an explicit different amount/currency or missing currency marker fails. | More complex or ambiguous formatting remains unassessed instead of being rejected. Inspect the complete rendered amount and currency and, if it is a valid format not covered by the conservative parser, record that agent assessment or revise the oracle from an authoritative formatting rule. |

## Scope limits

- A failed deterministic clause fails that oracle, while unavailable semantic interpretation does not prevent the other oracles from being assessed.
- Missing or malformed observation fields are `unassessed`; a present observed contradiction is `failed`.
- `reasons` contains the clause-specific basis and preserves the complete summary or guest message when semantic review is required.
- The module performs no browser, API, account, booking, tracker, network, registration, or publication action.
- Passing outputs cover only the supplied clauses and observation; they are not whole-product or release verdicts.
