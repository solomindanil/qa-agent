# Appointment-preview oracle report

## Scope and result

`control-1.mjs` is an offline, dependency-free oracle for fresh rendered/API observations. It does not run the product, book an appointment, create an account, approve a release, or establish product acceptance. No product check was executed while authoring it.

Each area is aggregated independently. A supported failed clause makes that area `failed`; all clauses must be supported and pass for `passed`; otherwise the area is `unassessed`. `reasons` retains clause-level outcomes so missing or uninterpretable evidence in one clause does not hide results from the others.

## Oracle grounding

| Area | Enforced oracle | Requirement source |
| --- | --- | --- |
| Availability | For `2026-10-01`, the rendered appointment set is empty. For `2026-10-02`, it is exactly `slot-a` at `09:00`. For any capture, an interpretable English summary count must agree with the rendered array length, including zero. | Accepted product brief plus its read-only fixture data. |
| Legal | Rendered banner text equals `This service does not provide medical advice.` byte-for-byte, including the final period. | Accepted product brief, identified there as approved legal copy. |
| Guest | API code is exactly `AUTH_REQUIRED`, `bookingCreated` is exactly `false`, and the English message conveys that sign-in/authentication/an account is required. | Accepted product brief. |
| Fee | Stored amount is exactly `2500`, stored currency is exactly `GBP`, and the display contains a numeric value equivalent to 25.00 plus either `GBP` or `£`. Decimal comma/point and omitted or one/two zero decimal places are accepted because locale formatting is not prescribed. | Accepted product brief. |

The prior continuation note is not used as independent authority. Its October 1/2 suggestions happen to be supported by the accepted fixture. The supplied October 3 render is retained as a prior observation, not promoted into a durable exact-availability oracle: it does not identify the two appointments or establish that its count remains the fixture for a future capture.

## Limits and next actions

- `summary` and `legalText` are treated as already-isolated rendered text. The input has no visibility, DOM ownership, selected-control state, or accessibility data, so this module cannot independently prove that text was visible or belonged to the intended banner/selected date. Next action: supply a fresh capture that attests those properties, or check them in an authorized browser lane.
- Exact appointment completeness is assessable only for October 1 and 2. Other dates can still get a clause-level summary/count result, but overall availability remains `unassessed`. Next action: add accepted read-only fixture data (IDs and times) for the specific date before treating its set as passed or failed.
- A nonempty summary with no single parseable English integer adjacent to “appointment(s)” is `unassessed`, not guessed. Next action: inspect the fresh rendered wording and extend the interpreter only if that wording is an accepted format.
- Guest-message meaning uses a bounded English phrase matcher. Alternate wording may require human/source review; do not weaken the API-code or no-booking clauses. Next action: review an unrecognized fresh message against the accepted sign-in requirement, then deliberately extend the matcher if warranted.
- Fee display parsing proves only that the supplied text contains the required value and GBP marker. It does not prove visual prominence, localization quality, or that another conflicting amount is absent elsewhere on the page. Next action: pair the text capture with element identity/visibility evidence in a supported browser check.
- Missing fields or uninterpretable types are `unassessed`; observed empty required text is `failed`. A failure is an oracle result requiring current-environment diagnosis, not by itself a confirmed product bug.

Before release review, run the module against fresh captures from the intended environment, preserve the returned clause evidence, and investigate every `failed` or `unassessed` result. Do not infer whole-preview or release acceptance from four passing statuses.
