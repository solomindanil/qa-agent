# Appointment-preview oracle design (control 4)

This is an offline test-design artifact. No product check was executed, and creating the evaluator does not establish release or product acceptance. Proposed: 4 oracle groups. Executed: 0. Product outcomes therefore remain unassessed until fresh captures are supplied to the evaluator.

## Oracle sources and boundaries

| Oracle | Requirement source | What can pass | Limits and unavailable-evidence action |
| --- | --- | --- | --- |
| Availability | Accepted product brief plus the supplied read-only fixtures | For `2026-10-01`, an empty list and a rendered count of 0. For `2026-10-02`, exactly `slot-a` at `09:00` and a rendered count of 1. Ordering is not prescribed. | Other dates can have list/summary agreement assessed, but their exact slot contents remain `unassessed` without an authoritative dated fixture. Obtain the dated fixture (slot IDs and times), then add it to `AVAILABILITY_FIXTURES` and evaluate a fresh rendered capture. An absent or ambiguous count is `unassessed`; an empty summary is a failure. The supplied `2026-10-03` render is an observation, not a normative fixture, so its two slots are not promoted into an expected list. |
| Legal | Accepted product brief's approved legal copy | Exact character-for-character equality with `This service does not provide medical advice.` | The capture contract contains text, not independent geometry/visibility evidence. The evaluator assumes `legalText` was taken from visibly rendered copy. If that provenance is unavailable, capture the visible banner text afresh; do not substitute DOM presence alone. |
| Guest | Accepted product brief's guest-denial rule | Exact API code `AUTH_REQUIRED`, `bookingCreated === false`, and supported English wording that conveys authentication/sign-in is needed | Each clause is reported separately. Missing API/result/message evidence is `unassessed`; any observed booking creation fails even if the other clauses pass. The message matcher intentionally accepts several English sign-in/authentication/account phrasings but is not a general natural-language oracle. Review unfamiliar but plausibly equivalent wording against the brief and extend the matcher only with an approved interpretation. Do not create an account or booking to obtain evidence. |
| Fee | Accepted product brief's fee rule | `minorUnits === 2500`, stored currency exactly `GBP`, and a rendered fee containing both a supported GBP marker and numeric 25 in common dot/comma locale forms | Locale style itself is not asserted. Spelled-out amounts and unusual currency names are `unassessed` when the numeric amount cannot be interpreted; capture the rendered fee or obtain an approved formatter example before extending the parser. The text-only contract does not independently prove visual prominence or layout. |

The prior continuation note is not an independent requirement or execution record. Its October 1 and October 2 suggestions are included only because the accepted brief and read-only fixtures separately support them. No status is derived from the note.

The evaluator deliberately uses failure-dominant aggregation within compound requirements: one observed contradiction makes that oracle `failed`; otherwise any missing clause keeps it `unassessed`; only all assessed clauses passing produces `passed`. The four oracle groups are evaluated independently, so unavailable availability evidence does not suppress legal, guest, or fee findings.

## Next use

Pass one fresh rendered/API observation matching the documented input shape to `evaluate(capture)`. Retain the returned clause reasons with the capture identity and time. For any `unassessed` clause, collect only the specific missing observation or authoritative fixture named above, then re-evaluate; do not infer whole-product coverage or release acceptance from these four checks.
