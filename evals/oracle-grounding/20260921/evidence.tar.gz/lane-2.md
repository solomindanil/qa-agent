# Appointment-preview oracle report (lane 2)

Artifact: `lane-2.mjs`. It exports dependency-free `evaluate(capture)` and performs no product actions.

## Oracle basis and behavior

| Oracle | Requirement source | Deterministic assessment |
| --- | --- | --- |
| Availability | Accepted product brief; dated read-only fixtures for 2026-10-01 and 2026-10-02 | The fixture-backed dates require an exact rendered list. A nonempty English summary must expose one unambiguous count and agree with the rendered list (or the dated fixture when the list is unavailable). Any established mismatch fails. |
| Legal | Accepted product brief and its approved legal copy | Complete string equality, including punctuation and whitespace, against `This service does not provide medical advice.` |
| Guest | Accepted product brief | Separately requires exact code `AUTH_REQUIRED`, authoritative `bookingCreated === false`, and wording that unambiguously conveys required sign-in. Clear contradiction or an empty explanation fails; wording outside the bounded English interpreter remains unassessed rather than being guessed. |
| Fee | Accepted product brief | Separately requires numeric minor units `2500`, exact stored code `GBP`, displayed value 25, and a GBP marker. `£`, `GBP`, and English pound/sterling names are supported; `.` or `,` decimal punctuation and omitted zero decimals are accepted. |

The prior continuation note is not used as authority for exact summary wording: it has no attached source. Its proposed `0 appointments` and `1 appointment` examples are valid inputs, but the brief requires count agreement rather than those literal strings. The statement about the existing 2026-10-03 render is treated as an observation, not promoted to fixture truth.

## Limits and next actions

- For 2026-10-03 or another date without an independent fixture, the oracle can fail a summary/list mismatch but cannot pass the exact-availability clause. Next action: supply an accepted read-only fixture/API truth for that date, then add it to the fixture map through the reviewed test-design path.
- The capture contract is assumed to contain complete visible rendered text. It does not independently prove CSS visibility, date-selection mechanics, API provenance, or deployment identity. Next action: collect a fresh authorized browser/API observation that explicitly records those facts.
- Guest-message interpretation is deliberately conservative. It recognizes common unambiguous English formulations, rejects clear permission/negation contradictions, and leaves other wording unassessed. Next action: have an authorized agent assess the complete rendered wording in context against the brief; do not weaken the requirement to obtain green.
- Fee parsing covers common unambiguous GBP displays, not every locale or accessibility representation. Multiple/ambiguous numeric candidates remain unassessed. Next action: capture the complete display and its accessible text, then extend the parser only from an approved concrete format.
- Missing or wrongly typed evidence is `unassessed`; an observed value that contradicts a supported requirement is `failed`. Clauses are aggregated independently: any established violation fails its oracle, otherwise unresolved evidence prevents `passed`.

This is an authored test-design artifact only. No checks were executed, no live product was contacted, and it does not establish product or release acceptance.
