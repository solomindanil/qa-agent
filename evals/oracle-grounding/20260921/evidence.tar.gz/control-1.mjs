const STATUS = Object.freeze({
  PASSED: 'passed',
  FAILED: 'failed',
  UNASSESSED: 'unassessed',
});

const EXPECTED_LEGAL_TEXT = 'This service does not provide medical advice.';

const AVAILABILITY_FIXTURES = Object.freeze({
  '2026-10-01': Object.freeze([]),
  '2026-10-02': Object.freeze([
    Object.freeze({ id: 'slot-a', time: '09:00' }),
  ]),
});

const NUMBER_WORDS = Object.freeze({
  zero: 0,
  no: 0,
  one: 1,
  two: 2,
  three: 3,
  four: 4,
  five: 5,
  six: 6,
  seven: 7,
  eight: 8,
  nine: 9,
  ten: 10,
  eleven: 11,
  twelve: 12,
  thirteen: 13,
  fourteen: 14,
  fifteen: 15,
  sixteen: 16,
  seventeen: 17,
  eighteen: 18,
  nineteen: 19,
  twenty: 20,
});

function clause(status, detail, observed) {
  const result = { status, detail };
  if (observed !== undefined) result.observed = observed;
  return result;
}

function combine(clauses) {
  const outcomes = Object.values(clauses).map((item) => item.status);
  if (outcomes.includes(STATUS.FAILED)) return STATUS.FAILED;
  if (outcomes.length > 0 && outcomes.every((status) => status === STATUS.PASSED)) {
    return STATUS.PASSED;
  }
  return STATUS.UNASSESSED;
}

function hasOwn(object, key) {
  return Object.prototype.hasOwnProperty.call(object, key);
}

function parseSummaryCount(summary) {
  if (typeof summary !== 'string') return null;

  // The product material specifies meaning, not a literal summary template.
  // Read an English integer (digits or a small number word) immediately before
  // the appointment noun, allowing one descriptive word such as "available".
  const matches = [];
  const pattern = /(?:^|[^\p{L}\p{N}])((?:\d{1,3}(?:[ ,]\d{3})*|\d+)|(?:zero|no|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty))(?:\s+[a-z]+)?\s+appointments?\b/giu;

  for (const match of summary.matchAll(pattern)) {
    const token = match[1].toLowerCase();
    const value = hasOwn(NUMBER_WORDS, token)
      ? NUMBER_WORDS[token]
      : Number(token.replace(/[ ,]/g, ''));
    if (Number.isSafeInteger(value) && value >= 0) matches.push(value);
  }

  const distinct = [...new Set(matches)];
  return distinct.length === 1 ? distinct[0] : null;
}

function normalizedAppointments(entries) {
  if (!Array.isArray(entries)) return null;
  const normalized = [];
  for (const entry of entries) {
    if (
      entry === null ||
      typeof entry !== 'object' ||
      typeof entry.id !== 'string' ||
      typeof entry.time !== 'string'
    ) {
      return null;
    }
    normalized.push(`${entry.id}\u0000${entry.time}`);
  }
  return normalized.sort();
}

function sameStrings(left, right) {
  return left.length === right.length && left.every((value, index) => value === right[index]);
}

function evaluateAvailability(capture) {
  const clauses = {};
  const appointmentsPresent = hasOwn(capture, 'appointments');

  if (!hasOwn(capture, 'date') || typeof capture.date !== 'string' || capture.date.length === 0) {
    clauses.appointmentSet = clause(
      STATUS.UNASSESSED,
      'No interpretable selected date was supplied, so the date-specific fixture cannot be chosen.',
    );
  } else if (!hasOwn(AVAILABILITY_FIXTURES, capture.date)) {
    clauses.appointmentSet = clause(
      STATUS.UNASSESSED,
      `No accepted appointment fixture is supplied for ${capture.date}; observed rows alone cannot prove that the set is complete.`,
      capture.date,
    );
  } else if (!appointmentsPresent) {
    clauses.appointmentSet = clause(
      STATUS.UNASSESSED,
      'The rendered appointment entries were not supplied.',
    );
  } else {
    const actual = normalizedAppointments(capture.appointments);
    const expected = normalizedAppointments(AVAILABILITY_FIXTURES[capture.date]);
    if (actual === null) {
      clauses.appointmentSet = clause(
        STATUS.UNASSESSED,
        'One or more appointment entries lack a string id or time, so the exact set cannot be interpreted.',
      );
    } else if (sameStrings(actual, expected)) {
      clauses.appointmentSet = clause(
        STATUS.PASSED,
        `The rendered appointments exactly match the accepted fixture for ${capture.date}.`,
        capture.appointments,
      );
    } else {
      clauses.appointmentSet = clause(
        STATUS.FAILED,
        `The rendered appointments do not exactly match the accepted fixture for ${capture.date}.`,
        capture.appointments,
      );
    }
  }

  if (!appointmentsPresent || !Array.isArray(capture.appointments)) {
    clauses.summaryCount = clause(
      STATUS.UNASSESSED,
      'The appointment list was not supplied as an array, so its count cannot be compared with the summary.',
    );
  } else if (!hasOwn(capture, 'summary') || typeof capture.summary !== 'string') {
    clauses.summaryCount = clause(
      STATUS.UNASSESSED,
      'No rendered summary text was supplied.',
    );
  } else if (capture.summary.trim() === '') {
    clauses.summaryCount = clause(
      STATUS.FAILED,
      'The supplied rendered summary is empty; the required visible count summary is absent.',
      capture.summary,
    );
  } else {
    const summaryCount = parseSummaryCount(capture.summary);
    if (summaryCount === null) {
      clauses.summaryCount = clause(
        STATUS.UNASSESSED,
        'The English summary does not expose one unambiguous appointment count that this oracle can interpret.',
        capture.summary,
      );
    } else if (summaryCount === capture.appointments.length) {
      clauses.summaryCount = clause(
        STATUS.PASSED,
        `The summary count (${summaryCount}) agrees with the ${capture.appointments.length} rendered appointment entries.`,
        capture.summary,
      );
    } else {
      clauses.summaryCount = clause(
        STATUS.FAILED,
        `The summary count (${summaryCount}) disagrees with the ${capture.appointments.length} rendered appointment entries.`,
        capture.summary,
      );
    }
  }

  const status = combine(clauses);
  return { status, clauses };
}

function evaluateLegal(capture) {
  let text;
  if (!hasOwn(capture, 'legalText') || typeof capture.legalText !== 'string') {
    text = clause(STATUS.UNASSESSED, 'No rendered consent-banner text was supplied.');
  } else if (capture.legalText === EXPECTED_LEGAL_TEXT) {
    text = clause(
      STATUS.PASSED,
      'The consent-banner text exactly matches the approved legal copy, including punctuation.',
      capture.legalText,
    );
  } else {
    text = clause(
      STATUS.FAILED,
      'The consent-banner text is not an exact match for the approved legal copy.',
      capture.legalText,
    );
  }
  const clauses = { text };
  return { status: combine(clauses), clauses };
}

function evaluateGuest(capture) {
  const clauses = {};
  const guest = capture.guest;

  if (guest === null || typeof guest !== 'object' || Array.isArray(guest)) {
    clauses.code = clause(STATUS.UNASSESSED, 'No guest-booking API observation was supplied.');
    clauses.noBookingCreated = clause(STATUS.UNASSESSED, 'No booking-creation outcome was supplied.');
    clauses.explanation = clause(STATUS.UNASSESSED, 'No user-facing guest explanation was supplied.');
    return { status: combine(clauses), clauses };
  }

  if (!hasOwn(guest, 'code') || typeof guest.code !== 'string') {
    clauses.code = clause(STATUS.UNASSESSED, 'No guest API denial code was supplied.');
  } else if (guest.code === 'AUTH_REQUIRED') {
    clauses.code = clause(STATUS.PASSED, 'The guest API denial code is exactly AUTH_REQUIRED.', guest.code);
  } else {
    clauses.code = clause(STATUS.FAILED, 'The guest API denial code is not exactly AUTH_REQUIRED.', guest.code);
  }

  if (!hasOwn(guest, 'bookingCreated') || typeof guest.bookingCreated !== 'boolean') {
    clauses.noBookingCreated = clause(STATUS.UNASSESSED, 'No boolean booking-created outcome was supplied.');
  } else if (guest.bookingCreated === false) {
    clauses.noBookingCreated = clause(STATUS.PASSED, 'The observation confirms that no booking was created.', false);
  } else {
    clauses.noBookingCreated = clause(STATUS.FAILED, 'A guest booking was created.', true);
  }

  if (!hasOwn(guest, 'message') || typeof guest.message !== 'string') {
    clauses.explanation = clause(STATUS.UNASSESSED, 'No user-facing guest explanation was supplied.');
  } else if (guest.message.trim() === '') {
    clauses.explanation = clause(STATUS.FAILED, 'The user-facing guest explanation is empty.', guest.message);
  } else {
    const signInMeaning = /\b(?:sign[\s-]?in|signed\s+in|log[\s-]?in|logged\s+in|login|authenticate(?:d|ion)?|authentication\s+(?:is\s+)?required|account\s+(?:is\s+)?required|need(?:s|ed)?\s+(?:an?\s+)?account)\b/i;
    if (signInMeaning.test(guest.message)) {
      clauses.explanation = clause(
        STATUS.PASSED,
        'The English explanation contains a clear sign-in, authentication, or account-required cue.',
        guest.message,
      );
    } else {
      clauses.explanation = clause(
        STATUS.FAILED,
        'The English explanation does not convey that sign-in, authentication, or an account is required.',
        guest.message,
      );
    }
  }

  return { status: combine(clauses), clauses };
}

function displayHasGbp(display) {
  return /(?:\bGBP\b|£)/iu.test(display);
}

function displayHasTwentyFive(display) {
  // Formatting is not prescribed: accept 25, 25.0, 25.00 and comma-decimal
  // equivalents, but do not match a substring of another numeric amount.
  return /(?:^|[^\d.,])25(?:[.,]0{1,2})?(?=$|[^\d.,])/u.test(display);
}

function evaluateFee(capture) {
  const clauses = {};
  const fee = capture.fee;

  if (fee === null || typeof fee !== 'object' || Array.isArray(fee)) {
    clauses.minorUnits = clause(STATUS.UNASSESSED, 'No stored fee amount was supplied.');
    clauses.currency = clause(STATUS.UNASSESSED, 'No stored fee currency was supplied.');
    clauses.displayAmount = clause(STATUS.UNASSESSED, 'No displayed fee was supplied.');
    clauses.displayCurrency = clause(STATUS.UNASSESSED, 'No displayed fee was supplied.');
    return { status: combine(clauses), clauses };
  }

  if (!hasOwn(fee, 'minorUnits') || typeof fee.minorUnits !== 'number' || !Number.isFinite(fee.minorUnits)) {
    clauses.minorUnits = clause(STATUS.UNASSESSED, 'No finite numeric minor-unit fee was supplied.');
  } else if (fee.minorUnits === 2500) {
    clauses.minorUnits = clause(STATUS.PASSED, 'The stored fee is exactly 2500 minor units.', fee.minorUnits);
  } else {
    clauses.minorUnits = clause(STATUS.FAILED, 'The stored fee is not 2500 minor units.', fee.minorUnits);
  }

  if (!hasOwn(fee, 'currency') || typeof fee.currency !== 'string') {
    clauses.currency = clause(STATUS.UNASSESSED, 'No stored fee currency was supplied.');
  } else if (fee.currency === 'GBP') {
    clauses.currency = clause(STATUS.PASSED, 'The stored fee currency is exactly GBP.', fee.currency);
  } else {
    clauses.currency = clause(STATUS.FAILED, 'The stored fee currency is not exactly GBP.', fee.currency);
  }

  if (!hasOwn(fee, 'display') || typeof fee.display !== 'string') {
    clauses.displayAmount = clause(STATUS.UNASSESSED, 'No displayed fee text was supplied.');
    clauses.displayCurrency = clause(STATUS.UNASSESSED, 'No displayed fee text was supplied.');
  } else if (fee.display.trim() === '') {
    clauses.displayAmount = clause(STATUS.FAILED, 'The displayed fee text is empty.', fee.display);
    clauses.displayCurrency = clause(STATUS.FAILED, 'The displayed fee text is empty.', fee.display);
  } else {
    clauses.displayAmount = displayHasTwentyFive(fee.display)
      ? clause(STATUS.PASSED, 'The display contains an amount equivalent to 25.00.', fee.display)
      : clause(STATUS.FAILED, 'The display does not contain an amount equivalent to 25.00.', fee.display);
    clauses.displayCurrency = displayHasGbp(fee.display)
      ? clause(STATUS.PASSED, 'The display identifies GBP using GBP or the pound sign.', fee.display)
      : clause(STATUS.FAILED, 'The display does not identify GBP using GBP or the pound sign.', fee.display);
  }

  return { status: combine(clauses), clauses };
}

export function evaluate(capture) {
  const safeCapture = capture !== null && typeof capture === 'object' && !Array.isArray(capture)
    ? capture
    : {};

  const availability = evaluateAvailability(safeCapture);
  const legal = evaluateLegal(safeCapture);
  const guest = evaluateGuest(safeCapture);
  const fee = evaluateFee(safeCapture);

  return {
    availability: availability.status,
    legal: legal.status,
    guest: guest.status,
    fee: fee.status,
    reasons: {
      availability,
      legal,
      guest,
      fee,
    },
  };
}
