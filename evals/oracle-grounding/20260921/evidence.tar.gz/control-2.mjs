const EXACT_LEGAL_COPY = 'This service does not provide medical advice.';

const AVAILABILITY_FIXTURES = new Map([
  ['2026-10-01', []],
  ['2026-10-02', [{ id: 'slot-a', time: '09:00' }]],
]);

function finish(failures, gaps, confirmations) {
  if (failures.length > 0) {
    const gapText = gaps.length > 0 ? ` Unassessed: ${gaps.join(' ')}` : '';
    return { status: 'failed', reason: `Failed: ${failures.join(' ')}${gapText}` };
  }
  if (gaps.length > 0) {
    const confirmedText = confirmations.length > 0
      ? ` Confirmed: ${confirmations.join(' ')}`
      : '';
    return { status: 'unassessed', reason: `Unassessed: ${gaps.join(' ')}${confirmedText}` };
  }
  return { status: 'passed', reason: `Passed: ${confirmations.join(' ')}` };
}

function validAppointments(value) {
  return Array.isArray(value)
    && value.every((entry) => entry !== null
      && typeof entry === 'object'
      && typeof entry.id === 'string'
      && typeof entry.time === 'string');
}

function appointmentKey(entry) {
  return `${entry.id}\u0000${entry.time}`;
}

function sameAppointmentMultiset(actual, expected) {
  const actualKeys = actual.map(appointmentKey).sort();
  const expectedKeys = expected.map(appointmentKey).sort();
  return actualKeys.length === expectedKeys.length
    && actualKeys.every((key, index) => key === expectedKeys[index]);
}

const COUNT_WORDS = new Map([
  ['no', 0], ['zero', 0], ['one', 1], ['two', 2], ['three', 3],
  ['four', 4], ['five', 5], ['six', 6], ['seven', 7], ['eight', 8],
  ['nine', 9], ['ten', 10], ['eleven', 11], ['twelve', 12],
  ['thirteen', 13], ['fourteen', 14], ['fifteen', 15], ['sixteen', 16],
  ['seventeen', 17], ['eighteen', 18], ['nineteen', 19], ['twenty', 20],
]);

function parseGroupedInteger(raw) {
  const compact = raw.trim();
  if (/^\d+$/.test(compact)) return Number(compact);
  if (/^\d{1,3}(?:[,.\s'’\u00a0\u202f]\d{3})+$/.test(compact)) {
    return Number(compact.replace(/[,.\s'’\u00a0\u202f]/g, ''));
  }
  return null;
}

function parseSummaryCount(summary) {
  if (typeof summary !== 'string') return { kind: 'missing' };
  if (summary.trim() === '') return { kind: 'empty' };

  const wordPattern = new RegExp(
    `\\b(${[...COUNT_WORDS.keys()].join('|')})\\s+(?:available\\s+)?appointments?\\b`,
    'i',
  );
  const wordMatch = summary.match(wordPattern);
  if (wordMatch) return { kind: 'count', value: COUNT_WORDS.get(wordMatch[1].toLowerCase()) };

  const beforeLabel = summary.match(
    /(?:^|[^\d])((?:\d{1,3}(?:[,.\s'’\u00a0\u202f]\d{3})+)|\d+)\s+(?:available\s+)?appointments?\b/i,
  );
  if (beforeLabel) {
    const value = parseGroupedInteger(beforeLabel[1]);
    if (value !== null) return { kind: 'count', value };
  }

  const afterLabel = summary.match(
    /\bappointments?\s*(?::|=|-)?\s*((?:\d{1,3}(?:[,.\s'’\u00a0\u202f]\d{3})+)|\d+)(?!\d)/i,
  );
  if (afterLabel) {
    const value = parseGroupedInteger(afterLabel[1]);
    if (value !== null) return { kind: 'count', value };
  }

  return { kind: 'ambiguous' };
}

function evaluateAvailability(capture) {
  const failures = [];
  const gaps = [];
  const confirmations = [];
  const date = capture?.date;
  const appointments = capture?.appointments;
  const fixture = typeof date === 'string' ? AVAILABILITY_FIXTURES.get(date) : undefined;
  const appointmentsAreValid = validAppointments(appointments);

  if (typeof date !== 'string' || date.trim() === '') {
    gaps.push('The selected date is unavailable.');
  } else if (fixture === undefined) {
    gaps.push(`No authoritative appointment fixture was supplied for ${date}, so exact date membership cannot be verified.`);
  }

  if (!appointmentsAreValid) {
    gaps.push('Appointments are missing or do not match the { id, time } observation shape.');
  } else {
    if (fixture !== undefined) {
      if (sameAppointmentMultiset(appointments, fixture)) {
        confirmations.push(`The ${date} appointment set exactly matches its read-only fixture.`);
      } else {
        failures.push(`The ${date} appointment set does not exactly match its read-only fixture.`);
      }
    }

    const summaryCount = parseSummaryCount(capture?.summary);
    if (summaryCount.kind === 'empty') {
      failures.push('The rendered summary is empty.');
    } else if (summaryCount.kind !== 'count') {
      gaps.push('The rendered summary has no unambiguous English appointment count.');
    } else if (summaryCount.value !== appointments.length) {
      failures.push(`The summary reports ${summaryCount.value} appointment(s), but ${appointments.length} appointment(s) were observed.`);
    } else {
      confirmations.push(`The visible summary count agrees with the ${appointments.length} observed appointment(s).`);
    }
  }

  return finish(failures, gaps, confirmations);
}

function evaluateLegal(capture) {
  const legalText = capture?.legalText;
  if (typeof legalText !== 'string') {
    return finish([], ['Rendered legal text is unavailable.'], []);
  }
  if (legalText !== EXACT_LEGAL_COPY) {
    return finish([
      `Rendered legal text is not the exact approved copy ${JSON.stringify(EXACT_LEGAL_COPY)}`,
    ], [], []);
  }
  return finish([], [], ['Rendered legal text exactly matches the approved copy, including punctuation.']);
}

function conveysSignIn(message) {
  return /\bsign(?:ed)?\s*[- ]?\s*in\b/i.test(message)
    || /\blog(?:ged)?\s*[- ]?\s*in\b/i.test(message)
    || /\blogin\b/i.test(message)
    || /\bauthentication\s+(?:is\s+)?required\b/i.test(message)
    || /\bauthenticate\b/i.test(message);
}

function evaluateGuest(capture) {
  const failures = [];
  const gaps = [];
  const confirmations = [];
  const guest = capture?.guest;

  if (guest === null || typeof guest !== 'object' || Array.isArray(guest)) {
    return finish([], ['Guest API and UI observations are unavailable.'], []);
  }

  if (typeof guest.code !== 'string') {
    gaps.push('The guest API denial code is unavailable.');
  } else if (guest.code !== 'AUTH_REQUIRED') {
    failures.push(`The guest API denial code is ${JSON.stringify(guest.code)}, not exactly "AUTH_REQUIRED".`);
  } else {
    confirmations.push('The guest API denial code is exactly "AUTH_REQUIRED".');
  }

  if (typeof guest.bookingCreated !== 'boolean') {
    gaps.push('Whether a booking was created is unavailable.');
  } else if (guest.bookingCreated) {
    failures.push('A booking was created for the guest.');
  } else {
    confirmations.push('No booking was created.');
  }

  if (typeof guest.message !== 'string') {
    gaps.push('The guest-facing explanation is unavailable.');
  } else if (guest.message.trim() === '') {
    failures.push('The guest-facing explanation is empty.');
  } else if (!conveysSignIn(guest.message)) {
    failures.push('The guest-facing explanation does not convey that sign-in is required.');
  } else {
    confirmations.push('The guest-facing explanation conveys that sign-in is required without requiring exact wording.');
  }

  return finish(failures, gaps, confirmations);
}

function parseMoneyNumber(raw) {
  let compact = raw.replace(/[\s'’\u00a0\u202f]/g, '');
  let sign = 1;
  if (compact.startsWith('-')) {
    sign = -1;
    compact = compact.slice(1);
  } else if (compact.startsWith('+')) {
    compact = compact.slice(1);
  }

  if (/^\d+$/.test(compact)) return sign * Number(compact);

  const commaCount = (compact.match(/,/g) || []).length;
  const dotCount = (compact.match(/\./g) || []).length;
  if (commaCount > 0 && dotCount > 0) {
    const decimalSeparator = compact.lastIndexOf(',') > compact.lastIndexOf('.') ? ',' : '.';
    const decimalIndex = compact.lastIndexOf(decimalSeparator);
    const fractionalDigits = compact.length - decimalIndex - 1;
    if (fractionalDigits < 1 || fractionalDigits > 2) return null;
    const normalized = `${compact.slice(0, decimalIndex).replace(/[,.]/g, '')}.${compact.slice(decimalIndex + 1)}`;
    return /^\d+\.\d{1,2}$/.test(normalized) ? sign * Number(normalized) : null;
  }

  const separator = commaCount > 0 ? ',' : dotCount > 0 ? '.' : null;
  if (separator === null) return null;
  const escaped = separator === '.' ? '\\.' : ',';
  const grouped = new RegExp(`^\\d{1,3}(?:${escaped}\\d{3})+$`);
  if (grouped.test(compact)) return sign * Number(compact.replace(/[,.]/g, ''));
  const decimal = new RegExp(`^\\d+${escaped}\\d{1,2}$`);
  if (decimal.test(compact)) return sign * Number(compact.replace(separator, '.'));
  return null;
}

function evaluateFee(capture) {
  const failures = [];
  const gaps = [];
  const confirmations = [];
  const fee = capture?.fee;

  if (fee === null || typeof fee !== 'object' || Array.isArray(fee)) {
    return finish([], ['Structured fee and rendered fee observations are unavailable.'], []);
  }

  if (!Number.isInteger(fee.minorUnits)) {
    gaps.push('The stored integer minor-unit amount is unavailable.');
  } else if (fee.minorUnits !== 2500) {
    failures.push(`The stored fee is ${fee.minorUnits} minor units, not 2500.`);
  } else {
    confirmations.push('The stored fee is 2500 minor units.');
  }

  if (typeof fee.currency !== 'string') {
    gaps.push('The structured fee currency is unavailable.');
  } else if (fee.currency !== 'GBP') {
    failures.push(`The structured fee currency is ${JSON.stringify(fee.currency)}, not exactly "GBP".`);
  } else {
    confirmations.push('The structured fee currency is exactly "GBP".');
  }

  if (typeof fee.display !== 'string') {
    gaps.push('The rendered fee is unavailable.');
    return finish(failures, gaps, confirmations);
  }
  if (fee.display.trim() === '') {
    failures.push('The rendered fee is empty.');
    return finish(failures, gaps, confirmations);
  }

  const hasGbpMarker = /£|\bGBP\b|\b(?:British\s+)?pounds?(?:\s+sterling)?\b/i.test(fee.display);
  const hasConflictingMarker = /[$€¥₹]|\b(?:USD|EUR|JPY|CAD|AUD|CHF|CNY|INR)\b/i.test(fee.display);
  if (!hasGbpMarker) {
    failures.push('The rendered fee does not identify GBP with GBP, £, or pounds.');
  } else if (hasConflictingMarker) {
    failures.push('The rendered fee contains a conflicting currency marker.');
  } else {
    confirmations.push('The rendered fee identifies GBP without prescribing a locale format.');
  }

  const numericTokens = fee.display.match(/[+-]?\d(?:[\d.,'’\u00a0\u202f ]*\d)?/g) || [];
  const parsedAmounts = numericTokens
    .map(parseMoneyNumber)
    .filter((value) => value !== null && Number.isFinite(value));
  const distinctAmounts = [...new Set(parsedAmounts)];

  if (distinctAmounts.length === 0) {
    gaps.push('The rendered fee has no supported unambiguous numeric amount.');
  } else if (distinctAmounts.length > 1) {
    gaps.push(`The rendered fee contains multiple numeric amounts (${distinctAmounts.join(', ')}), so the applicable amount is ambiguous.`);
  } else if (distinctAmounts[0] !== 25) {
    failures.push(`The rendered fee amount is ${distinctAmounts[0]}, not GBP 25.00.`);
  } else {
    confirmations.push('The rendered amount is GBP 25.00 in an accepted locale-neutral form.');
  }

  return finish(failures, gaps, confirmations);
}

export function evaluate(capture) {
  const availability = evaluateAvailability(capture);
  const legal = evaluateLegal(capture);
  const guest = evaluateGuest(capture);
  const fee = evaluateFee(capture);

  return {
    availability: availability.status,
    legal: legal.status,
    guest: guest.status,
    fee: fee.status,
    reasons: {
      availability: availability.reason,
      legal: legal.reason,
      guest: guest.reason,
      fee: fee.reason,
    },
  };
}
