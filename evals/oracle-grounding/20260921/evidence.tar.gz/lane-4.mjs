const EXPECTED_LEGAL = 'This service does not provide medical advice.'
const EXPECTED_GUEST_CODE = 'AUTH_REQUIRED'
const EXPECTED_MINOR_UNITS = 2500
const EXPECTED_CURRENCY = 'GBP'

const FIXTURES = {
  '2026-10-01': { appointments: [] },
  '2026-10-02': { appointments: [{ id: 'slot-a', time: '09:00' }] },
  '2026-10-03': { count: 2 },
}

const hasOwn = (value, key) =>
  value !== null && typeof value === 'object' && Object.prototype.hasOwnProperty.call(value, key)

function finish(passed, failed, unassessed) {
  const status = failed.length ? 'failed' : unassessed.length ? 'unassessed' : 'passed'
  return {
    status,
    reasons: [
      ...failed.map((reason) => `FAILED: ${reason}`),
      ...unassessed.map((reason) => `UNASSESSED: ${reason}`),
      ...passed.map((reason) => `PASSED: ${reason}`),
    ],
  }
}

function sameAppointment(actual, expected) {
  return (
    actual !== null &&
    typeof actual === 'object' &&
    actual.id === expected.id &&
    actual.time === expected.time
  )
}

function summaryCount(summary) {
  const normalized = summary.normalize('NFKC').replace(/[\u00a0\u202f]/g, ' ').trim()
  const words = {
    no: 0,
    none: 0,
    zero: 0,
    one: 1,
    two: 2,
    three: 3,
    four: 4,
    five: 5,
    six: 6,
    seven: 7,
    eight: 8,
    nine: 9,
    ten: 10,
  }
  const value = '(no|none|zero|one|two|three|four|five|six|seven|eight|nine|ten|\\d[\\d, ]*)'
  const before = normalized.match(new RegExp(`\\b${value}\\s+appointments?\\b`, 'i'))
  const after = normalized.match(new RegExp(`\\bappointments?\\s*(?::|=|-)?\\s*${value}\\b`, 'i'))
  const token = before?.[1] ?? after?.[1]

  if (token === undefined) return null
  const lower = token.toLowerCase()
  if (hasOwn(words, lower)) return words[lower]
  const digits = token.replace(/[ ,]/g, '')
  if (!/^\d+$/.test(digits)) return null
  const count = Number(digits)
  return Number.isSafeInteger(count) ? count : null
}

function evaluateAvailability(capture) {
  const passed = []
  const failed = []
  const unassessed = []
  const date = hasOwn(capture, 'date') && typeof capture.date === 'string' ? capture.date : null
  const appointments = hasOwn(capture, 'appointments') && Array.isArray(capture.appointments)
    ? capture.appointments
    : null

  if (date === null || date.length === 0) {
    unassessed.push('the selected date was not captured')
  }
  if (appointments === null) {
    unassessed.push('the rendered appointment collection was not captured as an array')
  }

  if (date && appointments) {
    const fixture = FIXTURES[date]
    if (!fixture) {
      unassessed.push(`no authoritative appointment fixture was supplied for ${date}`)
    } else if ('appointments' in fixture) {
      const exact =
        appointments.length === fixture.appointments.length &&
        fixture.appointments.every((expected, index) => sameAppointment(appointments[index], expected))
      if (exact) {
        passed.push(`${date} shows exactly the supplied appointment fixture`)
      } else {
        failed.push(`${date} appointments do not exactly match the supplied fixture`)
      }
    } else if (appointments.length === fixture.count) {
      passed.push(`${date} shows the supplied count of ${fixture.count} appointments`)
    } else {
      failed.push(`${date} shows ${appointments.length} appointments; the supplied render requires ${fixture.count}`)
    }
  }

  if (!hasOwn(capture, 'summary') || capture.summary === null || capture.summary === undefined) {
    unassessed.push('summary text was not captured')
  } else if (typeof capture.summary !== 'string') {
    unassessed.push('summary evidence is not text')
  } else if (capture.summary.trim().length === 0) {
    failed.push('the captured rendered summary is empty')
  } else if (appointments === null) {
    unassessed.push('summary agreement cannot be checked without the rendered appointments array')
  } else {
    const count = summaryCount(capture.summary)
    if (count === null) {
      unassessed.push('the English summary count could not be interpreted safely')
    } else if (count !== appointments.length) {
      failed.push(`summary says ${count} appointments but ${appointments.length} were captured`)
    } else {
      passed.push(`summary agrees with the rendered count of ${appointments.length}`)
    }
  }

  return finish(passed, failed, unassessed)
}

function evaluateLegal(capture) {
  const passed = []
  const failed = []
  const unassessed = []

  if (!hasOwn(capture, 'legalText') || capture.legalText === null || capture.legalText === undefined) {
    unassessed.push('consent-banner text was not captured')
  } else if (typeof capture.legalText !== 'string') {
    unassessed.push('consent-banner evidence is not text')
  } else if (capture.legalText === EXPECTED_LEGAL) {
    passed.push('consent banner matches the approved legal copy exactly')
  } else {
    failed.push('consent banner does not match the approved legal copy exactly')
  }

  return finish(passed, failed, unassessed)
}

function conveysSignInRequired(message) {
  const text = message
    .normalize('NFKC')
    .toLowerCase()
    .replace(/[‐‑‒–—-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
  return [
    /\b(?:must|need(?:s)? to|have to|required to|please) (?:sign|log) in\b/,
    /\b(?:sign|log) in (?:is )?(?:required|needed)\b/,
    /\b(?:sign|log) in to (?:book|continue|proceed)\b/,
    /\bauthentication (?:is )?(?:required|needed)\b/,
    /\b(?:must|need(?:s)? to|have to) (?:be )?authenticated\b/,
  ].some((pattern) => pattern.test(text))
}

function evaluateGuest(capture) {
  const passed = []
  const failed = []
  const unassessed = []
  const guest = hasOwn(capture, 'guest') && capture.guest !== null && typeof capture.guest === 'object'
    ? capture.guest
    : null

  if (!guest) {
    unassessed.push('guest API/UI evidence was not captured')
    return finish(passed, failed, unassessed)
  }

  if (!hasOwn(guest, 'code') || guest.code === null || guest.code === undefined) {
    unassessed.push('guest denial code was not captured')
  } else if (guest.code === EXPECTED_GUEST_CODE) {
    passed.push(`guest denial code is exactly ${EXPECTED_GUEST_CODE}`)
  } else {
    failed.push(`guest denial code is not exactly ${EXPECTED_GUEST_CODE}`)
  }

  if (!hasOwn(guest, 'bookingCreated') || typeof guest.bookingCreated !== 'boolean') {
    unassessed.push('booking creation state was not captured as a boolean')
  } else if (guest.bookingCreated) {
    failed.push('a booking was created for the guest')
  } else {
    passed.push('no guest booking was created')
  }

  if (!hasOwn(guest, 'message') || guest.message === null || guest.message === undefined) {
    unassessed.push('user-facing guest explanation was not captured')
  } else if (typeof guest.message !== 'string') {
    unassessed.push('user-facing guest explanation is not text')
  } else if (guest.message.trim().length === 0) {
    failed.push('user-facing guest explanation is empty')
  } else if (conveysSignInRequired(guest.message)) {
    passed.push('user-facing explanation clearly conveys that sign-in is required')
  } else {
    unassessed.push('the explanation needs human semantic review; the bounded English matcher could not confirm its meaning')
  }

  return finish(passed, failed, unassessed)
}

function minorUnitInterpretations(token) {
  const compact = token.replace(/[\s\u00a0\u202f'’]/g, '')
  if (!/^\d[\d.,]*$/.test(compact)) return []
  const interpretations = new Set()
  const grouped = compact.replace(/[.,]/g, '')
  if (/^\d+$/.test(grouped)) {
    const major = Number(grouped)
    if (Number.isSafeInteger(major)) interpretations.add(major * 100)
  }

  const lastComma = compact.lastIndexOf(',')
  const lastDot = compact.lastIndexOf('.')
  const decimalAt = Math.max(lastComma, lastDot)
  if (decimalAt !== -1) {
    const whole = compact.slice(0, decimalAt).replace(/[.,]/g, '')
    const fraction = compact.slice(decimalAt + 1)
    if (/^\d+$/.test(whole) && /^\d{1,2}$/.test(fraction)) {
      const minor = Number(whole) * 100 + Number(fraction.padEnd(2, '0'))
      if (Number.isSafeInteger(minor)) interpretations.add(minor)
    }
  }
  return [...interpretations]
}

function displayedMinorUnits(display) {
  const tokens = display.normalize('NFKC').match(/\d+(?:[\s\u00a0\u202f.,'’]\d+)*/g) ?? []
  return tokens.flatMap(minorUnitInterpretations)
}

function evaluateFee(capture) {
  const passed = []
  const failed = []
  const unassessed = []
  const fee = hasOwn(capture, 'fee') && capture.fee !== null && typeof capture.fee === 'object'
    ? capture.fee
    : null

  if (!fee) {
    unassessed.push('fee storage/display evidence was not captured')
    return finish(passed, failed, unassessed)
  }

  if (!hasOwn(fee, 'minorUnits') || fee.minorUnits === null || fee.minorUnits === undefined) {
    unassessed.push('stored minor-unit amount was not captured')
  } else if (fee.minorUnits === EXPECTED_MINOR_UNITS) {
    passed.push(`stored amount is exactly ${EXPECTED_MINOR_UNITS} minor units`)
  } else {
    failed.push(`stored amount is not exactly ${EXPECTED_MINOR_UNITS} minor units`)
  }

  if (!hasOwn(fee, 'currency') || fee.currency === null || fee.currency === undefined) {
    unassessed.push('stored currency was not captured')
  } else if (fee.currency === EXPECTED_CURRENCY) {
    passed.push(`stored currency is exactly ${EXPECTED_CURRENCY}`)
  } else {
    failed.push(`stored currency is not exactly ${EXPECTED_CURRENCY}`)
  }

  if (!hasOwn(fee, 'display') || fee.display === null || fee.display === undefined) {
    unassessed.push('displayed fee text was not captured')
  } else if (typeof fee.display !== 'string') {
    unassessed.push('displayed fee evidence is not text')
  } else if (fee.display.trim().length === 0) {
    failed.push('displayed fee text is empty')
  } else {
    const display = fee.display.normalize('NFKC')
    const hasGbp = /£|\bGBP\b|\b(?:British\s+)?pounds?(?:\s+sterling)?\b|\bsterling\b/i.test(display)
    const hasOtherCurrency = /\b(?:USD|EUR|JPY|CAD|AUD|CHF)\b|[$€¥]/i.test(display)
    if (hasOtherCurrency) {
      failed.push('displayed fee contains a non-GBP currency marker')
    } else if (hasGbp) {
      passed.push('displayed fee conveys GBP')
    } else {
      failed.push('displayed fee does not convey GBP')
    }

    const amounts = displayedMinorUnits(display)
    if (amounts.length === 0) {
      unassessed.push('displayed amount could not be interpreted by the locale-tolerant numeric parser')
    } else if (amounts.includes(EXPECTED_MINOR_UNITS)) {
      passed.push('displayed amount agrees with GBP 25.00')
    } else {
      failed.push('displayed numeric amount does not agree with GBP 25.00')
    }
  }

  return finish(passed, failed, unassessed)
}

export function evaluate(capture) {
  const input = capture !== null && typeof capture === 'object' ? capture : {}
  const availability = evaluateAvailability(input)
  const legal = evaluateLegal(input)
  const guest = evaluateGuest(input)
  const fee = evaluateFee(input)

  return {
    availability: availability.status,
    legal: legal.status,
    guest: guest.status,
    fee: fee.status,
    reasons: {
      availability: availability.reasons,
      legal: legal.reasons,
      guest: guest.reasons,
      fee: fee.reasons,
    },
  }
}
