const EXPECTED_LEGAL_TEXT = 'This service does not provide medical advice.';

const FIXTURES = new Map([
  ['2026-10-01', []],
  ['2026-10-02', [{ id: 'slot-a', time: '09:00' }]],
]);

const own = (value, key) =>
  value !== null && typeof value === 'object' &&
  Object.prototype.hasOwnProperty.call(value, key);

function clause(name, outcome, detail) {
  return { clause: name, outcome, detail };
}

function result(clauses) {
  const outcome = clauses.some((item) => item.outcome === 'failed')
    ? 'failed'
    : clauses.some((item) => item.outcome === 'unassessed')
      ? 'unassessed'
      : 'passed';
  return { outcome, clauses };
}

const NUMBER_WORDS = new Map([
  ['zero', 0],
  ['one', 1],
  ['two', 2],
  ['three', 3],
  ['four', 4],
  ['five', 5],
  ['six', 6],
  ['seven', 7],
  ['eight', 8],
  ['nine', 9],
  ['ten', 10],
]);

function parseGroupedInteger(raw) {
  const compact = raw.replace(/[\u00a0\u202f]/g, ' ').trim();
  if (/^\d+$/.test(compact)) return Number(compact);
  if (/^\d{1,3}(?:[ ,.]\d{3})+$/.test(compact)) {
    return Number(compact.replace(/[ ,.]\s*/g, ''));
  }
  return null;
}

function summaryCount(text) {
  const normalized = text.toLowerCase().replace(/[\u00a0\u202f]/g, ' ');
  const claims = [];
  let interpretationUnavailable = false;

  if (/\bno\s+(?:available\s+)?appointments?\b/.test(normalized)) claims.push(0);

  const wordPattern = /\b(zero|one|two|three|four|five|six|seven|eight|nine|ten)\s+(?:available\s+)?appointments?\b/g;
  for (const match of normalized.matchAll(wordPattern)) {
    const prefix = normalized.slice(Math.max(0, match.index - 18), match.index);
    if (/\b(?:not|isn't|aren't|is\s+not|are\s+not)\s*$/.test(prefix)) {
      interpretationUnavailable = true;
    } else {
      claims.push(NUMBER_WORDS.get(match[1]));
    }
  }

  const numericPattern = /(?:^|[^\d])((?:\d{1,3}(?:[ ,.\u00a0\u202f]\d{3})+)|\d+)\s+(?:available\s+)?appointments?\b/gi;
  for (const match of normalized.matchAll(numericPattern)) {
    const valueStart = (match.index ?? 0) + match[0].indexOf(match[1]);
    const prefix = normalized.slice(Math.max(0, valueStart - 18), valueStart);
    const parsed = parseGroupedInteger(match[1]);
    if (/\b(?:not|isn't|aren't|is\s+not|are\s+not)\s*$/.test(prefix) || parsed === null) {
      interpretationUnavailable = true;
    } else {
      claims.push(parsed);
    }
  }

  const reversePattern = /\bappointments?\s*(?:available\s*)?(?:[:=()\-]\s*|are\s+)((?:\d{1,3}(?:[ ,.\u00a0\u202f]\d{3})+)|\d+)\b/gi;
  for (const match of normalized.matchAll(reversePattern)) {
    const parsed = parseGroupedInteger(match[1]);
    if (parsed === null) interpretationUnavailable = true;
    else claims.push(parsed);
  }

  const unique = [...new Set(claims)];
  if (interpretationUnavailable || unique.length !== 1) return null;
  return unique[0];
}

function availabilityClauses(capture) {
  const clauses = [];
  const dateAvailable = own(capture, 'date') && typeof capture.date === 'string';
  const appointmentsAvailable = own(capture, 'appointments') && Array.isArray(capture.appointments);

  if (!dateAvailable) {
    clauses.push(clause('fixture appointments for selected date', 'unassessed', 'No usable selected-date observation was supplied.'));
  } else if (!FIXTURES.has(capture.date)) {
    clauses.push(clause('fixture appointments for selected date', 'unassessed', `No authoritative appointment fixture is supplied for ${capture.date}.`));
  } else if (!appointmentsAvailable) {
    clauses.push(clause('fixture appointments for selected date', 'unassessed', 'No usable rendered appointment list was supplied.'));
  } else {
    const expected = FIXTURES.get(capture.date);
    const matches = expected.length === capture.appointments.length && expected.every((item, index) => {
      const actual = capture.appointments[index];
      return actual !== null && typeof actual === 'object' && actual.id === item.id && actual.time === item.time;
    });
    clauses.push(clause(
      'fixture appointments for selected date',
      matches ? 'passed' : 'failed',
      matches
        ? `The rendered list matches the accepted fixture for ${capture.date}.`
        : `The rendered list does not match the accepted fixture for ${capture.date}.`,
    ));
  }

  if (!appointmentsAvailable) {
    clauses.push(clause('visible summary agrees with rendered count', 'unassessed', 'No usable rendered appointment list was supplied for a count comparison.'));
  } else if (!own(capture, 'summary') || capture.summary === null || capture.summary === undefined || typeof capture.summary !== 'string') {
    clauses.push(clause('visible summary agrees with rendered count', 'unassessed', 'No usable rendered summary observation was supplied.'));
  } else if (capture.summary.length === 0 || capture.summary.trim().length === 0) {
    clauses.push(clause('visible summary agrees with rendered count', 'failed', 'The observed rendered summary is empty.'));
  } else {
    const interpreted = summaryCount(capture.summary);
    if (interpreted === null) {
      clauses.push(clause('visible summary agrees with rendered count', 'unassessed', 'The English summary does not yield one unambiguous appointment count.'));
    } else {
      const matches = interpreted === capture.appointments.length;
      clauses.push(clause(
        'visible summary agrees with rendered count',
        matches ? 'passed' : 'failed',
        matches
          ? `The summary count (${interpreted}) agrees with ${capture.appointments.length} rendered appointment(s).`
          : `The summary count (${interpreted}) disagrees with ${capture.appointments.length} rendered appointment(s).`,
      ));
    }
  }

  return clauses;
}

function legalClauses(capture) {
  if (!own(capture, 'legalText') || capture.legalText === null || capture.legalText === undefined || typeof capture.legalText !== 'string') {
    return [clause('exact approved consent copy', 'unassessed', 'No usable rendered legal-text observation was supplied.')];
  }
  const matches = capture.legalText === EXPECTED_LEGAL_TEXT;
  return [clause(
    'exact approved consent copy',
    matches ? 'passed' : 'failed',
    matches ? 'The legal text exactly matches the approved copy.' : 'The observed legal text is not an exact character-for-character match.',
  )];
}

function interpretSignInMessage(message) {
  const normalized = message.toLowerCase().replace(/[\u2010-\u2015]/g, '-').replace(/\s+/g, ' ').trim();
  if (!normalized) return false;

  const contradictsRequirement = [
    /\b(?:do\s+not|don't)\s+need\s+to\s+(?:sign|log)[ -]?in\b/,
    /\b(?:sign|log)[ -]?in\s+(?:is\s+)?(?:not\s+required|optional)\b/,
    /\bwithout\s+(?:signing|logging)[ -]?in\b/,
    /\bcontinue\s+as\s+(?:a\s+)?guest\b/,
    /\bguests?\s+(?:can|may)\s+book\b/,
  ].some((pattern) => pattern.test(normalized));
  if (contradictsRequirement) return false;

  const conveysRequirement = [
    /\b(?:sign|log)[ -]?in\s+(?:is\s+)?(?:required|needed|necessary)\b/,
    /\b(?:must|need\s+to|have\s+to|please|required\s+to)\s+(?:sign|log)[ -]?in\b/,
    /\b(?:sign|log)[ -]?in\s+(?:to|before|in\s+order\s+to)\b/,
    /\bauthentication\s+(?:is\s+)?required\b/,
    /\b(?:an\s+)?account\s+(?:is\s+)?required\s+(?:to|before|for)\b/,
    /\bonly\s+(?:signed|logged)[ -]?in\s+(?:users?|patients?)\s+(?:can|may)\s+book\b/,
  ].some((pattern) => pattern.test(normalized));
  return conveysRequirement ? true : null;
}

function guestClauses(capture) {
  if (!own(capture, 'guest') || capture.guest === null || typeof capture.guest !== 'object' || Array.isArray(capture.guest)) {
    return [
      clause('API denial code', 'unassessed', 'No usable guest API observation was supplied.'),
      clause('no booking created', 'unassessed', 'No usable guest booking outcome was supplied.'),
      clause('user-facing sign-in explanation', 'unassessed', 'No usable guest message observation was supplied.'),
    ];
  }

  const guest = capture.guest;
  const clauses = [];
  if (!own(guest, 'code') || guest.code === null || guest.code === undefined || typeof guest.code !== 'string') {
    clauses.push(clause('API denial code', 'unassessed', 'No usable API denial-code observation was supplied.'));
  } else {
    clauses.push(clause('API denial code', guest.code === 'AUTH_REQUIRED' ? 'passed' : 'failed', guest.code === 'AUTH_REQUIRED' ? 'The API code exactly matches AUTH_REQUIRED.' : `Observed API code ${JSON.stringify(guest.code)} instead of AUTH_REQUIRED.`));
  }

  if (!own(guest, 'bookingCreated') || typeof guest.bookingCreated !== 'boolean') {
    clauses.push(clause('no booking created', 'unassessed', 'No boolean booking-created outcome was supplied.'));
  } else {
    clauses.push(clause('no booking created', guest.bookingCreated === false ? 'passed' : 'failed', guest.bookingCreated === false ? 'The observation confirms that no booking was created.' : 'A booking was created for a guest.'));
  }

  if (!own(guest, 'message') || guest.message === null || guest.message === undefined || typeof guest.message !== 'string') {
    clauses.push(clause('user-facing sign-in explanation', 'unassessed', 'No usable rendered guest message was supplied.'));
  } else {
    const interpretation = interpretSignInMessage(guest.message);
    clauses.push(clause(
      'user-facing sign-in explanation',
      interpretation === true ? 'passed' : interpretation === false ? 'failed' : 'unassessed',
      interpretation === true
        ? 'The English message conveys that sign-in is required.'
        : interpretation === false
          ? 'The observed message is empty or contradicts the sign-in requirement.'
          : 'The English message cannot be classified confidently as conveying a sign-in requirement.',
    ));
  }
  return clauses;
}

function parseLocalizedAmountToMinor(raw) {
  let value = raw.replace(/[\u00a0\u202f\s'\u2019]/g, '');
  let sign = 1;
  if (value.startsWith('+')) value = value.slice(1);
  else if (value.startsWith('-')) {
    sign = -1;
    value = value.slice(1);
  }
  if (!/^\d[\d.,]*$/.test(value)) return null;

  const lastDot = value.lastIndexOf('.');
  const lastComma = value.lastIndexOf(',');
  const separators = [...value].filter((character) => character === '.' || character === ',');
  let integerPart = value;
  let fractionPart = '';

  if (separators.length > 0) {
    const decimalSeparator = lastDot > lastComma ? '.' : ',';
    const lastSeparator = Math.max(lastDot, lastComma);
    const tailLength = value.length - lastSeparator - 1;
    if (tailLength === 1 || tailLength === 2) {
      integerPart = value.slice(0, lastSeparator).replace(/[.,]/g, '');
      fractionPart = value.slice(lastSeparator + 1);
    } else if (/^\d{1,3}(?:[.,]\d{3})+$/.test(value)) {
      integerPart = value.replace(/[.,]/g, '');
    } else {
      return null;
    }
    void decimalSeparator;
  }

  if (!/^\d+$/.test(integerPart) || (fractionPart && !/^\d{1,2}$/.test(fractionPart))) return null;
  const major = Number(integerPart);
  const fractional = fractionPart ? Number(fractionPart.padEnd(2, '0')) : 0;
  if (!Number.isSafeInteger(major)) return null;
  const minor = sign * (major * 100 + fractional);
  return Number.isSafeInteger(minor) ? minor : null;
}

function displayAmountCandidates(display) {
  const numberSource = "[+-]?\\d(?:[\\d\\s\\u00a0\\u202f'\\u2019.,]*\\d)?";
  const currencySource = '(?:GBP|\\u00a3|pounds?(?:\\s+sterling)?)';
  const patterns = [
    new RegExp(`${currencySource}\\s*(${numberSource})`, 'gi'),
    new RegExp(`(${numberSource})\\s*${currencySource}`, 'gi'),
  ];
  const values = [];
  for (const pattern of patterns) {
    for (const match of display.matchAll(pattern)) {
      const parsed = parseLocalizedAmountToMinor(match[1]);
      if (parsed !== null) values.push(parsed);
    }
  }
  if (values.length === 0) {
    const allNumbers = [...display.matchAll(new RegExp(numberSource, 'g'))];
    if (allNumbers.length === 1) {
      const parsed = parseLocalizedAmountToMinor(allNumbers[0][0]);
      if (parsed !== null) values.push(parsed);
    }
  }
  return [...new Set(values)];
}

function feeClauses(capture) {
  if (!own(capture, 'fee') || capture.fee === null || typeof capture.fee !== 'object' || Array.isArray(capture.fee)) {
    return [
      clause('stored minor units', 'unassessed', 'No usable fee observation was supplied.'),
      clause('stored currency', 'unassessed', 'No usable fee observation was supplied.'),
      clause('displayed currency', 'unassessed', 'No usable fee display was supplied.'),
      clause('displayed amount', 'unassessed', 'No usable fee display was supplied.'),
    ];
  }

  const fee = capture.fee;
  const clauses = [];
  if (!own(fee, 'minorUnits') || typeof fee.minorUnits !== 'number' || !Number.isFinite(fee.minorUnits)) {
    clauses.push(clause('stored minor units', 'unassessed', 'No usable numeric minor-unit observation was supplied.'));
  } else {
    clauses.push(clause('stored minor units', fee.minorUnits === 2500 ? 'passed' : 'failed', fee.minorUnits === 2500 ? 'The stored amount is exactly 2500 minor units.' : `The stored amount is ${fee.minorUnits}, not 2500 minor units.`));
  }

  if (!own(fee, 'currency') || fee.currency === null || fee.currency === undefined || typeof fee.currency !== 'string') {
    clauses.push(clause('stored currency', 'unassessed', 'No usable stored-currency observation was supplied.'));
  } else {
    clauses.push(clause('stored currency', fee.currency === 'GBP' ? 'passed' : 'failed', fee.currency === 'GBP' ? 'The stored currency is exactly GBP.' : `The stored currency is ${JSON.stringify(fee.currency)}, not GBP.`));
  }

  if (!own(fee, 'display') || fee.display === null || fee.display === undefined || typeof fee.display !== 'string') {
    clauses.push(clause('displayed currency', 'unassessed', 'No usable fee display was supplied.'));
    clauses.push(clause('displayed amount', 'unassessed', 'No usable fee display was supplied.'));
    return clauses;
  }

  const display = fee.display;
  if (!display.trim()) {
    clauses.push(clause('displayed currency', 'failed', 'The observed fee display is empty.'));
    clauses.push(clause('displayed amount', 'failed', 'The observed fee display is empty.'));
    return clauses;
  }

  const hasGbp = /\bGBP\b/i.test(display) || /\u00a3/.test(display) || /\bpounds?(?:\s+sterling)?\b/i.test(display);
  const hasConflictingCurrency = /\b(?:USD|EUR|JPY|AUD|CAD|CHF|CNY|INR)\b/i.test(display) || /[$\u20ac\u00a5]/.test(display);
  clauses.push(clause(
    'displayed currency',
    hasGbp && !hasConflictingCurrency ? 'passed' : 'failed',
    hasGbp && !hasConflictingCurrency
      ? 'The display identifies the fee as GBP/pounds sterling.'
      : hasConflictingCurrency
        ? 'The display contains a currency that conflicts with GBP.'
        : 'The display does not identify the currency as GBP/pounds sterling.',
  ));

  const amounts = displayAmountCandidates(display);
  if (amounts.length !== 1) {
    clauses.push(clause('displayed amount', 'unassessed', amounts.length === 0 ? 'The localized display amount could not be interpreted.' : 'The display yields multiple different fee amounts.'));
  } else {
    clauses.push(clause('displayed amount', amounts[0] === 2500 ? 'passed' : 'failed', amounts[0] === 2500 ? 'The displayed amount represents GBP 25.00.' : `The displayed amount represents ${amounts[0]} minor units, not 2500.`));
  }
  return clauses;
}

export function evaluate(capture) {
  const safeCapture = capture !== null && typeof capture === 'object' && !Array.isArray(capture) ? capture : {};
  const availability = result(availabilityClauses(safeCapture));
  const legal = result(legalClauses(safeCapture));
  const guest = result(guestClauses(safeCapture));
  const fee = result(feeClauses(safeCapture));

  return {
    availability: availability.outcome,
    legal: legal.outcome,
    guest: guest.outcome,
    fee: fee.outcome,
    reasons: {
      availability: availability.clauses,
      legal: legal.clauses,
      guest: guest.clauses,
      fee: fee.clauses,
    },
  };
}
