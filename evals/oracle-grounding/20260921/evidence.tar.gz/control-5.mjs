const STATUSES = Object.freeze({
  PASSED: 'passed',
  FAILED: 'failed',
  UNASSESSED: 'unassessed',
});

const LEGAL_COPY = 'This service does not provide medical advice.';
const EXPECTED_FEE = Object.freeze({ minorUnits: 2500, currency: 'GBP' });
const AVAILABILITY_FIXTURES = Object.freeze({
  '2026-10-01': Object.freeze([]),
  '2026-10-02': Object.freeze([Object.freeze({ id: 'slot-a', time: '09:00' })]),
});

const COUNT_WORDS = Object.freeze({
  zero: 0,
  one: 1,
  two: 2,
  three: 3,
  four: 4,
  five: 5,
  six: 6,
  seven: 7,
  eight: 8,
  nine: 9,
  ten: 10,
  eleven: 11,
  twelve: 12,
  thirteen: 13,
  fourteen: 14,
  fifteen: 15,
  sixteen: 16,
  seventeen: 17,
  eighteen: 18,
  nineteen: 19,
  twenty: 20,
});

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function hasOwn(value, key) {
  return isRecord(value) && Object.prototype.hasOwnProperty.call(value, key);
}

function clause(status, detail) {
  return { status, detail };
}

function aggregate(clauses) {
  const values = Object.values(clauses).map((entry) => entry.status);
  if (values.includes(STATUSES.FAILED)) return STATUSES.FAILED;
  if (values.length > 0 && values.every((value) => value === STATUSES.PASSED)) {
    return STATUSES.PASSED;
  }
  return STATUSES.UNASSESSED;
}

function validAppointmentList(value) {
  return Array.isArray(value) && value.every((entry) => (
    isRecord(entry)
    && typeof entry.id === 'string'
    && entry.id.length > 0
    && typeof entry.time === 'string'
    && entry.time.length > 0
  ));
}

function appointmentKeys(appointments) {
  return appointments.map(({ id, time }) => `${id}\u0000${time}`).sort();
}

function sameAppointments(actual, expected) {
  const actualKeys = appointmentKeys(actual);
  const expectedKeys = appointmentKeys(expected);
  return actualKeys.length === expectedKeys.length
    && actualKeys.every((key, index) => key === expectedKeys[index]);
}

function parseRenderedCount(text) {
  const candidates = [];
  const numericTokens = text.match(/\d(?:[\d\s,.'’]*\d)?/g) ?? [];

  for (const token of numericTokens) {
    const compact = token.replace(/[\s'’]/g, '');
    if (/^\d+$/.test(compact)) {
      candidates.push(Number(compact));
      continue;
    }
    if (/^\d{1,3}(?:[,.]\d{3})+$/.test(compact)) {
      candidates.push(Number(compact.replace(/[,.]/g, '')));
    }
  }

  const wordPattern = new RegExp(`\\b(${Object.keys(COUNT_WORDS).join('|')})\\b`, 'gi');
  for (const match of text.matchAll(wordPattern)) {
    candidates.push(COUNT_WORDS[match[1].toLowerCase()]);
  }

  const unique = [...new Set(candidates.filter(Number.isSafeInteger))];
  if (unique.length === 1) return { kind: 'value', value: unique[0] };
  if (unique.length === 0) return { kind: 'missing' };
  return { kind: 'ambiguous', values: unique };
}

function parseMoneyToken(token) {
  const compact = token.replace(/[\s'’]/g, '');
  if (/^\d+$/.test(compact)) return { ambiguous: false, values: [Number(compact)] };

  const comma = compact.lastIndexOf(',');
  const dot = compact.lastIndexOf('.');
  if (comma !== -1 && dot !== -1) {
    const decimalIndex = Math.max(comma, dot);
    const integerPart = compact.slice(0, decimalIndex).replace(/[,.]/g, '');
    const fractionPart = compact.slice(decimalIndex + 1);
    if (/^\d+$/.test(integerPart) && /^\d+$/.test(fractionPart)) {
      return { ambiguous: false, values: [Number(`${integerPart}.${fractionPart}`)] };
    }
    return { ambiguous: true, values: [] };
  }

  const separator = comma !== -1 ? ',' : '.';
  const parts = compact.split(separator);
  if (!parts.every((part) => /^\d+$/.test(part))) {
    return { ambiguous: true, values: [] };
  }
  if (parts.length > 2) {
    if (parts.slice(1).every((part) => part.length === 3)) {
      return { ambiguous: false, values: [Number(parts.join(''))] };
    }
    return { ambiguous: true, values: [] };
  }

  const [whole, tail] = parts;
  if (tail.length <= 2) {
    return { ambiguous: false, values: [Number(`${whole}.${tail}`)] };
  }
  if (tail.length === 3) {
    return {
      ambiguous: true,
      values: [Number(`${whole}.${tail}`), Number(`${whole}${tail}`)],
    };
  }
  return { ambiguous: true, values: [] };
}

function parseDisplayedAmount(text) {
  const tokens = text.match(/\d(?:[\d\s,.'’]*\d)?/g) ?? [];
  const parsed = tokens.map(parseMoneyToken);
  const values = [...new Set(parsed.flatMap((entry) => entry.values).filter(Number.isFinite))];
  if (parsed.some((entry) => entry.ambiguous) || values.length > 1) {
    return { kind: 'ambiguous', values };
  }
  if (values.length === 0) return { kind: 'missing' };
  return { kind: 'value', value: values[0] };
}

function guestMessageConveysSignIn(message) {
  const contradictions = [
    /\b(?:no|not)\s+(?:authentication|sign[- ]?in|login)\s+(?:is\s+)?(?:needed|required)\b/i,
    /\b(?:authentication|sign[- ]?in|login)\s+(?:is\s+)?not\s+(?:needed|required)\b/i,
    /\bdo(?:es)?\s+not\s+need\s+to\s+(?:sign|log)\s*[- ]?\s*in\b/i,
    /\bcan\s+(?:book|continue)\s+without\s+(?:authentication|signing|logging)\s*[- ]?\s*in\b/i,
  ];
  if (contradictions.some((pattern) => pattern.test(message))) return false;

  const authConcept = '(?:authentication|authenticate|sign\\s*[- ]?\\s*in|log\\s*[- ]?\\s*in|login|signed\\s+in|logged\\s+in)';
  const directAction = new RegExp(`\\b(?:please\\s+)?(?:sign|log)\\s*[- ]?\\s*in\\b`, 'i');
  const conceptThenNeed = new RegExp(`\\b${authConcept}\\b.{0,40}\\b(?:required|needed|must)\\b`, 'i');
  const needThenConcept = new RegExp(`\\b(?:must|need(?:s|ed)?|required)\\b.{0,40}\\b${authConcept}\\b`, 'i');
  return directAction.test(message) || conceptThenNeed.test(message) || needThenConcept.test(message);
}

function evaluateAvailability(capture) {
  let dateAppointments;
  if (typeof capture.date !== 'string' || capture.date.length === 0) {
    dateAppointments = clause(STATUSES.UNASSESSED, 'No selected date was supplied.');
  } else if (!hasOwn(AVAILABILITY_FIXTURES, capture.date)) {
    dateAppointments = clause(
      STATUSES.UNASSESSED,
      `No authoritative appointment fixture is supplied for ${capture.date}.`,
    );
  } else if (!validAppointmentList(capture.appointments)) {
    dateAppointments = clause(
      STATUSES.UNASSESSED,
      `The appointment observation for ${capture.date} is missing or malformed.`,
    );
  } else {
    const expected = AVAILABILITY_FIXTURES[capture.date];
    dateAppointments = sameAppointments(capture.appointments, expected)
      ? clause(STATUSES.PASSED, `Appointments exactly match the supplied fixture for ${capture.date}.`)
      : clause(STATUSES.FAILED, `Appointments do not match the supplied fixture for ${capture.date}.`);
  }

  let summaryCount;
  if (!validAppointmentList(capture.appointments)) {
    summaryCount = clause(
      STATUSES.UNASSESSED,
      'A valid appointment list is unavailable, so the summary count cannot be compared.',
    );
  } else if (!hasOwn(capture, 'summary') || typeof capture.summary !== 'string') {
    summaryCount = clause(STATUSES.UNASSESSED, 'No rendered summary text was supplied.');
  } else if (capture.summary.trim().length === 0) {
    summaryCount = clause(STATUSES.FAILED, 'The observed rendered summary is empty.');
  } else {
    const parsed = parseRenderedCount(capture.summary);
    if (parsed.kind !== 'value') {
      summaryCount = clause(
        STATUSES.UNASSESSED,
        parsed.kind === 'ambiguous'
          ? `The rendered summary has ambiguous counts: ${parsed.values.join(', ')}.`
          : 'The rendered summary has no interpretable numeric count.',
      );
    } else if (parsed.value === capture.appointments.length) {
      summaryCount = clause(
        STATUSES.PASSED,
        `The rendered summary count (${parsed.value}) agrees with the ${capture.appointments.length} observed appointments.`,
      );
    } else {
      summaryCount = clause(
        STATUSES.FAILED,
        `The rendered summary count (${parsed.value}) disagrees with the ${capture.appointments.length} observed appointments.`,
      );
    }
  }

  const clauses = { dateAppointments, summaryCount };
  return { outcome: aggregate(clauses), clauses };
}

function evaluateLegal(capture) {
  let exactCopy;
  if (!hasOwn(capture, 'legalText') || typeof capture.legalText !== 'string') {
    exactCopy = clause(STATUSES.UNASSESSED, 'No rendered legal text was supplied.');
  } else if (capture.legalText === LEGAL_COPY) {
    exactCopy = clause(STATUSES.PASSED, 'The legal text exactly matches the approved copy.');
  } else {
    exactCopy = clause(STATUSES.FAILED, 'The legal text does not exactly match the approved copy.');
  }
  const clauses = { exactCopy };
  return { outcome: aggregate(clauses), clauses };
}

function evaluateGuest(capture) {
  const guest = isRecord(capture.guest) ? capture.guest : null;

  let denialCode;
  if (!guest || !hasOwn(guest, 'code') || typeof guest.code !== 'string') {
    denialCode = clause(STATUSES.UNASSESSED, 'No usable guest API denial code was supplied.');
  } else if (guest.code === 'AUTH_REQUIRED') {
    denialCode = clause(STATUSES.PASSED, 'The guest API denial code is exactly AUTH_REQUIRED.');
  } else {
    denialCode = clause(STATUSES.FAILED, `The guest API denial code is ${JSON.stringify(guest.code)}, not AUTH_REQUIRED.`);
  }

  let noBookingCreated;
  if (!guest || typeof guest.bookingCreated !== 'boolean') {
    noBookingCreated = clause(STATUSES.UNASSESSED, 'No boolean booking-created observation was supplied.');
  } else if (guest.bookingCreated === false) {
    noBookingCreated = clause(STATUSES.PASSED, 'The observation confirms that no booking was created.');
  } else {
    noBookingCreated = clause(STATUSES.FAILED, 'A booking was created for the guest denial attempt.');
  }

  let signInExplanation;
  if (!guest || !hasOwn(guest, 'message') || typeof guest.message !== 'string') {
    signInExplanation = clause(STATUSES.UNASSESSED, 'No user-facing guest message was supplied.');
  } else if (guest.message.trim().length === 0) {
    signInExplanation = clause(STATUSES.FAILED, 'The observed user-facing guest message is empty.');
  } else if (guestMessageConveysSignIn(guest.message)) {
    signInExplanation = clause(STATUSES.PASSED, 'The user-facing message conveys that sign-in is needed.');
  } else {
    signInExplanation = clause(STATUSES.FAILED, 'The user-facing message does not convey that sign-in is needed.');
  }

  const clauses = { denialCode, noBookingCreated, signInExplanation };
  return { outcome: aggregate(clauses), clauses };
}

function evaluateFee(capture) {
  const fee = isRecord(capture.fee) ? capture.fee : null;

  let minorUnits;
  if (!fee || typeof fee.minorUnits !== 'number' || !Number.isSafeInteger(fee.minorUnits)) {
    minorUnits = clause(STATUSES.UNASSESSED, 'No integer fee in minor units was supplied.');
  } else if (fee.minorUnits === EXPECTED_FEE.minorUnits) {
    minorUnits = clause(STATUSES.PASSED, 'The stored fee is 2500 minor units.');
  } else {
    minorUnits = clause(STATUSES.FAILED, `The stored fee is ${fee.minorUnits} minor units, not 2500.`);
  }

  let currency;
  if (!fee || typeof fee.currency !== 'string') {
    currency = clause(STATUSES.UNASSESSED, 'No stored fee currency was supplied.');
  } else if (fee.currency === EXPECTED_FEE.currency) {
    currency = clause(STATUSES.PASSED, 'The stored fee currency is exactly GBP.');
  } else {
    currency = clause(STATUSES.FAILED, `The stored fee currency is ${JSON.stringify(fee.currency)}, not GBP.`);
  }

  let displayAmount;
  let displayCurrency;
  if (!fee || !hasOwn(fee, 'display') || typeof fee.display !== 'string') {
    displayAmount = clause(STATUSES.UNASSESSED, 'No rendered fee display was supplied.');
    displayCurrency = clause(STATUSES.UNASSESSED, 'No rendered fee display was supplied.');
  } else if (fee.display.trim().length === 0) {
    displayAmount = clause(STATUSES.FAILED, 'The observed rendered fee display is empty.');
    displayCurrency = clause(STATUSES.FAILED, 'The observed rendered fee display is empty.');
  } else {
    const hasGbp = /£|\bGBP\b/i.test(fee.display);
    const hasConflictingCurrency = /[$€¥₹₽₩]|\b(?:USD|EUR|JPY|CNY|RMB|AUD|CAD|CHF|NZD)\b/i.test(fee.display);
    displayCurrency = hasGbp && !hasConflictingCurrency
      ? clause(STATUSES.PASSED, 'The rendered fee display identifies GBP using GBP or the pound sign.')
      : clause(
        STATUSES.FAILED,
        hasConflictingCurrency
          ? 'The rendered fee display contains a currency marker that conflicts with GBP.'
          : 'The rendered fee display does not identify GBP.',
      );

    const parsed = parseDisplayedAmount(fee.display);
    if (parsed.kind === 'value') {
      displayAmount = parsed.value === EXPECTED_FEE.minorUnits / 100
        ? clause(STATUSES.PASSED, 'The rendered fee amount is numerically GBP 25.00.')
        : clause(STATUSES.FAILED, `The rendered fee amount is ${parsed.value}, not 25.00.`);
    } else {
      displayAmount = clause(
        STATUSES.UNASSESSED,
        parsed.kind === 'ambiguous'
          ? 'The rendered fee contains an ambiguous numeric amount.'
          : 'The rendered fee contains no interpretable numeric amount.',
      );
    }
  }

  const clauses = { minorUnits, currency, displayAmount, displayCurrency };
  return { outcome: aggregate(clauses), clauses };
}

export function evaluate(capture) {
  const safeCapture = isRecord(capture) ? capture : {};
  const availability = evaluateAvailability(safeCapture);
  const legal = evaluateLegal(safeCapture);
  const guest = evaluateGuest(safeCapture);
  const fee = evaluateFee(safeCapture);

  return {
    availability: availability.outcome,
    legal: legal.outcome,
    guest: guest.outcome,
    fee: fee.outcome,
    reasons: {
      availability,
      legal,
      guest,
      fee,
    },
  };
}
