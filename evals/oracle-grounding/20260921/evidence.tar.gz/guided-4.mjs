const LEGAL_COPY = 'This service does not provide medical advice.';

const AVAILABILITY_FIXTURES = new Map([
  ['2026-10-01', []],
  ['2026-10-02', [{ id: 'slot-a', time: '09:00' }]],
]);

function result(parts) {
  const passed = [];
  const failed = [];
  const unassessed = [];

  for (const [clause, outcome] of Object.entries(parts)) {
    const entry = `${clause}: ${outcome.reason}`;
    if (outcome.state === 'passed') passed.push(entry);
    else if (outcome.state === 'failed') failed.push(entry);
    else unassessed.push(entry);
  }

  return {
    state: failed.length ? 'failed' : unassessed.length ? 'unassessed' : 'passed',
    reasons: { passed, failed, unassessed },
  };
}

function extractAppointmentCount(summary) {
  if (typeof summary !== 'string' || summary.trim() === '') return null;

  const text = summary.normalize('NFKC').toLowerCase();
  const values = new Set();

  if (/\bno\s+(?:available\s+)?appointments?\b/.test(text) ||
      /\bappointments?\s*(?::|=|-|—)?\s*none\b/.test(text)) {
    values.add(0);
  }

  const words = {
    zero: 0, one: 1, two: 2, three: 3, four: 4, five: 5,
    six: 6, seven: 7, eight: 8, nine: 9, ten: 10,
  };
  const wordPattern = Object.keys(words).join('|');
  const wordBefore = new RegExp(`\\b(${wordPattern})\\s+(?:available\\s+)?appointments?\\b`, 'g');
  const wordAfter = new RegExp(`\\bappointments?\\s*(?::|=|-|—)?\\s*(${wordPattern})\\b`, 'g');
  for (const pattern of [wordBefore, wordAfter]) {
    for (const match of text.matchAll(pattern)) values.add(words[match[1]]);
  }

  // Counts are integers. Grouping separators are accepted, while unrelated
  // numbers (for example, a date elsewhere in the sentence) are ignored.
  const numberToken = "(?:\\d{1,3}(?:[,.'’\\s\\u00a0\\u202f]\\d{3})+|\\d+)";
  const numberBefore = new RegExp(`(${numberToken})\\s+(?:available\\s+)?appointments?\\b`, 'g');
  const numberAfter = new RegExp(`\\bappointments?\\s*(?::|=|-|—)?\\s*(${numberToken})`, 'g');
  for (const pattern of [numberBefore, numberAfter]) {
    for (const match of text.matchAll(pattern)) {
      const digits = match[1].replace(/\D/g, '');
      if (digits !== '') values.add(Number(digits));
    }
  }

  return values.size === 1 ? [...values][0] : null;
}

function sameAppointments(actual, expected) {
  return actual.length === expected.length && expected.every((wanted) =>
    actual.some((item) => item && item.id === wanted.id && item.time === wanted.time));
}

function evaluateAvailability(capture) {
  const parts = {};
  const appointmentsAvailable = Array.isArray(capture.appointments);
  const fixture = typeof capture.date === 'string'
    ? AVAILABILITY_FIXTURES.get(capture.date)
    : undefined;

  if (!appointmentsAvailable) {
    parts.renderedAppointments = {
      state: 'unassessed',
      reason: 'no rendered appointment array was supplied',
    };
  } else if (fixture) {
    parts.renderedAppointments = sameAppointments(capture.appointments, fixture)
      ? { state: 'passed', reason: `the rendered set matches the accepted fixture for ${capture.date}` }
      : { state: 'failed', reason: `the rendered set does not match the accepted fixture for ${capture.date}` };
  } else {
    parts.renderedAppointments = {
      state: 'unassessed',
      reason: 'this date has no accepted expected appointment set; the rendered list alone cannot prove completeness',
    };
  }

  const summaryCount = extractAppointmentCount(capture.summary);
  if (typeof capture.summary !== 'string' || capture.summary.trim() === '') {
    parts.summary = { state: 'unassessed', reason: 'no visible rendered summary text was supplied' };
  } else if (!appointmentsAvailable) {
    parts.summary = {
      state: 'unassessed',
      reason: 'the summary is present but no rendered appointment array is available for comparison',
    };
  } else if (summaryCount === null) {
    parts.summary = {
      state: 'failed',
      reason: 'the visible summary does not express one unambiguous appointment count',
    };
  } else if (summaryCount !== capture.appointments.length) {
    parts.summary = {
      state: 'failed',
      reason: `the summary reports ${summaryCount}, but ${capture.appointments.length} appointment(s) are rendered`,
    };
  } else {
    parts.summary = {
      state: 'passed',
      reason: `the visible summary agrees with the ${summaryCount} rendered appointment(s)`,
    };
  }

  return result(parts);
}

function evaluateLegal(capture) {
  if (typeof capture.legalText !== 'string') {
    return result({
      exactCopy: { state: 'unassessed', reason: 'no visible rendered legal text was supplied' },
    });
  }
  return result({
    exactCopy: capture.legalText === LEGAL_COPY
      ? { state: 'passed', reason: 'the rendered banner matches the approved copy exactly' }
      : { state: 'failed', reason: 'the rendered banner differs from the approved copy, including punctuation or spacing' },
  });
}

function classifySignInMessage(message) {
  if (typeof message !== 'string' || message.trim() === '') {
    return { state: 'unassessed', reason: 'no user-facing guest denial message was supplied' };
  }

  const text = message.normalize('NFKC').toLowerCase().replace(/\s+/g, ' ').trim();
  const contradictionPatterns = [
    /\b(?:without|no need (?:to|for))\b.{0,35}\b(?:sign(?:ing)?[ -]?in|log(?:ging)?[ -]?in|authentication|an? account)\b/,
    /\b(?:sign(?:ing)?[ -]?in|log(?:ging)?[ -]?in|authentication|an? account)\b.{0,35}\b(?:not (?:required|needed|necessary)|optional)\b/,
    /\b(?:do|does|is|are) not\b.{0,20}\b(?:need|require)\b.{0,35}\b(?:sign|log|authentication|account)\b/,
    /\bguests?\b.{0,25}\b(?:can|may|are allowed to)\b.{0,25}\bbook\b/,
  ];
  if (contradictionPatterns.some((pattern) => pattern.test(text))) {
    return { state: 'failed', reason: 'the message says or implies that guest booking does not require sign-in' };
  }

  const requirementPatterns = [
    /\b(?:must|need(?:s)? to|have to|please)\s+(?:be\s+)?(?:sign(?:ed)?[ -]?in|log(?:ged)?[ -]?in|authenticate(?:d)?)\b/,
    /\b(?:must|need(?:s)? to|have to)\s+(?:have|create)\s+an?\s+account\b/,
    /\b(?:sign(?:ing)?[ -]?in|log(?:ging)?[ -]?in|authentication|an? account)\b.{0,35}\b(?:is\s+)?(?:required|needed|necessary)\b/,
    /\b(?:sign|log)[ -]?in\b.{0,25}\b(?:to|before)\b.{0,35}\b(?:book|continue|make|schedule|reserve)\b/,
    /\b(?:booking|appointments?)\b.{0,35}\b(?:requires?|needs?)\b.{0,25}\b(?:sign|log|authentication|account)\b/,
    /\bonly\b.{0,25}\b(?:signed|logged)[ -]?in\b.{0,35}\b(?:users?\b|book\b)/,
    /^(?:please\s+)?(?:sign|log)[ -]?in\b/,
  ];
  return requirementPatterns.some((pattern) => pattern.test(text))
    ? { state: 'passed', reason: 'the message conveys that sign-in is required to book or continue' }
    : { state: 'failed', reason: 'the supplied message does not convey that sign-in is required' };
}

function evaluateGuest(capture) {
  const guest = capture.guest && typeof capture.guest === 'object' ? capture.guest : null;
  if (!guest) {
    return result({
      apiCode: { state: 'unassessed', reason: 'no guest denial API observation was supplied' },
      bookingState: { state: 'unassessed', reason: 'no post-attempt booking state was supplied' },
      explanation: { state: 'unassessed', reason: 'no user-facing guest denial message was supplied' },
    });
  }

  const code = typeof guest.code !== 'string'
    ? { state: 'unassessed', reason: 'the API denial code was not observed' }
    : guest.code === 'AUTH_REQUIRED'
      ? { state: 'passed', reason: 'the API denial code is exactly AUTH_REQUIRED' }
      : { state: 'failed', reason: `the API denial code is ${JSON.stringify(guest.code)}, not AUTH_REQUIRED` };

  const bookingState = typeof guest.bookingCreated !== 'boolean'
    ? { state: 'unassessed', reason: 'booking creation was not observed as a boolean state' }
    : guest.bookingCreated === false
      ? { state: 'passed', reason: 'no booking was created for the guest' }
      : { state: 'failed', reason: 'a booking was created for the guest' };

  return result({ apiCode: code, bookingState, explanation: classifySignInMessage(guest.message) });
}

function parseMoneyMinorUnits(token) {
  let value = token.replace(/[\s\u00a0\u202f'’]/g, '');
  if (!/^[+-]?\d+(?:[.,]\d+)*$/.test(value)) return null;

  const sign = value.startsWith('-') ? -1 : 1;
  value = value.replace(/^[+-]/, '');
  const lastDot = value.lastIndexOf('.');
  const lastComma = value.lastIndexOf(',');
  const lastSeparator = Math.max(lastDot, lastComma);

  let whole;
  let fraction = '';
  if (lastSeparator >= 0) {
    const tail = value.slice(lastSeparator + 1);
    if (tail.length === 1 || tail.length === 2) {
      whole = value.slice(0, lastSeparator).replace(/[.,]/g, '');
      fraction = tail;
    } else {
      whole = value.replace(/[.,]/g, '');
    }
  } else {
    whole = value;
  }

  if (!/^\d+$/.test(whole) || (fraction && !/^\d{1,2}$/.test(fraction))) return null;
  const minor = Number(whole) * 100 + Number((fraction + '00').slice(0, 2));
  return Number.isSafeInteger(minor) ? sign * minor : null;
}

function displayFeeMinorUnits(display) {
  if (typeof display !== 'string' || display.trim() === '') return null;
  const number = "[+-]?(?:\\d{1,3}(?:[,.'’\\s\\u00a0\\u202f]\\d{3})+(?:[.,]\\d{1,2})?|\\d+(?:[.,]\\d{1,2})?)";
  const patterns = [
    new RegExp(`(?:\\bGBP\\b|£)\\s*(${number})`, 'i'),
    new RegExp(`(${number})\\s*(?:\\bGBP\\b|£)`, 'i'),
  ];
  for (const pattern of patterns) {
    const match = display.match(pattern);
    if (match) return parseMoneyMinorUnits(match[1]);
  }
  return null;
}

function evaluateFee(capture) {
  const fee = capture.fee && typeof capture.fee === 'object' ? capture.fee : null;
  if (!fee) {
    return result({
      storedAmount: { state: 'unassessed', reason: 'no fee API observation was supplied' },
      storedCurrency: { state: 'unassessed', reason: 'no fee currency observation was supplied' },
      display: { state: 'unassessed', reason: 'no rendered fee display was supplied' },
    });
  }

  const storedAmount = typeof fee.minorUnits !== 'number'
    ? { state: 'unassessed', reason: 'stored minor units were not observed as a number' }
    : fee.minorUnits === 2500
      ? { state: 'passed', reason: 'the stored amount is exactly 2500 minor units' }
      : { state: 'failed', reason: `the stored amount is ${fee.minorUnits}, not 2500 minor units` };

  const storedCurrency = typeof fee.currency !== 'string'
    ? { state: 'unassessed', reason: 'stored currency was not observed' }
    : fee.currency === 'GBP'
      ? { state: 'passed', reason: 'the stored currency is exactly GBP' }
      : { state: 'failed', reason: `the stored currency is ${JSON.stringify(fee.currency)}, not GBP` };

  let display;
  if (typeof fee.display !== 'string' || fee.display.trim() === '') {
    display = { state: 'unassessed', reason: 'no visible rendered fee display was supplied' };
  } else {
    const hasGbp = /\bGBP\b/i.test(fee.display) || fee.display.includes('£');
    const hasConflictingCurrency = /\b(?:USD|EUR|JPY|AUD|CAD|CHF|CNY|INR)\b/i.test(fee.display) || /[$€¥]/.test(fee.display);
    const displayedMinorUnits = displayFeeMinorUnits(fee.display);
    display = hasGbp && !hasConflictingCurrency && displayedMinorUnits === 2500
      ? { state: 'passed', reason: 'the display shows GBP 25.00 using an accepted locale-independent form' }
      : { state: 'failed', reason: 'the display does not unambiguously show 2500 minor units in GBP' };
  }

  return result({ storedAmount, storedCurrency, display });
}

export function evaluate(capture) {
  const observation = capture && typeof capture === 'object' ? capture : {};
  const availability = evaluateAvailability(observation);
  const legal = evaluateLegal(observation);
  const guest = evaluateGuest(observation);
  const fee = evaluateFee(observation);

  return {
    availability: availability.state,
    legal: legal.state,
    guest: guest.state,
    fee: fee.state,
    reasons: {
      availability: availability.reasons,
      legal: legal.reasons,
      guest: guest.reasons,
      fee: fee.reasons,
    },
  };
}
