# Lane 4 appointment-preview oracle

Artifact: `lane-4.mjs`. It exports `evaluate(capture)` and performs no I/O, imports, product actions, or network access. This is an authored test-design oracle, not evidence that the preview passed release acceptance.

| Oracle | Requirement source | Evaluation | If evidence is unavailable |
| --- | --- | --- | --- |
| Availability | Accepted product brief plus its read-only fixtures | For 2026-10-01, requires no appointments; for 2026-10-02, requires exactly `slot-a` at `09:00`; for 2026-10-03, requires two appointments because only that count was supplied. Independently parses an English appointment count from the rendered summary and compares it with the captured array, including zero. | Capture the selected date, rendered appointment entries, and nonblank visible summary. Supply an authoritative fixture for any other date before judging whether that date's appointment set is exact. |
| Legal | Accepted product brief's approved legal copy | Requires exact code-point equality with `This service does not provide medical advice.` including punctuation. | Capture the consent banner's complete rendered text. |
| Guest | Accepted product brief's guest-booking rule | Separately requires API code `AUTH_REQUIRED`, `bookingCreated === false`, and a nonblank English explanation confidently conveying that sign-in/authentication is required. An established violation fails even when another clause is unavailable. | Capture the denial response, verify booking state through authorized read-only evidence, and capture the complete user message. If the bounded phrase matcher cannot establish meaning, review the full message in context rather than calling it a defect. |
| Fee | Accepted product brief's GBP 25.00 / 2500-minor-unit rule | Separately requires numeric `minorUnits === 2500`, stored currency exactly `GBP`, and a display that conveys GBP and numerically resolves to 25 major units. Dot/comma decimals, common grouping, spacing, the GBP code, pound symbol, and English sterling wording are supported. | Capture the stored amount/currency and complete displayed fee. Human-review an unfamiliar numeric format rather than failing it solely because the parser cannot interpret it. |

## Limits

- The prior continuation note has no attached source, so it does not create literal requirements for `0 appointments` or `1 appointment`; the accepted brief requires semantic count agreement. The parser accepts numeric and common English counts around `appointment(s)`.
- A nonblank `summary` is treated as text obtained from the fresh rendered-summary observation described by the input contract. The schema has no geometry, CSS, accessibility-tree, or visibility flag, so independent proof of actual visibility requires a screenshot/DOM-accessibility observation.
- Appointment entries contain no per-entry date. The oracle relies on the capture contract associating the `appointments` array with `capture.date`; a fresh observation must establish that association.
- The 2026-10-03 material supplies only a count, not appointment identities or times, so exact entry identity for that date remains unassessed by design.
- The guest message matcher is intentionally conservative. Unsupported but potentially valid wording produces `unassessed`, not a product failure.
- Display parsing checks amount/currency agreement, not a mandated locale style. Accessibility, responsiveness, performance, security, and whole-product coverage are outside this narrow artifact.

Next action: feed fresh, authorized, read-only rendered/API captures into `evaluate`; retain each `unassessed` clause until the specified observation or authoritative fixture is supplied. Do not book, create an account, or infer release acceptance from module output alone.
