# Appointment-preview oracle report

`guided-2.mjs` is an offline, dependency-free oracle over a fresh capture. It authors checks only; no product check was executed and no release or product acceptance is claimed.

## Oracle basis and behavior

| Oracle | Requirement source | What is assessed |
| --- | --- | --- |
| Availability | Accepted product brief and its read-only fixtures | For `2026-10-01`, the rendered list must be empty. For `2026-10-02`, it must contain only `slot-a` at `09:00`. Independently, a nonempty English summary must yield one unambiguous count agreeing with the rendered array length, including zero. |
| Legal | Accepted product brief, approved legal copy | Character-for-character equality with `This service does not provide medical advice.` including punctuation. |
| Guest | Accepted product brief | The API code is exactly `AUTH_REQUIRED`; `bookingCreated` is exactly `false`; and the English message conveys that sign-in is required. These three clauses are evaluated independently. |
| Fee | Accepted product brief | Stored values are exactly `2500` and `GBP`. The rendered display identifies GBP/pounds sterling and expresses 25 major units. Common dot/comma decimal and grouping styles are accepted; no single locale layout is required. |

Each top-level result is `failed` when any assessable clause contradicts its requirement, `unassessed` when no clause fails but at least one lacks usable/unambiguous evidence, and `passed` only when every clause for that oracle is assessed and passes. `reasons` retains per-clause outcomes so one unavailable interpretation does not erase independent findings.

## Grounding decisions and limits

- The `2026-10-03` render (`2 appointments`) is a supplied observation, not an authoritative availability fixture. The module can compare its summary with its rendered array, but it does not hardcode two as the expected source-of-truth availability for that date.
- The prior continuation note is neither execution evidence nor an additional requirement source. In particular, its literal summary strings are not enforced because the brief requires agreement, not fixed summary wording.
- A present capture field is treated as the fresh rendered/API observation described by the handoff. The object does not carry DOM visibility, selected-control state, request/response provenance, capture time, environment identity, or proof that the array is the complete UI list. Those properties cannot be established offline.
- Summary and guest-message interpretation is deliberately bounded to recognizable English meanings. An unfamiliar but potentially valid phrasing is `unassessed`, not failed. Explicitly contradictory sign-in wording fails even if it contains sign-in keywords.
- Fee parsing supports ordinary GBP symbols/words and common numeric separators. Ambiguous/multiple amounts or an unparseable textual amount remain unassessed; a missing or conflicting displayed currency fails.
- The evaluator does not book, authenticate, create accounts, call an API, or mutate product/tracker state.

## Next action for unavailable evidence

- Unknown-date appointment truth: obtain an authoritative read-only fixture/API expectation for that date, then add it to the fixture binding before judging exact availability.
- Uninterpretable summary or guest copy: collect the exact fresh rendered English text and review its meaning; extend the semantic parser only when that phrasing is confirmed valid or contradictory by the accepted requirement owner.
- Missing API/storage fields: capture the guest denial response and post-attempt booking outcome, plus the fee's stored minor units/currency, from an authorized read-only observation.
- Visibility, completeness, and environment identity: during the authorized release review, capture the selected date, complete rendered list, visible summary/legal/guest/fee text, API denial response, and positive environment identity in one attributable observation. Preserve any still-unsupported clause as unassessed.
