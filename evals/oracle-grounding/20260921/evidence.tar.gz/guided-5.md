# Appointment-preview oracle report

`guided-5.mjs` is an offline, dependency-free test-design oracle. It evaluates a caller-supplied fresh capture; it does not visit the product, book, create an account, or establish release acceptance.

## Oracle basis and behavior

| Oracle | Requirement source | Evaluated outcome | Limit and next action when evidence is unavailable |
| --- | --- | --- | --- |
| Availability | Accepted product brief in `task.md`: a selected date must show exactly its appointments and a summary with the same count. The same brief supplies authoritative fixtures for 2026-10-01 (none) and 2026-10-02 (`slot-a`, `09:00`). | Exact, order-independent fixture comparison plus semantic summary-count/list-count agreement. A known contradiction fails even if another clause is unavailable. | Other dates remain `unassessed` for exact list membership even when their summary agrees with the captured list. Add an authoritative dated fixture, then evaluate a fresh capture. The capture shape also cannot independently prove on-screen visibility or that the requested selector interaction occurred; preserve that as separate browser evidence. |
| Legal | Accepted product brief in `task.md`: approved text is exactly `This service does not provide medical advice.` including punctuation. | Exact string comparison; missing text is `unassessed`. | Capture rendered legal text (and separate visibility evidence if needed), then rerun. |
| Guest | Accepted product brief in `task.md`: guests cannot book, denial code is exactly `AUTH_REQUIRED`, no booking is created, and the explanation must convey that sign-in is needed. | Code and side effect are exact. Recognized sign-in-required meanings pass; explicit permission/negation fails. Unrecognized nonempty wording is `unassessed`, not guessed from keywords. | Obtain semantic human/agent review of unfamiliar wording while retaining the independent code and side-effect findings; supply missing API or creation evidence and rerun. |
| Fee | Accepted product brief in `task.md`: 2500 minor units, GBP, displayed amount/currency agree; locale format is not prescribed. | Exact stored values; display accepts `GBP` or `£` with common dot/comma locale forms that equal 25. | If a novel display cannot be parsed, review its rendered meaning or extend the parser from an approved example, then rerun. Missing stored fields require fresh API evidence. |

The brief's statement about the currently supplied 2026-10-03 render is treated as an observation, not a complete dated fixture: it gives no appointment identities/times and therefore cannot prove that the list is exact. The prior continuation note has no attached source and no execution evidence; its October 1/2 expectations happen to be supported by the accepted brief, but the note adds no authority or PASS result.

## Result semantics

- `failed`: at least one assessable required clause contradicts the brief.
- `passed`: every clause for that oracle is assessable and meets the brief.
- `unassessed`: no contradiction was established, but at least one required clause lacks reliable or interpretable evidence.

The four oracles are evaluated independently, so missing or unfamiliar evidence in one does not prevent deterministic findings in the others. A result from this module is scoped to the supplied capture and is not whole-product or release acceptance.
