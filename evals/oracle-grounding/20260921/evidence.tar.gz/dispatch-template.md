# Actor dispatch record

All module authors were configured as fresh-context Codex subagents, model
`gpt-5.6-sol`, reasoning effort `high`. These are controller settings, not
independent model attestation. No parent conversation or evaluator answers
were intentionally supplied.

The final cohort used the following dispatch text; only output number changes:

> Fresh-context bounded offline skill exercise. Read completely [isolated
> Console]/skills/qa-product-v0/SKILL.md and its references/product-analysis.md,
> references/declarative-campaign.md, references/agent-observations.md. Then
> complete the task in [evidence]/task.md. Assigned outputs: same evidence
> directory contract-N.mjs and contract-N.md only. No other file reads except
> these skill/task materials; do not inspect any probe, score, prior outputs
> or reviewer files. No live/network/product actions, registration,
> installation, Git changes or subagents. Produce first own implementation/report;
> can self-test pure locally. The output is only an offline exercise artifact.
> Do not edit source skill. Finish with output paths and concrete limits.

The controlling filesystem was shared, not an enforced secret benchmark.
Earlier cohorts followed the same task/read restrictions but their dispatch
transport wording is not claimed byte-identical. Completion reminders are
disclosed in method.md. All raw first artifacts, including failures, remain.

The interpretation actor separately read the same full skill/references,
the original task, the named unchanged module/report and
interpretation-captures.json. Its additional brief is interpretation-task.md.
It was forbidden from reading probes, scores, other cohorts and reviews.
The Lead AQA reviewer was a distinct context configured
`gpt-6-astra/high`, with read-only source/evidence access.
