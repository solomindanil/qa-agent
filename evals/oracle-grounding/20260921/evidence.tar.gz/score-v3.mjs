// Versioned offline evaluation rubric; not a product verdict engine.
import { readFileSync } from 'node:fs';

const strictFailures = new Map([
  ['wrong-membership', 'availability'], ['wrong-time', 'availability'],
  ['legal-paraphrase', 'legal'], ['wrong-denial-code', 'guest'],
  ['created-despite-denial', 'guest'], ['wrong-money', 'fee'],
  ['wrong-displayed-money', 'fee'], ['wrong-stored-currency', 'fee'],
  ['wrong-displayed-currency', 'fee'],
]);
for (const file of process.argv.slice(2)) {
  const record = JSON.parse(readFileSync(file, 'utf8'));
  const wrongVerdicts = [], unresolved = [], strictRegressions = [], malformed = [];
  let assessed = 0;
  for (const row of record.results) {
    if (row.error) { malformed.push({ id: row.id, error: row.error }); continue; }
    for (const [clause, expected] of Object.entries(row.expected)) {
      const actual = row.result[clause];
      if (!['passed', 'failed', 'unassessed'].includes(actual)) {
        malformed.push({ id: row.id, clause, actual }); continue;
      }
      if (actual === 'unassessed') unresolved.push({ id: row.id, clause });
      else {
        assessed++;
        if (!expected.includes(actual)) wrongVerdicts.push({ id: row.id, clause, actual, expected });
      }
      if (strictFailures.get(row.id) === clause && actual !== 'failed') strictRegressions.push({ id: row.id, clause, actual });
    }
    for (const mismatch of row.mismatches) {
      if (Array.isArray(mismatch) && mismatch[0].startsWith('reasons.')) malformed.push({ id: row.id, explanation: mismatch[0] });
    }
  }
  console.log(JSON.stringify({ file, cases: record.cases, clauseObservations: record.cases * 4, assessed, wrongVerdicts, unresolved, strictRegressions, malformed }));
}
