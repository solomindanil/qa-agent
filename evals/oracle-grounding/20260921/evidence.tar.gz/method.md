# Oracle-grounding microtest, 21 September 2026

Bounded task: validate an approved qa-product-v0 expectation/semantic-assertion correction without changing the runner or a product. The prior actual-browser failure remains in root `evals/public-input-agent-cycle/20260921/`; it is not rewritten or retrospectively made successful.

## Method fixed before skill edits

- Five fresh-context, single-shot Codex subagents, configured gpt-5.6-sol/high, receive the same task and full selected Console c421160 skill plus relevant references. This is the control without the proposed guidance, not a skill-free agent. They receive only task.md and their output paths, not probe.mjs, other answers or the proposed change.
- Outputs are executable offline oracle-design artifacts. They are not managed campaigns, new supported QA runtimes, or product execution. Appointment preview is a different example from the earlier catalog exercise; this is not broad cross-domain qualification.
- Probe outcomes are hand-derived from the task requirements. Five new contexts use the revised skill only if the control identifies a relevant gap. Preserve every first output; no feedback/fixes to sampled actors.
- Shared filesystem is not answer-key isolation. This is open-context evaluation with instructions limiting reads, not a blinded benchmark. Prompts and configured model are records, not independent model/host attestation.
- Manually review output behavior, source grounding and stated limits. Distinguish wrong failure on a valid rendering, wrong pass on a substantive violation, and honest abstention. A successful command is not a successful oracle.
- Existing strict legal copy, API denial code, no-created-booking state, amount and currency controls must remain strict. A source-conditioned text improvement must not make them permissive.

## Evaluator review and correction

Before skill edits, independent Lead AQA reviewer p2b_architecture_aqa inspected task.md and probe.mjs, not actor outputs. Review requested independent display/structured amount and currency controls, guest paraphrase/contradiction, unknown-date fixture and wrong-time cases, and reasoning presence. These were added before the first controller scoring. Reviewer also identified that `Schedule updated` permits either failed (no required count) or unassessed (uninterpretable), so both are accepted.

First scorer output incorrectly required each reason to be a string, while the task allowed structured explanations. This falsely flagged control-1's valid clause objects. Controller corrected the scorer, retained both original `*-results.json` and corrected `*-results-v2.json`, and did not change either actor output. Revised explanation check accepts substantive nested explanations and excludes status/observed-only records; manual grounding review remains necessary.

Word-based `One appointment available` allows passed or unassessed: this measures honest bounded interpretation, not proof of word-number understanding. Empty/ambiguous text also has explicitly bounded accepted outcomes. No reliability percentage may be inferred from five samples.

## Frozen control findings before edit

All five outputs retained. Controls 1/2/3/5 falsely pass `No sign-in is necessary` with otherwise correct denial evidence. Control 4 falsely fails the valid `Log in before booking`. Control 5 additionally abstains on both `No appointments available` controls, one healthy and one with a contradictory nonempty list: these are incomplete semantic coverage, not false bug reports or false PASS. None of the five reproduces the original catalog exact-count wording failure. The proposed small guidance therefore addresses demonstrated meaning/wording assertion boundaries; it cannot be described as a controlled causal repair of that earlier specific failure.

All supplied strict legal/API/no-booking/money/currency controls passed under the old guidance. Control 3/4/5 received one operational completion/timebox reminder; control 3 received one additional request to finish after its files were captured. No intended case answers or evaluator outcomes were sent to these actors. All five supplied their own optional self-tests; those are separate from the controller's common 21-case probe and not evidence of product execution.

Candidate edit: only two identical existing `product-analysis.md` references, adding one source-conditioned paragraph. Complete file SHA-256 `6325e04bd2f398169c6b2335f1422fe5276e98fab3d03968caa148f49a56174b`. Entry, runtime, schemas and required permissions are unchanged. Existing parity/reference tests passed2/2 before and after. Python quick_validate could not start because PyYAML is absent; no dependency was installed. Existing Node YAML parsed the unchanged entry successfully. Candidate is not accepted until new samples and independent review.

## First candidate rejected; clarified scoring frozen before second candidate samples

All five first-candidate outputs retained without edits: guided-1/2/3/4 still falsely pass the contradictory guest message; guided-5 abstains. Guided-3 also abstains on the healthy paraphrase. Original 21-case v2 output remains retained. Independent Lead AQA report `lead-aqa-boundary.md` confirms that definite wrong verdicts are defects, but legitimate unassessed clauses are incomplete coverage, not false verdicts. The offline coding task itself biases authors toward writing parsers; this does not prove the same error rate in ordinary agent-led QA.

`score-v3.mjs` therefore reads (does not replace) the original results and separates wrong definitive verdicts, unresolved clauses, malformed outputs and strict failures not detected. Strict inventory/time, legal, API/no-created-booking and money/currency mutations still require failure; semantic uncertainty must not hide them. The same rubric applies to every preserved control and both candidate cohorts. Unresolved semantic clauses require retained deterministic results and a concrete next action in manual report review. Unresolved is never counted as assessed PASS; a later separate agent-led fixture assessment is required to demonstrate useful completion rather than reward abstention alone.

Second candidate replaces the same paragraph, moving lane selection before parser synthesis: existing deterministic exact constraints/state stay strict; unrestricted meaning belongs to the existing agent-led evidence lane, not guessed keyword/regex proof. An established violation still fails a compound check. It adds no runtime/schema, language parser, grammar registry, install or authority. First-candidate full skill snapshot is preserved under `variants/v1/qa-product-v0/`. The next five contexts receive the unchanged task, the revised complete skill and new output paths only. A subsequent raw-capture interpretation task will be separate from module authoring and will preserve first results.

## Second candidate review and final bounded iteration

All five second-candidate outputs are preserved. Frozen21: lane-1/2/3/5 have zero wrong definitive verdicts, but lane-4 wrongly passes the date without authoritative exact fixture truth. All five retain strict controls. Independent Lead AQA also tested the unchanged lane-2/4 with `No sign-in is required`: both falsely pass. This is the same semantic-classifier error, not an unrelated reason to withhold acceptance. `diagnostic.mjs` records that extra two-message probe separately for all cohorts; it never changes the frozen21 denominator.

The separate fresh interpretation actor correctly assessed five supplied captures:14 passed,5 failed,1 unresolved. Reviewer independently deep-compared all five saved module returns with unchanged lane-1. This proves bounded useful agent interpretation, not live provenance or a behavioral fix across authors. Second candidate is not accepted as a verified repair; its full skill bytes are retained in `variants/v2/qa-product-v0/`. Lane-1/3 received one operational finish reminder; no semantic answers were supplied to sampled authors.

Lead AQA approved one final narrow formulation to test: deterministic modules capture unrestricted prose and leave meaning unresolved; the separate agent-led assessment evaluates it. Deterministic matching remains allowed for exact copy or grammar explicitly defined by the authoritative requirement, not grammar invented by the agent. Complete V3 reference hash is `ae61132d05033ee35cba9e54b3eee546fb9d2dc28c7d769cf5933c97abbba42b` in both adapters. Five fresh contexts receive the same unchanged task and the complete V3 skill, assigned `contract-1..5` outputs. All receive the same dispatch template (paths/index vary) and no controller/reviewer outputs. Existing parity tests again pass2/2; no runtime or test-byte edit.

The third cohort is a bounded last iteration for this slice, not an invitation to sample until green. Preserve its first results and any additional failures. Adoption still requires independent review, source packaging and delivery gates; no installed-host update is implied.

## Final outcome

All five V3 authors completed without content corrections or completion reminders. Frozen21 has zero wrong definitive verdicts, strict regressions or malformed outputs in each sample. Unresolved top-level observations are37/37/24/24/25 out of84 each. All five abstain on the extra guest contradiction diagnostic. These are not five successful complete QA runs.

Manual review exposed the same defect in another clause: contract-3/4/5 accept `No appointments available. Booking 1 appointment is not possible.` with the known one-item list. They extract a numeric substring and misstate the entire summary's meaning. `summary-diagnostic.mjs` records this separately for all20 original artifacts. Earlier lane-1/5 and control-5 also falsely pass it. No old score or artifact was rewritten to incorporate this additional test. Independent Lead AQA confirmed the contradiction.

Final disposition: source wording reviewed, but behavioral repair NOT accepted. Preserve V3 source as an inactive candidate; the manifest-selected Console remains c421160 and no installed skill/runtime changes. Stop this prose-only iteration. Use the already-existing independent test-design review in the next actual workflow, with complete-meaning counterexamples and retained source grounding. Generated oracle modules remain known-faulty research artifacts, never imports into the product runner.

The V2 separate interpretation remains correctly scoped14pass/5fail/1unresolved and original module readback5/5; it is not relabelled as a fresh V3 end-to-end run. Original catalog literal-count failure was not reproduced by these control authors, and is not retroactively closed. Full P3/P5, hosted/cross-domain/Claude qualification and the global remaining scope stay open.
