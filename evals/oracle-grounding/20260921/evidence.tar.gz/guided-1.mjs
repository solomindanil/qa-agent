const LEGAL_COPY = 'This service does not provide medical advice.';

const FIXTURES = Object.freeze({
  '2026-10-01': [],
  '2026-10-02': [{ id: 'slot-a', time: '09:00' }],
});

const NUMBER_WORDS = Object.freeze({
  zero: 0,
  no: 0,
  one: 1,
  two: 2,
  three: 3,
  four: 4,
  five: 5,
  six: 6,
  seven: 7,
  eight: 8,
  nine: 9,
  ten: 10,
  eleven: 11,
  twelve: 12,
  thirteen: 13,
  fourteen: 14,
  fifteen: 15,
  sixteen: 16,
  seventeen: 17,
  eighteen: 18,
  nineteen: 19,
  twenty: 20,
});

const own = (value, key) =>
  value !== null && typeof value === 'object' && Object.prototype.hasOwnProperty.call(value, key);

function compactText(value) {
  return value.normalize('NFKC').replace(/[\u00a0\u202f]/g, ' ').replace(/\s+/g, ' ').trim();
}

function parseCountToken(token) {
  const normalized = compactText(token).toLowerCase();
  if (Object.prototype.hasOwnProperty.call(NUMBER_WORDS, normalized)) {
    return NUMBER_WORDS[normalized];
  }

  if (!/^\d+(?:[ ,.']\d{3})*$/.test(normalized)) return null;
  const digits = normalized.replace(/[ ,.']/g, '');
  const value = Number(digits);
  return Number.isSafeInteger(value) ? value : null;
}

function summaryCount(summary) {
  const normalized = compactText(summary).toLowerCase();
  const wordAlternatives = Object.keys(NUMBER_WORDS).join('|');
  const token = `(?:\\d+(?:[ ,.']\\d{3})*|${wordAlternatives})`;
  const patterns = [
    new RegExp(`\\b(${token})\\s+(?:available\\s+)?appointments?\\b`, 'gi'),
    new RegExp(`\\bappointments?(?:\\s+available)?\\s*[:=\u2013\u2014-]\\s*(${token})\\b`, 'gi'),
  ];
  const counts = [];

  for (const pattern of patterns) {
    for (const match of normalized.matchAll(pattern)) {
      const parsed = parseCountToken(match[1]);
      if (parsed !== null) counts.push(parsed);
    }
  }

  const unique = [...new Set(counts)];
  if (unique.length === 1) return { kind: 'known', value: unique[0] };
  if (unique.length > 1) return { kind: 'ambiguous' };
  return { kind: 'unknown' };
}

function sameAppointments(actual, expected) {
  if (actual.length !== expected.length) return false;
  const keys = actual.map((entry) =>
    entry !== null && typeof entry === 'object' && typeof entry.id === 'string' && typeof entry.time === 'string'
      ? `${entry.id}\u0000${entry.time}`
      : null,
  );
  if (keys.includes(null)) return false;
  const expectedKeys = expected.map((entry) => `${entry.id}\u0000${entry.time}`);
  return keys.sort().every((key, index) => key === expectedKeys.sort()[index]);
}

function evaluateAvailability(capture) {
  if (!own(capture, 'date') || typeof capture.date !== 'string' || capture.date.trim() === '') {
    return { status: 'unassessed', reason: 'The selected date is unavailable in the capture.' };
  }
  if (!own(capture, 'appointments') || !Array.isArray(capture.appointments)) {
    return { status: 'unassessed', reason: 'The rendered appointment list is unavailable in the capture.' };
  }

  const failures = [];
  const unknowns = [];
  const expected = FIXTURES[capture.date];

  if (expected) {
    if (!sameAppointments(capture.appointments, expected)) {
      failures.push(`the list does not match the accepted fixture for ${capture.date}`);
    }
  } else {
    const entriesAreObservable = capture.appointments.every(
      (entry) => entry !== null && typeof entry === 'object' && typeof entry.id === 'string' && typeof entry.time === 'string',
    );
    if (!entriesAreObservable) {
      unknowns.push('one or more appointment entries lack an id or time');
    }
    unknowns.push(`no accepted expected inventory is supplied for ${capture.date}`);
  }

  if (!own(capture, 'summary') || typeof capture.summary !== 'string') {
    unknowns.push('the visible summary text is unavailable');
  } else if (capture.summary.trim() === '') {
    failures.push('the observed summary is empty');
  } else {
    const parsed = summaryCount(capture.summary);
    if (parsed.kind === 'known' && parsed.value !== capture.appointments.length) {
      failures.push(`the summary says ${parsed.value} while the rendered list has ${capture.appointments.length}`);
    } else if (parsed.kind === 'ambiguous') {
      unknowns.push('the summary contains more than one appointment count');
    } else if (parsed.kind === 'unknown') {
      unknowns.push('the English summary count could not be interpreted safely');
    }
  }

  if (failures.length) return { status: 'failed', reason: failures.join('; ') + '.' };
  if (unknowns.length) return { status: 'unassessed', reason: unknowns.join('; ') + '.' };
  return {
    status: 'passed',
    reason: `The ${capture.date} fixture list matches exactly and the visible summary agrees with its count.`,
  };
}

function evaluateLegal(capture) {
  if (!own(capture, 'legalText') || typeof capture.legalText !== 'string') {
    return { status: 'unassessed', reason: 'Visible legal text is unavailable in the capture.' };
  }
  if (capture.legalText !== LEGAL_COPY) {
    return { status: 'failed', reason: 'The captured legal text is not the exact approved copy, including punctuation.' };
  }
  return { status: 'passed', reason: 'The captured visible legal text exactly matches the approved copy.' };
}

function interpretSignInMessage(message) {
  const text = compactText(message.replace(/[\u2018\u2019]/g, "'")).toLowerCase();
  if (text === '') return { kind: 'failed', detail: 'the user-facing explanation is empty' };

  const contradictions = [
    /\b(?:do not|don't|does not|doesn't|need not)\s+(?:sign|log)[ -]?in\b/,
    /\bno need to\s+(?:sign|log)[ -]?in\b/,
    /\b(?:sign|log)[ -]?in\s+(?:is\s+)?not\s+(?:needed|required|necessary)\b/,
    /\b(?:can|may)\s+(?:book|schedule|continue|proceed)\b[^.!?]*\bwithout\s+(?:signing|logging)[ -]?in\b/,
  ];
  if (contradictions.some((pattern) => pattern.test(text))) {
    return { kind: 'failed', detail: 'the explanation says sign-in is not needed' };
  }

  const supportedMeanings = [
    /\b(?:please\s+)?(?:sign|log)[ -]?in\s+(?:to|before)\s+(?:book|booking|schedule|scheduling|continue|proceed|make)\b/,
    /\b(?:you\s+)?(?:must|need to|have to|required to)\s+(?:sign|log)[ -]?in\b/,
    /\b(?:sign|log)[ -]?in\s+(?:is\s+)?(?:required|needed|necessary)\b/,
    /\b(?:authentication|an authenticated (?:session|account)|a signed[- ]in account)\s+(?:is\s+)?(?:required|needed|necessary)\b/,
    /\b(?:please\s+)?authenticate\s+(?:to|before)\s+(?:book|booking|continue|proceed|schedule|scheduling)\b/,
    /\b(?:must|need to|have to)\s+(?:be\s+)?authenticated\b/,
    /\b(?:account|authentication)\s+(?:is\s+)?required\s+(?:to|for)\s+(?:book|booking|schedule|scheduling)\b/,
  ];
  if (supportedMeanings.some((pattern) => pattern.test(text))) {
    return { kind: 'passed', detail: 'the explanation clearly conveys that sign-in is needed' };
  }
  return { kind: 'unassessed', detail: 'the English explanation cannot be interpreted confidently by this bounded oracle' };
}

function evaluateGuest(capture) {
  if (!own(capture, 'guest') || capture.guest === null || typeof capture.guest !== 'object') {
    return { status: 'unassessed', reason: 'The guest API/UI observation is unavailable.' };
  }

  const failures = [];
  const unknowns = [];
  const passes = [];

  if (!own(capture.guest, 'code') || typeof capture.guest.code !== 'string') {
    unknowns.push('denial code unavailable');
  } else if (capture.guest.code !== 'AUTH_REQUIRED') {
    failures.push(`denial code is ${JSON.stringify(capture.guest.code)}, not "AUTH_REQUIRED"`);
  } else {
    passes.push('denial code is exactly "AUTH_REQUIRED"');
  }

  if (!own(capture.guest, 'bookingCreated') || typeof capture.guest.bookingCreated !== 'boolean') {
    unknowns.push('booking-creation outcome unavailable');
  } else if (capture.guest.bookingCreated !== false) {
    failures.push('a booking was created for the guest');
  } else {
    passes.push('no booking was created');
  }

  if (!own(capture.guest, 'message') || typeof capture.guest.message !== 'string') {
    unknowns.push('user-facing explanation unavailable');
  } else {
    const message = interpretSignInMessage(capture.guest.message);
    if (message.kind === 'failed') failures.push(message.detail);
    else if (message.kind === 'unassessed') unknowns.push(message.detail);
    else passes.push(message.detail);
  }

  if (failures.length) return { status: 'failed', reason: failures.join('; ') + '.' };
  if (unknowns.length) return { status: 'unassessed', reason: [...passes, ...unknowns].join('; ') + '.' };
  return { status: 'passed', reason: passes.join('; ') + '.' };
}

function parseLocalizedNumber(token) {
  let normalized = token.replace(/[\u00a0\u202f\s']/g, '');
  let sign = 1;
  if (normalized.startsWith('+') || normalized.startsWith('-')) {
    if (normalized.startsWith('-')) sign = -1;
    normalized = normalized.slice(1);
  }
  if (!/^\d[\d.,]*$/.test(normalized)) return null;

  const dots = [...normalized.matchAll(/\./g)].map((match) => match.index);
  const commas = [...normalized.matchAll(/,/g)].map((match) => match.index);
  let decimalSeparator = null;

  if (dots.length && commas.length) {
    const lastDot = dots[dots.length - 1];
    const lastComma = commas[commas.length - 1];
    const last = Math.max(lastDot, lastComma);
    const fractionLength = normalized.length - last - 1;
    if (fractionLength === 1 || fractionLength === 2) {
      decimalSeparator = normalized[last];
    }
  } else {
    const separator = dots.length ? '.' : commas.length ? ',' : null;
    if (separator) {
      const parts = normalized.split(separator);
      if (parts.length === 2 && (parts[1].length === 1 || parts[1].length === 2)) {
        decimalSeparator = separator;
      } else if (!parts.slice(1).every((part) => part.length === 3)) {
        return null;
      }
    }
  }

  let canonical;
  if (decimalSeparator) {
    const index = normalized.lastIndexOf(decimalSeparator);
    const whole = normalized.slice(0, index).replace(/[.,]/g, '');
    const fraction = normalized.slice(index + 1).replace(/[.,]/g, '');
    canonical = `${whole}.${fraction}`;
  } else {
    canonical = normalized.replace(/[.,]/g, '');
  }

  const value = sign * Number(canonical);
  return Number.isFinite(value) ? value : null;
}

function interpretFeeDisplay(display) {
  const text = compactText(display);
  if (text === '') return { kind: 'failed', detail: 'the displayed fee is empty' };

  const hasGbp = /£|\bGBP\b|\bsterling\b|\bBritish pounds?\b|\bpounds? sterling\b/i.test(text);
  const hasConflictingCurrency = /[$€¥₹]|\b(?:USD|EUR|CAD|AUD|NZD|JPY|CNY|CHF|INR)\b/i.test(text);
  if (hasGbp && hasConflictingCurrency) {
    return { kind: 'failed', detail: 'the display contains conflicting currency markers' };
  }
  if (!hasGbp && hasConflictingCurrency) {
    return { kind: 'failed', detail: 'the display identifies a currency other than GBP' };
  }

  const tokens = text.match(/[+-]?\d(?:[\d.,'\u00a0\u202f ]*\d)?/g) ?? [];
  const amounts = tokens.map(parseLocalizedNumber).filter((value) => value !== null);
  const uniqueAmounts = [...new Set(amounts)];

  if (!hasGbp) {
    return { kind: 'unassessed', detail: 'the display has no safely recognized GBP or sterling marker' };
  }
  if (uniqueAmounts.length === 0) {
    return { kind: 'unassessed', detail: 'the displayed numeric amount could not be interpreted safely' };
  }
  if (uniqueAmounts.length > 1) {
    if (!uniqueAmounts.includes(25)) {
      return { kind: 'failed', detail: 'none of the displayed numeric amounts is GBP 25.00' };
    }
    return { kind: 'unassessed', detail: 'the display contains multiple different numeric amounts' };
  }
  if (Math.abs(uniqueAmounts[0] - 25) > Number.EPSILON) {
    return { kind: 'failed', detail: `the displayed amount is ${uniqueAmounts[0]}, not 25.00` };
  }
  return { kind: 'passed', detail: 'the display conveys GBP 25.00 with an accepted locale-neutral representation' };
}

function evaluateFee(capture) {
  if (!own(capture, 'fee') || capture.fee === null || typeof capture.fee !== 'object') {
    return { status: 'unassessed', reason: 'The stored/displayed fee observation is unavailable.' };
  }

  const failures = [];
  const unknowns = [];
  const passes = [];

  if (!own(capture.fee, 'minorUnits') || typeof capture.fee.minorUnits !== 'number' || !Number.isFinite(capture.fee.minorUnits)) {
    unknowns.push('stored minor units unavailable');
  } else if (capture.fee.minorUnits !== 2500) {
    failures.push(`stored minor units are ${capture.fee.minorUnits}, not 2500`);
  } else {
    passes.push('stored minor units are 2500');
  }

  if (!own(capture.fee, 'currency') || typeof capture.fee.currency !== 'string') {
    unknowns.push('stored currency unavailable');
  } else if (capture.fee.currency.trim().toUpperCase() !== 'GBP') {
    failures.push(`stored currency is ${JSON.stringify(capture.fee.currency)}, not GBP`);
  } else {
    passes.push('stored currency is GBP');
  }

  if (!own(capture.fee, 'display') || typeof capture.fee.display !== 'string') {
    unknowns.push('displayed fee unavailable');
  } else {
    const display = interpretFeeDisplay(capture.fee.display);
    if (display.kind === 'failed') failures.push(display.detail);
    else if (display.kind === 'unassessed') unknowns.push(display.detail);
    else passes.push(display.detail);
  }

  if (failures.length) return { status: 'failed', reason: failures.join('; ') + '.' };
  if (unknowns.length) return { status: 'unassessed', reason: [...passes, ...unknowns].join('; ') + '.' };
  return { status: 'passed', reason: passes.join('; ') + '.' };
}

export function evaluate(capture) {
  const safeCapture = capture !== null && typeof capture === 'object' ? capture : {};
  const availability = evaluateAvailability(safeCapture);
  const legal = evaluateLegal(safeCapture);
  const guest = evaluateGuest(safeCapture);
  const fee = evaluateFee(safeCapture);

  return {
    availability: availability.status,
    legal: legal.status,
    guest: guest.status,
    fee: fee.status,
    reasons: {
      availability: availability.reason,
      legal: legal.reason,
      guest: guest.reason,
      fee: fee.reason,
    },
  };
}
