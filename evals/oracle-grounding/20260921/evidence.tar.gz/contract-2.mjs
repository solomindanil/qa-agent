const OUTCOME = Object.freeze({
  PASSED: 'passed',
  FAILED: 'failed',
  UNASSESSED: 'unassessed',
});

const FIXTURES = Object.freeze({
  '2026-10-01': Object.freeze([]),
  '2026-10-02': Object.freeze([
    Object.freeze({ id: 'slot-a', time: '09:00' }),
  ]),
});

const LEGAL_COPY = 'This service does not provide medical advice.';

function aggregate(clauses) {
  if (clauses.some((clause) => clause.outcome === OUTCOME.FAILED)) {
    return OUTCOME.FAILED;
  }
  if (clauses.every((clause) => clause.outcome === OUTCOME.PASSED)) {
    return OUTCOME.PASSED;
  }
  return OUTCOME.UNASSESSED;
}

function hasOwn(value, key) {
  return value !== null
    && typeof value === 'object'
    && Object.prototype.hasOwnProperty.call(value, key);
}

function observedSlot(slot) {
  return slot !== null
    && typeof slot === 'object'
    && typeof slot.id === 'string'
    && typeof slot.time === 'string';
}

function sameSlots(actual, expected) {
  if (actual.length !== expected.length) return false;

  const toKey = (slot) => `${slot.id.length}:${slot.id}|${slot.time.length}:${slot.time}`;
  const actualKeys = actual.map(toKey).sort();
  const expectedKeys = expected.map(toKey).sort();
  return actualKeys.every((key, index) => key === expectedKeys[index]);
}

function availabilityClauses(capture) {
  let appointments;
  if (typeof capture.date !== 'string' || !Array.isArray(capture.appointments)) {
    appointments = {
      outcome: OUTCOME.UNASSESSED,
      explanation: 'Date or appointments were not supplied as a usable fresh observation.',
    };
  } else if (!capture.appointments.every(observedSlot)) {
    appointments = {
      outcome: OUTCOME.UNASSESSED,
      explanation: 'At least one appointment lacks the observed string id/time needed for fixture comparison.',
    };
  } else if (!hasOwn(FIXTURES, capture.date)) {
    appointments = {
      outcome: OUTCOME.UNASSESSED,
      explanation: `No authoritative fixture expectation is supplied for ${capture.date}.`,
    };
  } else if (sameSlots(capture.appointments, FIXTURES[capture.date])) {
    appointments = {
      outcome: OUTCOME.PASSED,
      explanation: `Observed appointments exactly match the supplied fixture for ${capture.date}.`,
    };
  } else {
    appointments = {
      outcome: OUTCOME.FAILED,
      explanation: `Observed appointments do not exactly match the supplied fixture for ${capture.date}.`,
    };
  }

  let summary;
  if (!hasOwn(capture, 'summary')) {
    summary = {
      outcome: OUTCOME.UNASSESSED,
      explanation: 'No rendered summary observation was supplied.',
    };
  } else if (typeof capture.summary !== 'string') {
    summary = {
      outcome: OUTCOME.UNASSESSED,
      explanation: 'The summary observation is not text and cannot be interpreted.',
    };
  } else if (capture.summary.length === 0) {
    summary = {
      outcome: OUTCOME.FAILED,
      explanation: 'The supplied rendered summary is empty, so it cannot visibly agree with the count.',
    };
  } else {
    summary = {
      outcome: OUTCOME.UNASSESSED,
      explanation: 'Full summary text was captured, but its wording is unrestricted; semantic count agreement needs separate review rather than a keyword/regex oracle.',
      observedText: capture.summary,
      observedAppointmentCount: Array.isArray(capture.appointments)
        ? capture.appointments.length
        : null,
    };
  }

  return { appointments, summary };
}

function legalClause(capture) {
  if (!hasOwn(capture, 'legalText') || typeof capture.legalText !== 'string') {
    return {
      outcome: OUTCOME.UNASSESSED,
      explanation: 'Exact rendered legal text was not supplied.',
    };
  }
  if (capture.legalText === LEGAL_COPY) {
    return {
      outcome: OUTCOME.PASSED,
      explanation: 'Rendered legal text exactly matches the approved copy, including punctuation.',
    };
  }
  return {
    outcome: OUTCOME.FAILED,
    explanation: 'Rendered legal text does not exactly match the approved copy, including punctuation.',
  };
}

function guestClauses(capture) {
  const guest = capture.guest;
  if (guest === null || typeof guest !== 'object') {
    const unavailable = {
      outcome: OUTCOME.UNASSESSED,
      explanation: 'No usable guest-denial observation was supplied.',
    };
    return { denialCode: unavailable, bookingCreation: unavailable, message: unavailable };
  }

  const denialCode = !hasOwn(guest, 'code')
    ? {
        outcome: OUTCOME.UNASSESSED,
        explanation: 'The API denial code was not observed.',
      }
    : guest.code === 'AUTH_REQUIRED'
      ? {
          outcome: OUTCOME.PASSED,
          explanation: 'The API denial code exactly matches AUTH_REQUIRED.',
        }
      : {
          outcome: OUTCOME.FAILED,
          explanation: 'The observed API denial code is not AUTH_REQUIRED.',
        };

  const bookingCreation = !hasOwn(guest, 'bookingCreated')
    ? {
        outcome: OUTCOME.UNASSESSED,
        explanation: 'Booking creation state was not observed.',
      }
    : guest.bookingCreated === false
      ? {
          outcome: OUTCOME.PASSED,
          explanation: 'The observation records that no booking was created.',
        }
      : guest.bookingCreated === true
        ? {
            outcome: OUTCOME.FAILED,
            explanation: 'A booking was created for a guest, violating the requirement.',
          }
        : {
            outcome: OUTCOME.UNASSESSED,
            explanation: 'Booking creation state is not a usable boolean observation.',
          };

  let message;
  if (!hasOwn(guest, 'message') || typeof guest.message !== 'string') {
    message = {
      outcome: OUTCOME.UNASSESSED,
      explanation: 'No usable rendered guest explanation was supplied.',
    };
  } else if (guest.message.length === 0) {
    message = {
      outcome: OUTCOME.FAILED,
      explanation: 'The supplied rendered guest explanation is empty.',
    };
  } else {
    message = {
      outcome: OUTCOME.UNASSESSED,
      explanation: 'The explanation wording is unrestricted; whether the complete text conveys a sign-in requirement needs separate semantic review.',
      observedText: guest.message,
    };
  }

  return { denialCode, bookingCreation, message };
}

function parseDisplayedMoney(display) {
  if (typeof display !== 'string' || display.length === 0) return null;

  const hasGbp = /GBP/iu.test(display) || display.includes('\u00a3');
  const hasKnownOtherCurrency = /\b(?:USD|EUR|CAD|AUD)\b/iu.test(display)
    || /[$\u20ac]/u.test(display);
  const numericParts = display.match(/\d[\d\s\u00a0\u202f.,']*/gu) ?? [];

  if (numericParts.length !== 1) {
    return { hasGbp, hasKnownOtherCurrency, amount: null, interpretableAmount: false };
  }

  let token = numericParts[0].replace(/[\s\u00a0\u202f']/gu, '');
  const separators = [...token].reduce((positions, character, index) => {
    if (character === '.' || character === ',') positions.push(index);
    return positions;
  }, []);

  if (separators.length > 0) {
    const decimalIndex = separators[separators.length - 1];
    const fractionalLength = token.length - decimalIndex - 1;
    if (fractionalLength === 1 || fractionalLength === 2) {
      const whole = token.slice(0, decimalIndex).replace(/[.,]/gu, '');
      const fraction = token.slice(decimalIndex + 1);
      token = `${whole}.${fraction}`;
    } else if (separators.every((index) => token.length - index - 1 >= 3)) {
      token = token.replace(/[.,]/gu, '');
    } else {
      return { hasGbp, hasKnownOtherCurrency, amount: null, interpretableAmount: false };
    }
  }

  if (!/^\d+(?:\.\d{1,2})?$/u.test(token)) {
    return { hasGbp, hasKnownOtherCurrency, amount: null, interpretableAmount: false };
  }

  return {
    hasGbp,
    hasKnownOtherCurrency,
    amount: Number(token),
    interpretableAmount: Number.isFinite(Number(token)),
  };
}

function feeClauses(capture) {
  const fee = capture.fee;
  if (fee === null || typeof fee !== 'object') {
    const unavailable = {
      outcome: OUTCOME.UNASSESSED,
      explanation: 'No usable fee observation was supplied.',
    };
    return { storedAmount: unavailable, storedCurrency: unavailable, display: unavailable };
  }

  const storedAmount = !hasOwn(fee, 'minorUnits')
    ? {
        outcome: OUTCOME.UNASSESSED,
        explanation: 'Stored fee minor units were not observed.',
      }
    : fee.minorUnits === 2500
      ? {
          outcome: OUTCOME.PASSED,
          explanation: 'Stored fee is exactly 2500 minor units.',
        }
      : {
          outcome: OUTCOME.FAILED,
          explanation: 'Stored fee is not 2500 minor units.',
        };

  const storedCurrency = !hasOwn(fee, 'currency')
    ? {
        outcome: OUTCOME.UNASSESSED,
        explanation: 'Stored fee currency was not observed.',
      }
    : fee.currency === 'GBP'
      ? {
          outcome: OUTCOME.PASSED,
          explanation: 'Stored fee currency is exactly GBP.',
        }
      : {
          outcome: OUTCOME.FAILED,
          explanation: 'Stored fee currency is not GBP.',
        };

  let display;
  if (!hasOwn(fee, 'display') || typeof fee.display !== 'string') {
    display = {
      outcome: OUTCOME.UNASSESSED,
      explanation: 'Rendered fee text was not supplied.',
    };
  } else if (fee.display.length === 0) {
    display = {
      outcome: OUTCOME.FAILED,
      explanation: 'The supplied rendered fee text is empty.',
    };
  } else {
    const parsed = parseDisplayedMoney(fee.display);
    if (parsed.hasKnownOtherCurrency) {
      display = {
        outcome: OUTCOME.FAILED,
        explanation: 'Rendered fee contains an explicit non-GBP currency marker.',
      };
    } else if (parsed.interpretableAmount && parsed.amount !== 25) {
      display = {
        outcome: OUTCOME.FAILED,
        explanation: 'Rendered fee has an unambiguous amount that is not GBP 25.00.',
      };
    } else if (parsed.interpretableAmount && parsed.hasGbp) {
      display = {
        outcome: OUTCOME.PASSED,
        explanation: 'Rendered fee unambiguously expresses GBP 25.00 in an accepted locale-neutral form.',
      };
    } else {
      display = {
        outcome: OUTCOME.UNASSESSED,
        explanation: 'Rendered fee cannot be interpreted unambiguously as both GBP and 25.00 without assuming a locale or wording.',
        observedText: fee.display,
      };
    }
  }

  return { storedAmount, storedCurrency, display };
}

export function evaluate(capture) {
  const observed = capture !== null && typeof capture === 'object' ? capture : {};
  const availability = availabilityClauses(observed);
  const legal = legalClause(observed);
  const guest = guestClauses(observed);
  const fee = feeClauses(observed);

  return {
    availability: aggregate(Object.values(availability)),
    legal: legal.outcome,
    guest: aggregate(Object.values(guest)),
    fee: aggregate(Object.values(fee)),
    reasons: {
      availability,
      legal,
      guest,
      fee,
    },
  };
}

