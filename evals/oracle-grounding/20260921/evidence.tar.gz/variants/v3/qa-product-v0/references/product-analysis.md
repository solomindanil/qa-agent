# Product analysis and test design

Use this pass for an unfamiliar product, missing product knowledge or a material change. For an established product, inspect the changed area and its dependencies; reuse confirmed facts instead of restarting an interview. Analysis may precede registration and does not create a workspace, approve an oracle or authorize execution.

## Build a useful working model

Read the supplied brief, existing pack/graph, requirements and relevant tickets. Inspect available authorized documentation, UI, API or source code where they can answer a concrete question. Choose the smallest useful exploration; do not turn every source into a mandatory prerequisite.

In existing pack/checkpoint notes, capture:

- What the product promises, to whom, and what is outside its scope.
- Actors and role/resource/tenant boundaries; business objects, lifecycle states, critical journeys and observable outcomes.
- Relevant integrations, asynchronous transitions, data sensitivity and failure/recovery behavior.
- For each important claim: source/version, whether it is a requirement, an observation, a hypothesis or an unresolved question.

Current behavior, a role name or a newer-looking filename does not establish the intended rule. Resolve conflicting sources through actual authority/applicability, not invented chronology. Keep deployment identity unknown when it is unknown. Reading code does not enable unsupported source-aware registration.

## Clarify or investigate

First use facts already supplied and readily available authorized sources. When remaining uncertainty materially changes the test expectation, priority or scope, ask a short prioritized question: state the conflicting/missing rule and why its answer matters. Offer the user a genuine choice to answer or **“Разберись сам” / “Investigate it yourself”**. Do not make them complete a large questionnaire or repeat known facts.

- **User supplies the rule:** record its scope/source, reconcile any conflict and update only affected expectations and checks. An answer about business behavior is not approval to run mutations.
- **User chooses investigation:** pursue the question through available permitted sources/tools, then report the evidence, conclusion and remaining uncertainty. If useful material must be supplied, ask for that specific material rather than demand the business answer. Do not ask the same question repeatedly.
- **No answer yet, inaccessible evidence or unresolved normative choice:** preserve the question and affected checks; continue independent authorized analysis/checks. State what would unblock the remainder. Never silently pick one policy, treat silence as a choice, or mark the case passed.

Use the host's asynchronous question/input mechanism when available; otherwise keep the request in the dialogue and checkpoint. No scheduler or new interaction service is needed. Investigation is not permission for new accounts, credential extraction, product writes, payments or tracker publication. A delegated question that requires such an action remains a scoped authority gap.

## Derive checks from this product

Prioritize by likely impact and exposure, explaining the critical risks in plain language; no universal scoring formula is required. For selected journeys choose relevant normal, boundary/equivalence, role/tenant-negative, state-transition, recovery, concurrency or idempotency checks. State the expected outcome and its source; label an inferred desirable property as a hypothesis until supported. Do not declare extra forbidden transitions or permissions from an incomplete role/state list.

Before proposing checks or recording expectations in the catalog, review each material clause of a compound expected outcome: does its source support that clause and its scope? Could a reasonable implementation satisfy the source while contradicting that clause? Keep the supported outcome and its justified consequences; separate an unsupported desirable extension as a hypothesis to investigate. A clarification of one rule does not establish adjacent properties. This is a reasoning pass, not a new clause registry or a reason to stop independent checks.

Keep source-defined exact copy, identifiers, amounts/currency, denial codes and observable state strict; amount equality does not fix locale formatting. When authoring deterministic checks for unrestricted wording, capture the complete observed text and leave its semantic verdict unresolved; assess that wording in the separate agent-led evidence lane. Do not synthesize a keyword/regex classifier for unrestricted prose. Source-defined exact copy or a grammar explicitly defined by the authoritative requirement may still use deterministic matching. Preserve deterministic clause results: any established violation fails the check; otherwise unresolved meaning prevents PASS. Unknown wording is not itself a product defect, and an inherited literal checkpoint is not a wording requirement. Cite the capture and requirement in the separate agent assessment; it does not rewrite or promote the runner's receipt.

Consider responsive/UI, accessibility, performance, security and reliability where the product's use makes them relevant. Explain important omissions or lack of capability. A narrow functional result does not cover these areas, and their applicability is not a mandate to run a load/security probe. Avoid importing another product's payment, currency or provider rules.

Before execution, reconcile known requirements and risks with graph/catalog targets and the proposed checks: purpose, expectation/source, role/state/environment, required data and effects, selected lane, and gaps. Use existing fields/notes, not a new schema. An unmapped requirement remains a gap; graph presence is not test coverage. Keep critical unresolved checks visible while executing a justified independent subset.

## Carry knowledge forward

Present a compact product understanding, prioritized checks with reasons, open questions and independent next action. Preserve separate proposed, executed, supported, failed, blocked and unassessed counts; document review or an old screenshot is not a fresh product run.

Confirmed discoveries go through the product-owned graph/catalog revision and publication path in [declarative-campaign.md](declarative-campaign.md), with a relevant regression and next-task reuse where warranted. Hypotheses stay in notes/gaps, not confirmed edges. Use [agent-observations.md](agent-observations.md) for investigation outside the declarative adapter. Preserve existing identities, history and source limitations.
