---
name: qa-product-v0
description: Use when planning QA for an unfamiliar product or starting or resuming QA Starter product QA, including product packs, registered workspaces, authored checks, managed-browser checks, or work awaiting human help.
---

# Product QA from a fresh session

Drive product facts to checks, evidence, and a bounded result. Start with the product pack or supplied brief; discover missing knowledge instead of assuming a complete pack exists. Never invent business rules, credentials, deployment identity, permissions or whole-product coverage.

## Recover the working context

Read the pack and its checkpoint first: canonical QA workspace and tool repository, exact runtime revisions, product/environment URLs, graph, full catalog, expectations and their sources, current evidence, pending human requests, and allowed actions. Use the same workflow in Codex and Claude; discover the browser, plugin and human-input tools actually available in that runtime. Verify the selected paths and available tools locally. Do not select a repository or environment from its name or old conversation alone. Do not start another campaign when this one is paused.

Distinguish current observed identity, unknown identity, and historical evidence. A repository SHA or old staging PASS does not attest today's deployment. Candidate drift requires refreshing affected bindings and expectations before dependent execution; independent authorized source analysis can continue. Report missing facts as gaps without discarding known facts.

For a registered workspace, reuse its publication, graph and catalog. Read [declarative-campaign.md](references/declarative-campaign.md) for existing-plan validation, authored plans, or a knowledge revision. `generate-baseline` is an optional starting point, not a required reset or the only supported plan authoring path. `prepare` produces a draft with placeholders, not an executable campaign.

For a new registration only, use the existing `qa-init` command and registration path. Serialize `briefText` as canonical JSON:

```json
{"product":{"description":"<fact>","name":"<fact>"},"surfaces":[{"kind":"web","name":"<fact>"}],"journeys":[{"expectedOutcome":"<fact>","name":"<fact>"}],"risks":["<fact>"]}
```

Preserve a separate entry for every established surface, journey and risk. Outcomes must be observable postconditions. Intake kinds are `web`, `landing`, `api`, `tma_browser`, `native_ios`, `native_android`. The existing baseline intake needs a public HTTPS web/landing root; an unsupported intake or adapter does not establish that all agent-led checks are impossible. Do not rebuild an already registered workspace.

## Analyze before choosing checks

For an unfamiliar product, incomplete knowledge or material change, read [product-analysis.md](references/product-analysis.md) before deriving or revising checks. Build a sourced model of purpose, roles, states, journeys, dependencies and risks; choose a product-specific test design. Analysis can precede registration. For an established product, reuse its model and inspect the relevant delta rather than repeat onboarding.

Material uncertainty should produce a focused question with the option to answer or ask the agent to investigate independently. A pending answer blocks only dependent work; investigation does not expand execution authority. Follow the reference's clarification, evidence and coverage rules, then select the appropriate lane below.

## Select a supported lane for each check

| Lane | Conditions and evidence |
| --- | --- |
| Declarative campaign | Supported public, strictly read-only operations with exact graph/catalog/oracle bindings. Use the existing CLI and typed APIs in [declarative-campaign.md](references/declarative-campaign.md). Its sealed receipt describes only the selected campaign. |
| Agent-led tools | Available, authorized browser/API tools can cover behavior outside the declarative adapter. Discover actual capabilities and work in the selected environment. Use [agent-observations.md](references/agent-observations.md); caller observations are not attested campaign receipts. |
| Human assistance | A case needs access, a device, a decision, or observation the available tools cannot provide. Request the minimum help for that case and preserve independent progress. |

A zero executable declarative count prevents that CLI run; it does not stop separately authorized agent-led or source checks. Do not infer authenticated, native, payment, or other capabilities from a surface name or operation schema. Preserve unsupported and unrun targets in the coverage denominator.

## Ask for help without stopping independent work

Use facts and permissions already supplied. Ask only for information or action that actually blocks the next dependent step. After bounded reasonable attempts to diagnose a tool failure, stop repeating it and state the case, observed blocker, what the person should check/do, and the minimum result needed to resume. For an SMS challenge, use the available secure owner handoff and ask for completion, never for an OTP, password, token, or bypass of access controls.

If an authorized asynchronous human-input tool is available, use it and continue independent safe checks. Otherwise save the request and checkpoint, complete independent authorized work, and include the concrete request in the final reply. Pending help blocks only dependent scope. Do not invent a scheduler or promise an automatic wakeup.

Example: wallet access awaits owner SMS, while the public status page can still be assessed. Save case IDs, environment/identity, attempts, evidence, pending request, remaining scope and resume step. After the reply, read back the current origin, account/access signal and identity; verify the requested action actually completed before resuming that case.

An explicit user pause, candidate drift, or an action with unknown side effects remains a real boundary. An uncertain payment outcome is not permission to retry. Reconcile the original attempt through authorized read-only evidence; do not ask the person to repeat an unknown payment. Real-money, production mutations, irreversible actions and external publication require their own explicit authority; neither oracle approval nor a browser session grants it.

## Report and continue from evidence

Match each claim to its evidence: DOM presence alone does not prove rendered visibility or interaction success. Keep an unsupported part of an expectation unassessed even if the other parts match.

Separate checks verified, failed, blocked and unassessed, with the exact scope and denominator, environment/identity limitations, artifact paths and pending help. A partial result remains partial (`NEEDS_HUMAN`/`BLOCKED`/`UNASSESSED` as applicable), never whole-product PASS. A clean Starter self-test or stored observation is not a deployed-product verdict. Retain the checkpoint so a fresh session can continue without reconstructing permissions or treating history as current evidence.

## Publish confirmed dossiers

Nuanu Flow publication is a separate external action requiring explicit authority for the current concrete batch; registration and campaign approvals never authorize it. Use `nuanu-flow:work-items`. Resolve the exact project, state, Bug/area labels, priority and estimate scale; dedupe by dossier key and symptom. Show destination, dossier count and exact artifact paths. Check existing explicit authorization for that exact batch; request one batch confirmation only if it is missing or the scope changed. With that authority, create or reuse issues, upload screenshots, and read back each issue and attachment. A create/upload acknowledgement without both readbacks is partial, not published. If create/upload returns an unknown outcome, reconcile that same issue or attachment by its identifiers or dossier key before retrying; if readback is unavailable, checkpoint the pending write and request scoped help.
