# Existing declarative campaign path

Run commands from the selected Console repository; use the pack's absolute workspace and canonical `<workspace>/tests/qa-campaign.v0.json`. Check the actual CLI and Kernel pin before use. Console's campaign Kernel and an observation-capable Kernel can have different accepted revisions: do not replace one with the other or bypass a pin.

For a separately attributed interpretation of existing campaign artifacts, read [agent-observations.md](agent-observations.md). A supported `record-review`/`read-review` path preserves the runner evidence and verdict; use the report/checkpoint fallback when the selected paired runtime lacks it.

## Preserve or author the plan

Read the project, graph, full catalog and persisted plan first. An existing valid plan can go directly to validation; do not regenerate or delete it. For precise product assertions, the supported authored path is already demonstrated by `tests/unit/nuanu-authored-revision.test.ts` and `tests/fixtures/nuanu-readonly/fixture.ts` in Console:

1. If the existing graph/catalog already represent the check and resolved expectation, keep them. When new knowledge requires revision, use the accepted Kernel's `buildRegistrationKnowledgeRevision(authority, compilation)`, `previewRegistrationPublication(workspacePath, next, deps)`, then `applyRegistrationPublication(workspacePath, next, preview.previewDigest, deps)` and `validateWorkspace(workspacePath, deps)`. Review the exact proposed knowledge and digest under the task's authority before applying it. Never edit managed graph/catalog JSON directly. Retain registration context, previous requirements/kinds/coverage and discovery blockers; new or changed checks need resolved nonblank expectations. Active approval/run and stale preview guards still apply.
2. Build checks from the current catalog IDs, graph digest, product/environment and exact expected behavior; account for every target and catalog relationship as executable or blocked. Use `QaCampaignPlanV0Schema.parse(authoredPlan)` from `src/lib/qa-campaign-v0.ts`. Use `writeNewCampaignPlan(workspacePath, planPath, plan)` from `src/node/qa-campaign-files.ts` for an absent canonical plan. For an authorized revision of an existing plan use `writeCampaignPlan(workspacePath, planPath, plan, expectedCurrentDigest)`; preserve its compare-and-swap guard and read back the result. There is no generic authored-plan CLI subcommand. Use these existing APIs in a project-local script; do not copy fixture IDs or invent a CLI command.

For a suitable public-root baseline only, this optional command creates a new plan:

```bash
npm run qa-campaign -- generate-baseline --workspace <absolute-workspace> --plan <absolute-workspace>/tests/qa-campaign.v0.json
```

Its generated blockers are coverage gaps, not passed tests. Generic root assertions do not establish product business behavior. `prepare` only creates a draft; review and implement assertions through the supported authored path before treating it as executable.

## Oracle authority, validation, execution

Resolved catalog oracles require exact `expectedBehavior` and forbid `oracleBasis`; skip `approve-oracles` for them. For planned unresolved oracles only, preview:

```bash
npm run qa-campaign -- approve-oracles --workspace <absolute-workspace> --plan <absolute-workspace>/tests/qa-campaign.v0.json
```

Show exact questions, expected behaviors, targets and `approvalDigest`. Obtain explicit approval of that current batch, then apply only the reviewed digest:

```bash
npm run qa-campaign -- approve-oracles --workspace <absolute-workspace> --plan <absolute-workspace>/tests/qa-campaign.v0.json --approval-digest <reviewed-digest>
```

The CLI persists an approval receipt and updates the plan with digest checks. Never hand-author `oracleBasis`, fabricate an approval, or reuse a stale batch. Changed inputs require a fresh preview/review. Oracle approval grants check semantics; it is not execution authorization.

```bash
npm run qa-campaign -- validate --workspace <absolute-workspace> --plan <absolute-workspace>/tests/qa-campaign.v0.json
```

Inspect closure and executable/blocked counts. `ok:true` may coexist with `readyToRun:false`. Named blockers do not cancel a runnable safe subset: zero executable checks prevents `run`, while retained gaps keep a clean subset at `NEEDS_HUMAN`.

Immediately before `run`, re-read the persisted plan and present `planDigest`, registered `baseUrl`, executable check count and blocker count. Check execution authority separately from oracle approval. Continue when existing user authorization covers this current plan/environment/scope; otherwise obtain a separate confirmation for the concrete run. The CLI has no human-confirmation token: enforcing task authority remains the agent's responsibility, alongside the CLI's current identity, closure and pinned-Kernel checks before and after execution.

```bash
npm run qa-campaign -- run --workspace <absolute-workspace> --plan <absolute-workspace>/tests/qa-campaign.v0.json
```

This adapter supports public checks only: catalog runner `playwright`, compatible candidate/evidence routes, no required secrets; API GET/HEAD/OPTIONS. Browser execution creates a fresh context without an owner's authenticated session. Every `--allow-side-effect` value is rejected; it is not an override.

For public search/filter inputs, `fill` and `select` accept `{ "kind": "literal", "value": "..." }`. The author declares this data public and nonsecret: it is stored in the plan and is not credential-detected or redacted. Strings are at most4096 UTF-16 code units; empty strings and whitespace are preserved, with no interpolation. Use an empty fill to clear a search. Ground locators and option values in observed controls; for example, these actions assume the labels and option value were observed:

```json
[
  { "kind": "fill", "locator": { "kind": "label", "label": "Search" }, "value": { "kind": "literal", "value": "orchid" } },
  { "kind": "select", "locator": { "kind": "label", "label": "Category" }, "value": { "kind": "literal", "value": "outdoor" } },
  { "kind": "fill", "locator": { "kind": "label", "label": "Search" }, "value": { "kind": "literal", "value": "" } }
]
```

These are action examples, not a complete check. Each browser check has one fresh context; all of its actions share the same page. By default assertions run after the last operation, preserving existing plans.

For a same-session journey, put `afterOperationIndex` on the relevant assertion: it is a zero-based index into `operations`, not a new action. The executor completes that action, settles the page, evaluates the scheduled assertions in their declared order, and only then continues. The first failed intermediate assertion stops the remaining actions. Keep the effective indices nondecreasing; omitted means the last operation. At least one assertion must observe that terminal boundary. Invalid indices, ordering or an unobserved final action tail are rejected.

For example, if the independently sourced catalog contains Apple, Pear and Hammer and search is literal case-insensitive matching, this fragment checks narrowing and restoration in one page:

```json
{
  "operations": [
    { "kind": "navigate", "path": "/catalog" },
    { "kind": "fill", "locator": { "kind": "label", "label": "Search" }, "value": { "kind": "literal", "value": "apple" } },
    { "kind": "fill", "locator": { "kind": "label", "label": "Search" }, "value": { "kind": "literal", "value": "" } }
  ],
  "assertions": [
    { "kind": "count", "locator": { "kind": "testId", "testId": "item" }, "value": 1, "afterOperationIndex": 1 },
    { "kind": "text", "locator": { "kind": "testId", "testId": "item" }, "value": "Apple", "afterOperationIndex": 1 },
    { "kind": "count", "locator": { "kind": "testId", "testId": "item" }, "value": 3 },
    { "kind": "visible", "locator": { "kind": "text", "text": "Apple" } },
    { "kind": "visible", "locator": { "kind": "text", "text": "Pear" } },
    { "kind": "visible", "locator": { "kind": "text", "text": "Hammer" } }
  ]
}
```

Use the selected source schema to validate the whole graph/catalog-bound plan. Earlier runtimes lacking this field require the previously supported separate-prefix checks or an authorized agent-led observation; separate contexts do not prove a same-session journey. Never silently migrate an existing campaign. This extension is not browser crash replay.

The existing trace retains original numeric assertion indices in execution order; failure results retain `assertion-N` IDs. Inspect `totalEventCount` against retained events before claiming a complete trace. `tests/unit/browser-journey.test.ts` demonstrates both healthy and independently broken search/clear cases through the runner and actual evidence reader. Literal input does not authorize form submission, login, mutation or additional origins. Do not put credentials in literals or use environment references to bypass the catalog's required-secret restriction; credential-dependent checks remain in another supported lane.

Browser `visible` and `count` assertions accept one optional `observation`: `{ mode: "snapshot" }` (one read, the same as an absent field, whose canonical bytes stay unchanged), `{ mode: "eventual", timeoutMs }` for `visible` only (re-sampled until the first pass or one finite deadline), and `{ mode: "absence_window", timeoutMs }` for `count` 0 only (the whole declared window is sampled; sampling is not continuous). The budget comes from the declared expectation, is never tuned to obtain green, and must not exceed the adapter budget: a larger budget is an explicit harness configuration error, never silently shortened. The trace records the actual budget, elapsed time and sample count. Native actions, payments, mutations, arbitrary repository execution and unsupported behavior stay outside this lane.

Read `<workspace>/<runDirectory>/receipt.json`, every non-pass classification, `blockedTargets`, verdict, dossier, ticket and screenshot/trace path. Inspect evidence rather than just exit status (`NEEDS_HUMAN` is nonzero). The runner already repeats an eligible non-pass result once inside the same run (it does not repeat `pass` or `harness_failure`). Inspect the recorded attempts; never launch another CLI campaign automatically to obtain “two failures” when those attempts are already in the receipt. A new campaign needs a concrete diagnostic reason and current execution authority. Two oracle failures, even identical, classify as `needs_review` (`INCONCLUSIVE`) with both attempts retained and no automatic dossier: spending an assertion budget does not distinguish a wrong selector or expectation from a product defect. `needs_review` routes to the agent, not to a human: verify the expectation against its source and the current product identity, check page readiness and the locator against the freshly rendered state, and separate product, test mechanics and environment using the recorded attempts before any justified additional observation. Ask a human only for a concrete missing capability, access or decision. Record the diagnosis with references in the checkpoint/report; never rewrite an immutable receipt and never present that text as a sealed verdict. Before publication, verify the expectation against its source and current product version, inspect original expected-versus-actual evidence, and rule out hydration, locale, session, fixture and environment mismatches. Do not weaken the assertion to obtain green; unresolved oracle or harness problems remain unconfirmed and require diagnosis. `PASS` proves the exact registered scope, not whole-product or release readiness.
