# Authorized agent-led checks and observations

Use this lane when available tools can perform an authorized check the declarative adapter cannot. Tool availability is an observed fact, not an entitlement. Read the tool's current documentation, discover the actual capability and use the pack's environment, expectations and allowed actions. Do not create a new runner, auth bridge or service to compensate for an unsupported adapter.

## Review an existing campaign artifact

When the selected Console actually supports `record-review`/`read-review` and its exact paired Kernel pin, persist an interpretation of already-saved evidence without another product run. This is separate from recording new browser observations below. Do not change an accepted runtime pin merely to enable it; use checkpoint/report fallback if unavailable.

From that Console, send one sanitized JSON object (at most 64 KiB) to stdin:

```bash
npm run qa-campaign -- record-review --workspace <absolute-workspace>
# next session, using the returned reviewDigest:
npm run qa-campaign -- read-review --workspace <absolute-workspace> --review-digest sha256:<digest>
```

Both accept `--approval-store <absolute-root>` when the campaign uses an explicit oracle-approval store. The input contract is `AgentReviewDraftV0Schema` in `src/lib/qa-agent-review-v0.ts`:

- `expectedReceiptDigest`: canonical digest of the exact existing receipt, not a source SHA.
- `checkId`, `attempt` (1 or 2), and the plan's exact `expectedBehavior`.
- `artifacts`: one or more original inventory entries `{path, sha256, bytes}` belonging to that check and attempt. Inspect the actual referenced evidence first; do not copy another check's artifact or reinterpret absent traces as complete proof.
- `author: {agent, host, authoredAt}`: host is `codex`, `claude` or `other`; timestamp is when the review was authored, not when the screenshot was captured.
- `assessment: {kind, scope, actual, reasoning, expectationBasis, limitations}`: nonblank text; `limitations` is a nonempty array. Kind is `observed_as_expected`, `product_issue`, `oracle_issue`, `harness_issue`, `environment_issue` or `unresolved`. Explain the expectation's source and actual supporting observations; the label alone does not establish a bug.

Read back the returned `reviewDigest` and `record`, and save that digest/path in the owner checkpoint. The record is `agent_authored_unattested`: storage validates references, not the author's identity or reasoning. Different opinions coexist as separate records; no latest opinion wins automatically. An identical retry reconciles the same content; do not overwrite a conflicting record.

`currentBinding.state=current` means the review matches the newest valid **local campaign evidence**, not that the product is unchanged today. `historical` means a different current receipt exists; the older review's artifacts are not re-attested by this read. `unavailable` means current binding cannot be established. Preserve the original observed environment/identity and unknown deployment SHA. `campaignEvidence` is the separate, unchanged current runner result; none of these review states or classifications promotes its verdict, closes coverage, or authorizes a ticket write. Invalid/unavailable review reads are not successful retrieval or proof of absence. New unsaved CUA observations still use the accepted observation lane or report fallback below.

## Managed browser

Reuse the owner's existing authorized session through the documented browser tool. For CUA, follow its first-call rules: select an exact supplied browser/tab or inventory first, then select the exact tab returned. Check current origin and a positive signed-in/account signal. Ground navigation and locators in fresh rendered state; do not import cookies, tokens or storageState into the separate campaign adapter.

For a search check, use an existing non-sensitive visible witness and unique textbox, fill a meaningful substring, inspect the result, fill an absent probe, inspect no-match behavior, then clear and inspect recovery. Public read-only inputs may also use the declarative adapter's literal values; see [declarative-campaign.md](declarative-campaign.md). An authorized managed session remains a separate lane, not imported campaign authentication. Do not assume fixtures exist or create product records just to unblock a check. Missing login/witness or a failed tool leads to a bounded help request for that case, while independent authorized checks continue.

If owner sign-in/SMS is needed, discover the documented secure auth handoff if available. Ask the owner to complete it there, never to send credentials or a code to the agent. A submission or owner reply alone does not prove access: read back current rendered state and identity. Do not assume native, payment or auth capabilities are present. Unknown side effects, particularly a processing payment, must not be retried as a test recovery step.

## Store only what was observed

Capture fresh sanitized evidence with capture ID/time, exact observed outcomes, expected behavior, current identity and explicit unknowns. Historical evidence stays labelled with its original identity; source HEAD is not deployment attestation. Preserve unrun aspects such as filters/realtime even when search succeeds. Sanitize private data before computing hashes; do not store credentials, OTPs or session dumps.

### Write, recover and inspect scope

When the selected Console and its exact accepted Kernel support this channel, run from that Console with an explicit Kernel path and the existing absolute workspace:

```bash
export QA_STARTER_REPO=/absolute/path/to/accepted-kernel
npm run qa-campaign -- record-observation --workspace /absolute/product/workspace < /absolute/private/observation.json
npm run qa-campaign -- read-observation --workspace /absolute/product/workspace --evidence-id 'urn:qa:evidence:<24-hex-id>'
npm run qa-campaign -- observations --workspace /absolute/product/workspace
```

`record-observation` accepts one UTF-8 JSON stdin object with exactly two keys: `{ "manifest": <EvidenceManifestV1>, "artifact": <AgentToolObservationPayloadV1> }`. The **entire stdin envelope is at most 65,536 bytes (64 KiB)**. The CLI canonicalizes `artifact` before passing its bytes to the existing writer; compute the manifest's content digest and byte size from those same canonical bytes. These commands do not accept the review lane's `--approval-store`, a campaign plan, or a side-effect override.

The payload schema is `AgentToolObservationPayloadV1Schema` in the selected Kernel's `src/contracts/agent-tool-observation.ts`: `schemaVersion: "agent-tool-observation.v1"`, `provenance: "agent_authored_unattested"`, nonblank `scope`, `expectedBehavior`, `expectationBasis`, `actual`, `tool`; `result` is `passed`, `failed`, `partial`, `not_run` or `unknown`; `author` has nonblank `agent`, `host` (`codex`, `claude`, `other`) and ISO `authoredAt`; `limitations` is a nonempty array of nonblank strings; **`attachments` must be `[]`**. Screenshot, file and binary attachments are not supported by this channel. Keep separately authorized screenshots in their existing evidence lane; do not embed them as base64/text or claim this record verifies them.

Use the returned evidence ID to recover a record, and `observations` to read the full target scope, definitions, recorded observations, unobserved targets and diagnostics. A recorded target is not automatically passed: retain partial results and conflicting observations. An unavailable/invalid read is not proof of zero observations. For an observation, `currentBinding: "current"` means the existing local publication still matches; `historical` retains its original attribution, not current acceptance. Neither proves the deployed product is unchanged. Resume from the stored scope and limitations, then choose the next independent authorized check; do not repeat a completed action merely to reconstruct its result.

The same accepted Kernel exposes these APIs for direct callers:

```ts
const saved = await qa.recordAgentToolObservation({ workspacePath, manifest, artifactBytes });
const checked = await qa.readAgentToolObservation({ workspacePath, evidenceId });
const scope = await qa.readTargetObservationReport({ workspacePath });
```

Resolve these public exports from that accepted runtime; do not assume Console's pinned campaign Kernel has them. A valid manifest needs one `agent_tool_observation` entry with `adapterId: agent/tool`, a new evidence ID, owner-derived artifact path, sanitized bytes/hash/size, current publication/strategy and check-to-target bindings, reviewed verifies and resolved nonblank oracle. Use the runtime's `EvidenceManifestV1Schema` and semantic/digest helpers. If binding/oracle is missing, prepare a reviewed knowledge revision via the existing publication APIs; preserve gaps instead of borrowing a historical ID. If this runtime or binding is unavailable, retain clearly labelled local observations and the storage blocker; do not claim a sealed record.

The writer validates stored bytes and current bindings; it does not execute the browser action, validate claimed capture time/outcome, or create an attested campaign receipt. `record` permission does not authorize product interaction. Identity fields are caller-declared: preserve their provenance and unknowns. Read back IDs, manifest and artifact bytes/hash/size. Stored observations do not change managed coverage, runner receipts or release verdicts.

Keep an evidence ID immutable. Retry the same stored bytes/manifest after a write interruption; a new capture needs a new ID. Artifact and manifest are separate atomic writes, so an interrupted pair may leave artifact-only state. Never “repair” a conflict by overwriting historical evidence. Report bounded observed outcomes and remaining BLOCKED/UNASSESSED scope, not automated or whole-product PASS.
