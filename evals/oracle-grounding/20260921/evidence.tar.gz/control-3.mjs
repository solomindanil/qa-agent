const FIXTURES = Object.freeze({
  '2026-10-01': Object.freeze([]),
  '2026-10-02': Object.freeze([
    Object.freeze({ id: 'slot-a', time: '09:00' }),
  ]),
});

const WORD_COUNTS = Object.freeze({
  no: 0,
  zero: 0,
  one: 1,
  two: 2,
  three: 3,
  four: 4,
  five: 5,
  six: 6,
  seven: 7,
  eight: 8,
  nine: 9,
  ten: 10,
  eleven: 11,
  twelve: 12,
});

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function clause(status, explanation, expected, observed) {
  const result = { status, explanation };
  if (expected !== undefined) result.expected = expected;
  if (observed !== undefined) result.observed = observed;
  return result;
}

function aggregate(clauses) {
  const statuses = Object.values(clauses).map((item) => item.status);
  if (statuses.includes('failed')) return 'failed';
  if (statuses.length > 0 && statuses.every((status) => status === 'passed')) {
    return 'passed';
  }
  return 'unassessed';
}

function parseGroupedInteger(token) {
  const compact = token
    .normalize('NFKC')
    .replace(/[\s\u00a0\u202f'’]/gu, '');

  if (/^\d+$/u.test(compact)) return Number(compact);
  if (!/^\d{1,3}(?:[.,]\d{3})+$/u.test(compact)) return null;

  const value = Number(compact.replace(/[.,]/gu, ''));
  return Number.isSafeInteger(value) ? value : null;
}

function parseSummaryCount(summary) {
  const normalized = summary.normalize('NFKC').trim();
  if (normalized === '') return null;

  const number = String.raw`(\d[\d\s\u00a0\u202f,.'’]*|no|zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)`;
  const before = new RegExp(`${number}\\s+(?:available\\s+)?appointments?\\b`, 'giu');
  const after = new RegExp(`\\bappointments?\\b(?:\\s+(?:available|found))?\\s*[:=()\\-–—]*\\s*${number}`, 'giu');
  const candidates = [];

  for (const pattern of [before, after]) {
    for (const match of normalized.matchAll(pattern)) {
      const raw = match[1].trim().toLowerCase();
      const value = Object.prototype.hasOwnProperty.call(WORD_COUNTS, raw)
        ? WORD_COUNTS[raw]
        : parseGroupedInteger(raw);
      if (value !== null && Number.isSafeInteger(value)) candidates.push(value);
    }
  }

  const unique = [...new Set(candidates)];
  return unique.length === 1 ? unique[0] : null;
}

function availabilityClauses(capture) {
  const clauses = {};
  const date = capture.date;
  const appointments = capture.appointments;
  const fixture = typeof date === 'string' ? FIXTURES[date] : undefined;

  if (fixture === undefined) {
    clauses.fixtureCount = clause(
      'unassessed',
      'No approved appointment fixture is available for the captured date.',
      'An approved date-specific appointment count.',
      date,
    );
    clauses.fixtureEntries = clause(
      'unassessed',
      'The exact appointment identities and times cannot be checked without an approved fixture for this date.',
    );
  } else if (!Array.isArray(appointments)) {
    clauses.fixtureCount = clause(
      'unassessed',
      'The appointments observation is unavailable or is not an array.',
      fixture.length,
      appointments,
    );
    clauses.fixtureEntries = clause(
      'unassessed',
      'Appointment identities and times are unavailable because the appointments observation is not an array.',
    );
  } else {
    clauses.fixtureCount = appointments.length === fixture.length
      ? clause('passed', 'The rendered appointment count matches the approved fixture.', fixture.length, appointments.length)
      : clause('failed', 'The rendered appointment count contradicts the approved fixture.', fixture.length, appointments.length);

    const entriesAreReadable = appointments.every(
      (entry) => isRecord(entry) && typeof entry.id === 'string' && typeof entry.time === 'string',
    );

    if (!entriesAreReadable) {
      clauses.fixtureEntries = clause(
        'unassessed',
        'At least one appointment lacks a readable string id or time.',
        fixture,
        appointments,
      );
    } else {
      const observedEntries = appointments
        .map(({ id, time }) => ({ id, time }))
        .sort((left, right) => `${left.id}\u0000${left.time}`.localeCompare(`${right.id}\u0000${right.time}`));
      const expectedEntries = fixture
        .map(({ id, time }) => ({ id, time }))
        .sort((left, right) => `${left.id}\u0000${left.time}`.localeCompare(`${right.id}\u0000${right.time}`));
      const matches = JSON.stringify(observedEntries) === JSON.stringify(expectedEntries);
      clauses.fixtureEntries = matches
        ? clause('passed', 'The appointment id/time set matches the approved fixture.', expectedEntries, observedEntries)
        : clause('failed', 'The appointment id/time set contradicts the approved fixture.', expectedEntries, observedEntries);
    }
  }

  if (!Array.isArray(appointments)) {
    clauses.summaryCount = clause(
      'unassessed',
      'Summary agreement cannot be calculated without an appointment array.',
    );
  } else if (typeof capture.summary !== 'string') {
    clauses.summaryCount = clause(
      'unassessed',
      'The rendered summary text is unavailable.',
      appointments.length,
      capture.summary,
    );
  } else if (capture.summary.trim() === '') {
    clauses.summaryCount = clause(
      'failed',
      'The observed summary is empty, so no visible count is conveyed.',
      appointments.length,
      capture.summary,
    );
  } else {
    const summaryCount = parseSummaryCount(capture.summary);
    if (summaryCount === null) {
      clauses.summaryCount = clause(
        'unassessed',
        'The summary is present, but its appointment count cannot be interpreted unambiguously.',
        appointments.length,
        capture.summary,
      );
    } else {
      clauses.summaryCount = summaryCount === appointments.length
        ? clause('passed', 'The summary count agrees with the rendered appointment count.', appointments.length, summaryCount)
        : clause('failed', 'The summary count disagrees with the rendered appointment count.', appointments.length, summaryCount);
    }
  }

  return clauses;
}

function legalClauses(capture) {
  const expected = 'This service does not provide medical advice.';
  if (typeof capture.legalText !== 'string') {
    return {
      exactCopy: clause('unassessed', 'The rendered legal text is unavailable.', expected, capture.legalText),
    };
  }

  return {
    exactCopy: capture.legalText === expected
      ? clause('passed', 'The legal text exactly matches the approved copy.', expected, capture.legalText)
      : clause('failed', 'The legal text differs from the approved copy, including punctuation or whitespace.', expected, capture.legalText),
  };
}

function assessSignInMessage(message) {
  if (typeof message !== 'string') {
    return clause('unassessed', 'The guest-facing explanation is unavailable.', 'A message conveying that sign-in is needed.', message);
  }

  const normalized = message.normalize('NFKC').trim().toLowerCase().replace(/\s+/gu, ' ');
  if (normalized === '') {
    return clause('failed', 'The observed guest-facing explanation is empty.', 'A message conveying that sign-in is needed.', message);
  }

  const signInTerm = String.raw`(?:sign[ -]?in|log[ -]?in|login|authenticate|authentication)`;
  const negations = [
    new RegExp(String.raw`\b(?:do|does|did)\s+not\s+(?:need|have)\b.{0,32}\b${signInTerm}\b`, 'iu'),
    new RegExp(String.raw`\b${signInTerm}\b.{0,24}\bnot\s+(?:needed|required)\b`, 'iu'),
    new RegExp(String.raw`\bno\s+${signInTerm}\b.{0,16}\b(?:needed|required)\b`, 'iu'),
  ];
  if (negations.some((pattern) => pattern.test(normalized))) {
    return clause('failed', 'The explanation says that sign-in is not needed.', 'A message conveying that sign-in is needed.', message);
  }

  const positivePatterns = [
    new RegExp(String.raw`\b(?:please\s+)?(?:sign|log)[ -]?in\b`, 'iu'),
    /\blogin\s+(?:is\s+)?required\b/iu,
    /\bauthentication\s+(?:is\s+)?required\b/iu,
    /\b(?:must|need(?:s)?\s+to|required\s+to)\s+authenticate\b/iu,
    /\b(?:an?\s+)?account\s+(?:is\s+)?required\b/iu,
  ];
  if (positivePatterns.some((pattern) => pattern.test(normalized))) {
    return clause('passed', 'The explanation directly conveys that sign-in or authentication is needed.', 'A message conveying that sign-in is needed.', message);
  }

  if (/\b(?:sign|log)[ -]?in\b|\blogin\b|\bauth(?:enticate|entication)\b/iu.test(normalized)) {
    return clause('unassessed', 'The explanation mentions authentication, but the bounded lexical oracle cannot determine that it is required.', 'A message conveying that sign-in is needed.', message);
  }

  return clause('failed', 'The explanation does not convey that sign-in is needed.', 'A message conveying that sign-in is needed.', message);
}

function guestClauses(capture) {
  if (!isRecord(capture.guest)) {
    return {
      denialCode: clause('unassessed', 'The guest API observation is unavailable.', 'AUTH_REQUIRED'),
      noBookingCreated: clause('unassessed', 'Booking creation state is unavailable.', false),
      signInExplanation: clause('unassessed', 'The guest-facing explanation is unavailable.', 'A message conveying that sign-in is needed.'),
    };
  }

  const { guest } = capture;
  const denialCode = typeof guest.code !== 'string'
    ? clause('unassessed', 'The API denial code is unavailable.', 'AUTH_REQUIRED', guest.code)
    : guest.code === 'AUTH_REQUIRED'
      ? clause('passed', 'The API denial code exactly matches the requirement.', 'AUTH_REQUIRED', guest.code)
      : clause('failed', 'The API denial code contradicts the requirement.', 'AUTH_REQUIRED', guest.code);

  let noBookingCreated;
  if (typeof guest.bookingCreated !== 'boolean') {
    noBookingCreated = clause('unassessed', 'Booking creation state is unavailable.', false, guest.bookingCreated);
  } else if (guest.bookingCreated === false) {
    noBookingCreated = clause('passed', 'The observation confirms that no booking was created.', false, guest.bookingCreated);
  } else {
    noBookingCreated = clause('failed', 'A booking was created for a guest.', false, guest.bookingCreated);
  }

  return {
    denialCode,
    noBookingCreated,
    signInExplanation: assessSignInMessage(guest.message),
  };
}

function numericTokenToMinorUnits(token) {
  let compact = token.normalize('NFKC').replace(/[\s\u00a0\u202f'’]/gu, '');
  compact = compact.replace(/^[.,]+|[.,]+$/gu, '');
  if (!/^\d+(?:[.,]\d+)*$/u.test(compact)) return null;

  const dots = [...compact.matchAll(/\./gu)].map((match) => match.index);
  const commas = [...compact.matchAll(/,/gu)].map((match) => match.index);
  let decimalIndex = -1;

  if (dots.length > 0 && commas.length > 0) {
    decimalIndex = Math.max(dots.at(-1), commas.at(-1));
  } else {
    const separators = dots.length > 0 ? dots : commas;
    if (separators.length > 0) {
      const last = separators.at(-1);
      const fractionLength = compact.length - last - 1;
      if (fractionLength === 1 || fractionLength === 2) decimalIndex = last;
    }
  }

  let whole;
  let fraction = '';
  if (decimalIndex >= 0) {
    whole = compact.slice(0, decimalIndex).replace(/[.,]/gu, '');
    fraction = compact.slice(decimalIndex + 1);
    if (!/^\d{1,2}$/u.test(fraction)) return null;
  } else {
    const groupingPattern = /^\d{1,3}(?:([.,])\d{3})(?:\1\d{3})*$/u;
    if (/[.,]/u.test(compact) && !groupingPattern.test(compact)) return null;
    whole = compact.replace(/[.,]/gu, '');
  }

  if (!/^\d+$/u.test(whole)) return null;
  const minor = BigInt(whole) * 100n + BigInt((fraction + '00').slice(0, 2));
  return minor;
}

function feeDisplayClauses(display) {
  if (typeof display !== 'string') {
    return {
      displayCurrency: clause('unassessed', 'The rendered fee display is unavailable.', 'GBP', display),
      displayAmount: clause('unassessed', 'The rendered fee amount is unavailable.', 2500, display),
    };
  }

  if (display.trim() === '') {
    return {
      displayCurrency: clause('failed', 'The observed fee display is empty and does not show GBP.', 'GBP', display),
      displayAmount: clause('failed', 'The observed fee display is empty and does not show GBP 25.00.', 2500, display),
    };
  }

  const hasGbp = /\bGBP\b/iu.test(display) || /£/u.test(display);
  const hasConflictingMarker = /[$€¥₹₽]/u.test(display)
    || /\b(?:USD|EUR|JPY|CNY|AUD|CAD|CHF|INR|RUB)\b/iu.test(display);
  const displayCurrency = hasGbp && !hasConflictingMarker
    ? clause('passed', 'The displayed currency is identifiable as GBP.', 'GBP', display)
    : clause('failed', hasConflictingMarker
      ? 'The fee display contains a currency marker that conflicts with GBP.'
      : 'The fee display does not identify GBP.', 'GBP', display);

  const tokens = display.match(/\d[\d\s\u00a0\u202f,.'’]*/gu) ?? [];
  const parsed = tokens
    .map((token) => numericTokenToMinorUnits(token))
    .filter((value) => value !== null);
  let displayAmount;
  if (parsed.length === 0) {
    displayAmount = clause('unassessed', 'No unambiguous numeric amount can be interpreted from the fee display.', 2500, display);
  } else if (parsed.length > 1) {
    displayAmount = clause('unassessed', 'Multiple numeric amounts make the fee display ambiguous.', 2500, display);
  } else if (parsed[0] === 2500n) {
    displayAmount = clause('passed', 'The displayed amount represents 2500 minor units.', 2500, display);
  } else {
    displayAmount = clause('failed', 'The displayed amount does not represent 2500 minor units.', 2500, display);
  }

  return { displayCurrency, displayAmount };
}

function feeClauses(capture) {
  if (!isRecord(capture.fee)) {
    return {
      storedAmount: clause('unassessed', 'The stored fee observation is unavailable.', 2500),
      storedCurrency: clause('unassessed', 'The stored currency observation is unavailable.', 'GBP'),
      displayCurrency: clause('unassessed', 'The rendered fee display is unavailable.', 'GBP'),
      displayAmount: clause('unassessed', 'The rendered fee amount is unavailable.', 2500),
    };
  }

  const { fee } = capture;
  const storedAmount = typeof fee.minorUnits !== 'number' || !Number.isSafeInteger(fee.minorUnits)
    ? clause('unassessed', 'The stored minor-unit value is unavailable or not an integer.', 2500, fee.minorUnits)
    : fee.minorUnits === 2500
      ? clause('passed', 'The stored fee is exactly 2500 minor units.', 2500, fee.minorUnits)
      : clause('failed', 'The stored fee contradicts the required 2500 minor units.', 2500, fee.minorUnits);

  const storedCurrency = typeof fee.currency !== 'string'
    ? clause('unassessed', 'The stored currency is unavailable.', 'GBP', fee.currency)
    : fee.currency === 'GBP'
      ? clause('passed', 'The stored currency exactly matches GBP.', 'GBP', fee.currency)
      : clause('failed', 'The stored currency contradicts GBP.', 'GBP', fee.currency);

  return {
    storedAmount,
    storedCurrency,
    ...feeDisplayClauses(fee.display),
  };
}

/**
 * Evaluate one fresh rendered/API observation without performing product actions.
 * A failed clause dominates its oracle; otherwise every clause must pass for the
 * oracle to pass. Missing or uninterpretable evidence therefore stays unassessed.
 */
export function evaluate(capture) {
  const safeCapture = isRecord(capture) ? capture : {};
  const availability = availabilityClauses(safeCapture);
  const legal = legalClauses(safeCapture);
  const guest = guestClauses(safeCapture);
  const fee = feeClauses(safeCapture);

  return {
    availability: aggregate(availability),
    legal: aggregate(legal),
    guest: aggregate(guest),
    fee: aggregate(fee),
    reasons: { availability, legal, guest, fee },
  };
}
