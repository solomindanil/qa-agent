// Additional reviewer-derived diagnostic, kept separate from frozen 21 cases.
// Offline generated artifacts only; never a product/campaign verdict.
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
const base = {
  date: '2026-10-02', appointments: [{ id: 'slot-a', time: '09:00' }],
  summary: '1 appointment',
  legalText: 'This service does not provide medical advice.',
  guest: { code: 'AUTH_REQUIRED', bookingCreated: false, message: '' },
  fee: { minorUnits: 2500, currency: 'GBP', display: '£25.00' },
};
for (const file of process.argv.slice(2)) {
  const { evaluate } = await import(pathToFileURL(resolve(file)).href);
  const cases = [];
  for (const [message, allowed] of [
    ['No sign-in is required', ['failed', 'unassessed']],
    ['You cannot book without signing in', ['passed', 'unassessed']],
  ]) {
    const capture = structuredClone(base);
    capture.guest.message = message;
    const result = await evaluate(capture);
    cases.push({ capture, allowed, result, wrongDefinitiveVerdict: !allowed.includes(result.guest) });
  }
  console.log(JSON.stringify({ file, cases }));
}
