const STATUS = Object.freeze({
  PASSED: 'passed',
  FAILED: 'failed',
  UNASSESSED: 'unassessed',
});

const LEGAL_COPY = 'This service does not provide medical advice.';

const AVAILABILITY_FIXTURES = Object.freeze({
  '2026-10-01': [],
  '2026-10-02': [{ id: 'slot-a', time: '09:00' }],
});

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function outcome(clauses) {
  const values = Object.values(clauses).map((clause) => clause.status);
  if (values.includes(STATUS.FAILED)) return STATUS.FAILED;
  if (values.length > 0 && values.every((value) => value === STATUS.PASSED)) {
    return STATUS.PASSED;
  }
  return STATUS.UNASSESSED;
}

function clause(status, detail) {
  return { status, detail };
}

function parseEnglishSummaryCount(summary) {
  if (typeof summary !== 'string') {
    return { status: STATUS.UNASSESSED, detail: 'No rendered summary text was supplied.' };
  }

  const text = summary.trim();
  if (text === '') {
    return { status: STATUS.FAILED, detail: 'The rendered summary is empty.' };
  }

  // A summary may contain formatting around its count, but two different numeric
  // candidates would make the intended appointment count ambiguous.
  const numericTokens = [...text.matchAll(/(?<![\p{L}\p{N}])\d[\d,]*(?![\p{L}\p{N}])/gu)]
    .map((match) => match[0]);
  const numericCounts = numericTokens
    .map((token) => token.replaceAll(',', ''))
    .filter((token) => /^\d+$/.test(token))
    .map(Number)
    .filter(Number.isSafeInteger);

  const words = text.toLocaleLowerCase('en');
  const wordCounts = [];
  const supportedWords = [
    ['zero', 0],
    ['no', 0],
    ['one', 1],
    ['two', 2],
    ['three', 3],
    ['four', 4],
    ['five', 5],
    ['six', 6],
    ['seven', 7],
    ['eight', 8],
    ['nine', 9],
    ['ten', 10],
  ];

  for (const [word, value] of supportedWords) {
    // Word interpretations are limited to wording tied directly to appointments.
    const pattern = new RegExp(`\\b${word}\\s+(?:available\\s+)?appointments?\\b`, 'u');
    if (pattern.test(words)) wordCounts.push(value);
  }

  const distinct = [...new Set([...numericCounts, ...wordCounts])];
  if (distinct.length === 1) {
    return {
      status: STATUS.PASSED,
      count: distinct[0],
      detail: `The summary unambiguously reports ${distinct[0]} appointment(s).`,
    };
  }
  if (distinct.length > 1) {
    return {
      status: STATUS.UNASSESSED,
      detail: `The summary has conflicting count interpretations: ${distinct.join(', ')}.`,
    };
  }
  return {
    status: STATUS.UNASSESSED,
    detail: 'The English summary does not expose a count this deterministic oracle can interpret.',
  };
}

function exactAppointmentsClause(capture) {
  if (!isRecord(capture) || typeof capture.date !== 'string') {
    return clause(STATUS.UNASSESSED, 'No selected date was supplied.');
  }
  if (!Array.isArray(capture.appointments)) {
    return clause(STATUS.UNASSESSED, 'No rendered appointment list was supplied.');
  }

  const expected = AVAILABILITY_FIXTURES[capture.date];
  if (!expected) {
    return clause(
      STATUS.UNASSESSED,
      `No independent fixture establishes the exact appointments for ${capture.date}.`,
    );
  }

  const matches = capture.appointments.length === expected.length
    && expected.every((wanted, index) => {
      const actual = capture.appointments[index];
      return isRecord(actual) && actual.id === wanted.id && actual.time === wanted.time;
    });

  return matches
    ? clause(STATUS.PASSED, `The rendered list exactly matches the ${capture.date} fixture.`)
    : clause(
      STATUS.FAILED,
      `The rendered list does not match the ${capture.date} fixture ${JSON.stringify(expected)}.`,
    );
}

function summaryClause(capture) {
  if (!isRecord(capture)) {
    return clause(STATUS.UNASSESSED, 'No capture was supplied.');
  }

  const parsed = parseEnglishSummaryCount(capture.summary);
  if (parsed.status !== STATUS.PASSED) return clause(parsed.status, parsed.detail);

  let expectedCount;
  let basis;
  if (Array.isArray(capture.appointments)) {
    expectedCount = capture.appointments.length;
    basis = 'the rendered appointment list';
  } else if (typeof capture.date === 'string' && AVAILABILITY_FIXTURES[capture.date]) {
    expectedCount = AVAILABILITY_FIXTURES[capture.date].length;
    basis = `the ${capture.date} fixture`;
  } else {
    return clause(
      STATUS.UNASSESSED,
      `${parsed.detail} No rendered list or dated fixture is available for comparison.`,
    );
  }

  return parsed.count === expectedCount
    ? clause(STATUS.PASSED, `The visible summary count agrees with ${basis} (${expectedCount}).`)
    : clause(
      STATUS.FAILED,
      `The visible summary reports ${parsed.count}, but ${basis} has ${expectedCount}.`,
    );
}

function assessAvailability(capture) {
  const clauses = {
    exactAppointments: exactAppointmentsClause(capture),
    visibleSummary: summaryClause(capture),
  };
  return { outcome: outcome(clauses), clauses };
}

function assessLegal(capture) {
  let exactCopy;
  if (!isRecord(capture) || typeof capture.legalText !== 'string') {
    exactCopy = clause(STATUS.UNASSESSED, 'No complete rendered legal text was supplied.');
  } else if (capture.legalText === LEGAL_COPY) {
    exactCopy = clause(STATUS.PASSED, 'The legal text exactly matches the approved copy.');
  } else {
    exactCopy = clause(
      STATUS.FAILED,
      `The legal text differs from the approved exact copy ${JSON.stringify(LEGAL_COPY)}.`,
    );
  }
  const clauses = { exactCopy };
  return { outcome: outcome(clauses), clauses };
}

function explainSignInMessage(message) {
  if (typeof message !== 'string') {
    return clause(STATUS.UNASSESSED, 'No complete user-facing guest explanation was supplied.');
  }

  const normalized = message
    .normalize('NFKC')
    .toLocaleLowerCase('en')
    .replace(/sign[\s-]?in/g, 'sign in')
    .replace(/log[\s-]?in/g, 'log in')
    .replace(/\s+/g, ' ')
    .trim();

  if (normalized === '') {
    return clause(STATUS.FAILED, 'The user-facing explanation is empty.');
  }

  const contradiction = /(?:do(?:es)? not|don['’]?t|no) need to (?:sign|log) in|without (?:signing|logging) in|(?:signing|logging) in is optional|guests? (?:can|may) book/u;
  if (contradiction.test(normalized)) {
    return clause(STATUS.FAILED, 'The explanation says or implies that guest booking is allowed without sign-in.');
  }

  const explicitRequirement = [
    /(?:must|need(?:s)? to|required to|have to|please) (?:sign|log) in\b/u,
    /(?:sign|log) in (?:is )?(?:required|needed)\b/u,
    /(?:sign|log) in to (?:book|continue|make|schedule|reserve)\b/u,
    /authentication (?:is )?(?:required|needed)\b/u,
    /authenticate to (?:book|continue|make|schedule|reserve)\b/u,
    /only (?:signed in|authenticated) (?:users?|customers?|patients?) (?:can|may) book\b/u,
    /only (?:users?|customers?|patients?) who are (?:signed in|authenticated) (?:can|may) book\b/u,
  ];

  if (explicitRequirement.some((pattern) => pattern.test(normalized))) {
    return clause(STATUS.PASSED, 'The explanation unambiguously conveys that sign-in is required.');
  }

  return clause(
    STATUS.UNASSESSED,
    'The supplied English wording is not an unambiguous sign-in requirement under this bounded interpreter.',
  );
}

function assessGuest(capture) {
  const guest = isRecord(capture) && isRecord(capture.guest) ? capture.guest : null;
  const denialCode = !guest || typeof guest.code !== 'string'
    ? clause(STATUS.UNASSESSED, 'No API denial code was supplied.')
    : guest.code === 'AUTH_REQUIRED'
      ? clause(STATUS.PASSED, 'The API denial code is exactly AUTH_REQUIRED.')
      : clause(STATUS.FAILED, `The API denial code is ${JSON.stringify(guest.code)}, not AUTH_REQUIRED.`);

  const noBookingCreated = !guest || typeof guest.bookingCreated !== 'boolean'
    ? clause(STATUS.UNASSESSED, 'No authoritative booking-created observation was supplied.')
    : guest.bookingCreated === false
      ? clause(STATUS.PASSED, 'The observation confirms that no booking was created.')
      : clause(STATUS.FAILED, 'A booking was created for the guest denial attempt.');

  const explanation = explainSignInMessage(guest?.message);
  const clauses = { denialCode, noBookingCreated, explanation };
  return { outcome: outcome(clauses), clauses };
}

function assessFeeDisplay(display) {
  if (typeof display !== 'string') {
    return {
      amount: clause(STATUS.UNASSESSED, 'No complete rendered fee display was supplied.'),
      currency: clause(STATUS.UNASSESSED, 'No complete rendered fee display was supplied.'),
    };
  }

  const text = display.normalize('NFKC').trim();
  if (text === '') {
    return {
      amount: clause(STATUS.FAILED, 'The rendered fee display is empty.'),
      currency: clause(STATUS.FAILED, 'The rendered fee display is empty.'),
    };
  }

  const hasGbp = /£|\bGBP\b|\b(?:BRITISH\s+)?POUNDS?\b|\bSTERLING\b/iu.test(text);
  const hasKnownOtherCurrency = /[$€¥₹₽₩₺₴₫₪₦]|\b(?:USD|EUR|JPY|CAD|AUD|CHF|CNY|INR)\b/iu.test(text);
  let currency;
  if (hasGbp && !hasKnownOtherCurrency) {
    currency = clause(STATUS.PASSED, 'The display identifies GBP using a code, symbol, or English currency name.');
  } else if (hasKnownOtherCurrency) {
    currency = clause(STATUS.FAILED, 'The display contains a non-GBP currency marker.');
  } else {
    currency = clause(STATUS.FAILED, 'The display does not identify the fee as GBP.');
  }

  const withoutCurrency = text
    .replace(/£|\bGBP\b|\b(?:BRITISH\s+)?POUNDS?\b|\bSTERLING\b/giu, ' ');
  const numberTokens = withoutCurrency.match(/\d[\d.,'\u00A0\u202F ]*\d|\d/gu) ?? [];
  const cleanedTokens = numberTokens.map((token) => token.trim()).filter(Boolean);
  let amount;

  if (cleanedTokens.length === 0) {
    amount = clause(STATUS.FAILED, 'The display has no numeric fee amount.');
  } else if (cleanedTokens.length > 1) {
    amount = clause(STATUS.UNASSESSED, 'The display has multiple numeric candidates, so its fee amount is ambiguous.');
  } else {
    const token = cleanedTokens[0];
    if (/[-−]\s*(?:£|GBP)?\s*25/iu.test(text) || /\(\s*(?:£|GBP)?\s*25(?:[.,]0{1,2})?\s*\)/iu.test(text)) {
      amount = clause(STATUS.FAILED, 'The display presents the fee as a negative amount.');
    } else if (/^25(?:[.,]0{1,2})?$/u.test(token)) {
      amount = clause(STATUS.PASSED, 'The displayed numeric amount equals 25; decimal punctuation is not prescribed.');
    } else if (/^\d+(?:[.,]\d{1,2})?$/u.test(token)) {
      amount = clause(STATUS.FAILED, `The displayed numeric amount ${JSON.stringify(token)} does not equal 25.`);
    } else {
      amount = clause(
        STATUS.UNASSESSED,
        `The numeric formatting ${JSON.stringify(token)} is ambiguous to this locale-neutral oracle.`,
      );
    }
  }

  return { amount, currency };
}

function assessFee(capture) {
  const fee = isRecord(capture) && isRecord(capture.fee) ? capture.fee : null;
  const storedMinorUnits = !fee || typeof fee.minorUnits !== 'number' || !Number.isFinite(fee.minorUnits)
    ? clause(STATUS.UNASSESSED, 'No finite numeric minor-unit value was supplied.')
    : fee.minorUnits === 2500
      ? clause(STATUS.PASSED, 'The stored fee is exactly 2500 minor units.')
      : clause(STATUS.FAILED, `The stored fee is ${fee.minorUnits} minor units, not 2500.`);

  const storedCurrency = !fee || typeof fee.currency !== 'string'
    ? clause(STATUS.UNASSESSED, 'No stored currency code was supplied.')
    : fee.currency === 'GBP'
      ? clause(STATUS.PASSED, 'The stored currency code is exactly GBP.')
      : clause(STATUS.FAILED, `The stored currency code is ${JSON.stringify(fee.currency)}, not GBP.`);

  const display = assessFeeDisplay(fee?.display);
  const clauses = {
    storedMinorUnits,
    storedCurrency,
    displayedAmount: display.amount,
    displayedCurrency: display.currency,
  };
  return { outcome: outcome(clauses), clauses };
}

export function evaluate(capture) {
  const availability = assessAvailability(capture);
  const legal = assessLegal(capture);
  const guest = assessGuest(capture);
  const fee = assessFee(capture);

  return {
    availability: availability.outcome,
    legal: legal.outcome,
    guest: guest.outcome,
    fee: fee.outcome,
    reasons: {
      availability: availability.clauses,
      legal: legal.clauses,
      guest: guest.clauses,
      fee: fee.clauses,
    },
  };
}
