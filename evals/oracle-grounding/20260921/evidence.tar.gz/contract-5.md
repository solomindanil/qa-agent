# Contract 5: appointment-preview oracle

`contract-5.mjs` is an offline test-design artifact. It evaluates independent clauses and combines them conservatively: any established violation makes that area `failed`; otherwise any unavailable clause makes it `unassessed`; only all-supported clauses make it `passed`.

## Oracle grounding

| Oracle | Requirement source | Limits and unavailable-evidence action |
| --- | --- | --- |
| Availability | Accepted product brief plus the read-only fixtures: `2026-10-01` has no appointments; `2026-10-02` has exactly `slot-a` at `09:00`. The brief also requires the visible summary count to agree with the rendered list, including zero. | Exact date availability is assessed only for those two fixture dates. For any other date, obtain an authoritative fixture/API expectation before assessing exact availability. The October 3 render is an observation, not an intended-rule source. The prior continuation note is also not promoted to a requirement. A nonempty `summary` is assumed to be already-captured visible text; retain screenshot/DOM visibility evidence in the real execution lane. If its count is not one unambiguous integer, preserve the text and obtain agent/human semantic review. |
| Legal | Accepted product brief's approved exact copy: `This service does not provide medical advice.` including punctuation. | Comparison is character-for-character. The capture producer must establish that `legalText` came from the visible banner; if text is absent, capture the rendered banner rather than inferring from source or DOM presence alone. |
| Guest | Accepted product brief: exact API code `AUTH_REQUIRED`, no booking created, and a user-facing explanation that conveys sign-in is needed. | Code and creation state are deterministic. The message wording is unrestricted, so the module does not invent an exact phrase or keyword/regex classifier. Empty captured text fails; nonempty raw text remains `unassessed` until an agent/human reviews its meaning against the brief. That semantic review can clear only this clause and must not override a wrong code or created booking. |
| Fee | Accepted product brief: GBP 25.00, stored as 2500 minor units; displayed amount and currency must agree; locale format is not prescribed. | Stored fields are exact. Display parsing accepts `GBP` or `£` and one numeric token whose locale-valid interpretations include 25.00. Conflicting currencies or a clearly different amount fail. Free-form currency wording, multiple numbers, or ambiguous/unparseable text remains `unassessed`; inspect the rendered price and record a scoped semantic assessment rather than changing the oracle to obtain green. |

## Scope limits

The evaluator does not open a browser, call an API, establish visibility, identify a deployment, attest capture freshness, book an appointment, create an account, write a tracker item, or produce a campaign receipt. Writing or running this module is not product acceptance or release approval. It covers only the supplied appointment-preview clauses and deliberately preserves unsupported dates and semantic interpretations as `unassessed`.
