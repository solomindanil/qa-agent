const FIXTURES = Object.freeze({
  '2026-10-01': [],
  '2026-10-02': [{ id: 'slot-a', time: '09:00' }],
});

const LEGAL_COPY = 'This service does not provide medical advice.';

function combine(checks) {
  const states = Object.values(checks).map((check) => check.status);
  if (states.includes('failed')) return 'failed';
  if (states.includes('unassessed')) return 'unassessed';
  return 'passed';
}

function check(status, reason) {
  return { status, reason };
}

function appointmentKey(entry) {
  if (!entry || typeof entry !== 'object' ||
      typeof entry.id !== 'string' || typeof entry.time !== 'string') {
    return null;
  }
  return `${entry.id}\u0000${entry.time}`;
}

const numberWords = Object.freeze({
  zero: 0, one: 1, two: 2, three: 3, four: 4, five: 5,
  six: 6, seven: 7, eight: 8, nine: 9, ten: 10,
  eleven: 11, twelve: 12, thirteen: 13, fourteen: 14,
  fifteen: 15, sixteen: 16, seventeen: 17, eighteen: 18,
  nineteen: 19, twenty: 20, thirty: 30, forty: 40, fifty: 50,
  sixty: 60, seventy: 70, eighty: 80, ninety: 90,
});

function parseWordNumber(source) {
  const tokens = source.toLowerCase().replace(/-/g, ' ').split(/\s+/).filter(Boolean);
  if (tokens.length === 1 && (tokens[0] === 'no' || tokens[0] === 'none')) return 0;
  if (tokens.some((token) => token === 'no' || token === 'none')) return null;

  let total = 0;
  let current = 0;
  for (const token of tokens) {
    if (token === 'and') continue;
    if (Object.hasOwn(numberWords, token)) {
      current += numberWords[token];
    } else if (token === 'hundred') {
      current = (current || 1) * 100;
    } else if (token === 'thousand') {
      total += (current || 1) * 1000;
      current = 0;
    } else {
      return null;
    }
  }
  return total + current;
}

function summaryCounts(summary) {
  const candidates = [];
  const digits = '(\\d{1,3}(?:[,\\u00a0\\u202f ]\\d{3})*|\\d+)';
  const words = '(no|none|zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety)(?:[- ](?:one|two|three|four|five|six|seven|eight|nine))?';
  const patterns = [
    { regex: new RegExp(`\\b${digits}\\s+appointments?\\b`, 'gi'), group: 1, word: false },
    { regex: new RegExp(`\\b(${words})\\s+appointments?\\b`, 'gi'), group: 1, word: true },
    { regex: new RegExp(`\\bappointments?\\s*(?:available|open|remaining)?\\s*[:=\\-–—]?\\s*${digits}\\b`, 'gi'), group: 1, word: false },
    { regex: new RegExp(`\\bappointments?\\s*(?:available|open|remaining)?\\s*[:=\\-–—]?\\s*(${words})\\b`, 'gi'), group: 1, word: true },
  ];

  for (const { regex, group, word } of patterns) {
    for (const match of summary.matchAll(regex)) {
      const value = word
        ? parseWordNumber(match[group])
        : Number(match[group].replace(/[,\u00a0\u202f ]/g, ''));
      if (Number.isSafeInteger(value) && value >= 0) candidates.push(value);
    }
  }
  return [...new Set(candidates)];
}

function evaluateAvailability(capture) {
  const checks = {};
  const date = capture?.date;
  const appointments = capture?.appointments;

  if (typeof date !== 'string' || !Array.isArray(appointments)) {
    checks.dateInventory = check('unassessed', 'A date and appointment array were not both available.');
  } else if (!Object.hasOwn(FIXTURES, date)) {
    checks.dateInventory = check('unassessed', `No accepted expected inventory is supplied for ${date}.`);
  } else {
    const actual = appointments.map(appointmentKey);
    if (actual.some((key) => key === null)) {
      checks.dateInventory = check('unassessed', 'At least one appointment lacks a usable id or time.');
    } else {
      const expected = FIXTURES[date].map(appointmentKey).sort();
      actual.sort();
      const agrees = expected.length === actual.length && expected.every((value, index) => value === actual[index]);
      checks.dateInventory = agrees
        ? check('passed', `The rendered inventory exactly matches the accepted fixture for ${date}.`)
        : check('failed', `The rendered inventory does not match the accepted fixture for ${date}.`);
    }
  }

  if (!Array.isArray(appointments) || typeof capture?.summary !== 'string') {
    checks.summaryAgreement = check('unassessed', 'Both an appointment array and rendered summary text are required.');
  } else if (capture.summary.length === 0) {
    checks.summaryAgreement = check('failed', 'The rendered summary is empty.');
  } else {
    const counts = summaryCounts(capture.summary);
    if (counts.length !== 1) {
      checks.summaryAgreement = check('unassessed', 'The conservative English parser could not identify one unambiguous appointment count.');
    } else if (counts[0] === appointments.length) {
      checks.summaryAgreement = check('passed', `The summary count ${counts[0]} agrees with the ${appointments.length} rendered appointments.`);
    } else {
      checks.summaryAgreement = check('failed', `The summary count ${counts[0]} disagrees with the ${appointments.length} rendered appointments.`);
    }
  }

  return { status: combine(checks), checks };
}

function evaluateLegal(capture) {
  if (typeof capture?.legalText !== 'string') {
    return { status: 'unassessed', checks: { exactCopy: check('unassessed', 'Rendered legal text was not supplied.') } };
  }
  const exact = capture.legalText === LEGAL_COPY;
  const checks = { exactCopy: exact
    ? check('passed', 'The rendered text exactly matches the approved legal copy, including punctuation.')
    : check('failed', 'The rendered text is not an exact byte-for-byte match for the approved legal copy.') };
  return { status: combine(checks), checks };
}

function classifyGuestMessage(message) {
  if (typeof message !== 'string') return check('unassessed', 'A user-facing guest message was not supplied.');
  if (message.trim() === '') return check('failed', 'The user-facing guest message is empty.');

  const text = message.toLowerCase().replace(/[‐‑‒–—-]/g, ' ').replace(/\s+/g, ' ').trim();
  const auth = '(?:sign(?:ed|ing)? in|log(?:ged|ging)? in|authenticat(?:e|ed|ing|ion))';
  const contrary = [
    new RegExp(`\\b(?:no need to|do not need to|don['’]?t need to)\\s+${auth}`),
    new RegExp(`\\b${auth}\\s+(?:is\\s+)?(?:not required|optional|unnecessary)\\b`),
    new RegExp(`\\b(?:can|may)\\s+(?:book|continue|proceed).{0,40}\\bwithout\\s+${auth}`),
  ].some((pattern) => pattern.test(text));
  if (contrary) return check('failed', 'The message says or implies that sign-in is not needed.');

  const positive = [
    new RegExp(`\\b(?:must|need(?:s|ed)?(?: to)?|required to|please)\\b.{0,35}\\b${auth}\\b`),
    new RegExp(`\\b${auth}\\b.{0,25}\\b(?:required|needed|necessary)\\b`),
    new RegExp(`\\b${auth}\\b.{0,25}\\b(?:to|before)\\s+(?:book|continue|proceed)\\b`),
    new RegExp(`^(?:please\\s+)?${auth}(?:[.!]|$)`),
    new RegExp(`\\b(?:cannot|can't|unable to)\\b.{0,35}\\b(?:book|continue|proceed)\\b.{0,35}\\b(?:without|until|unless)\\b.{0,20}\\b${auth}\\b`),
  ].some((pattern) => pattern.test(text));
  if (positive) return check('passed', 'The message conveys that sign-in or authentication is needed.');

  const mentionsAuth = new RegExp(`\\b${auth}\\b`).test(text);
  return mentionsAuth
    ? check('unassessed', 'The message mentions authentication, but its requirement meaning is not safely interpretable by this oracle.')
    : check('failed', 'The message does not convey that sign-in or authentication is needed.');
}

function evaluateGuest(capture) {
  const guest = capture?.guest;
  if (!guest || typeof guest !== 'object') {
    const unavailable = check('unassessed', 'Guest API and UI observations were not supplied.');
    return { status: 'unassessed', checks: { denialCode: unavailable, noBooking: unavailable, explanation: unavailable } };
  }
  const checks = {
    denialCode: typeof guest.code !== 'string'
      ? check('unassessed', 'A denial code was not supplied.')
      : guest.code === 'AUTH_REQUIRED'
        ? check('passed', 'The API denial code is exactly AUTH_REQUIRED.')
        : check('failed', `The API denial code is ${JSON.stringify(guest.code)}, not AUTH_REQUIRED.`),
    noBooking: typeof guest.bookingCreated !== 'boolean'
      ? check('unassessed', 'A boolean bookingCreated observation was not supplied.')
      : guest.bookingCreated === false
        ? check('passed', 'No booking was created for the guest attempt.')
        : check('failed', 'A booking was created for the guest attempt.'),
    explanation: classifyGuestMessage(guest.message),
  };
  return { status: combine(checks), checks };
}

function classifyFeeDisplay(display) {
  if (typeof display !== 'string') return check('unassessed', 'Rendered fee text was not supplied.');
  if (display.trim() === '') return check('failed', 'The rendered fee text is empty.');

  const expectedCurrency = /\bGBP\b/i.test(display) || display.includes('£') || /\b(?:British pounds?|pounds? sterling|sterling)\b/i.test(display);
  const foreignCode = [...display.matchAll(/\b[A-Z]{3}\b/gi)].map((match) => match[0].toUpperCase()).find((code) => code !== 'GBP');
  const foreignSymbol = /[$€¥₹]/.test(display);
  if (foreignCode || foreignSymbol) return check('failed', 'The rendered fee contains a currency marker that does not agree with GBP.');
  if (!expectedCurrency) return check('failed', 'The rendered fee does not convey GBP.');

  const values = [...display.matchAll(/\d+(?:[.,]\d+)?/g)].map((match) => Number(match[0].replace(',', '.')));
  const unique = [...new Set(values.filter(Number.isFinite))];
  if (unique.length !== 1) return check('unassessed', 'The fee parser could not identify one unambiguous displayed amount.');
  return unique[0] === 25
    ? check('passed', 'The rendered amount is 25 major units and the rendered currency is GBP.')
    : check('failed', `The rendered amount ${unique[0]} does not agree with 2500 GBP minor units.`);
}

function evaluateFee(capture) {
  const fee = capture?.fee;
  if (!fee || typeof fee !== 'object') {
    const unavailable = check('unassessed', 'Stored and rendered fee observations were not supplied.');
    return { status: 'unassessed', checks: { minorUnits: unavailable, currency: unavailable, display: unavailable } };
  }
  const checks = {
    minorUnits: typeof fee.minorUnits !== 'number' || !Number.isInteger(fee.minorUnits)
      ? check('unassessed', 'An integer minorUnits observation was not supplied.')
      : fee.minorUnits === 2500
        ? check('passed', 'The stored fee is exactly 2500 minor units.')
        : check('failed', `The stored fee is ${fee.minorUnits} minor units, not 2500.`),
    currency: typeof fee.currency !== 'string'
      ? check('unassessed', 'A stored currency observation was not supplied.')
      : fee.currency === 'GBP'
        ? check('passed', 'The stored currency is exactly GBP.')
        : check('failed', `The stored currency is ${JSON.stringify(fee.currency)}, not GBP.`),
    display: classifyFeeDisplay(fee.display),
  };
  return { status: combine(checks), checks };
}

export function evaluate(capture) {
  const availabilityResult = evaluateAvailability(capture);
  const legalResult = evaluateLegal(capture);
  const guestResult = evaluateGuest(capture);
  const feeResult = evaluateFee(capture);

  return {
    availability: availabilityResult.status,
    legal: legalResult.status,
    guest: guestResult.status,
    fee: feeResult.status,
    reasons: {
      availability: availabilityResult,
      legal: legalResult,
      guest: guestResult,
      fee: feeResult,
    },
  };
}
