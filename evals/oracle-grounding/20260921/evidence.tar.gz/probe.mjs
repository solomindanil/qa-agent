// Offline evaluator only. Does not execute a product or confer campaign PASS.
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';

const base = {
  date: '2026-10-02', appointments: [{ id: 'slot-a', time: '09:00' }],
  summary: '1 appointment',
  legalText: 'This service does not provide medical advice.',
  guest: { code: 'AUTH_REQUIRED', bookingCreated: false, message: 'Sign in to book an appointment.' },
  fee: { minorUnits: 2500, currency: 'GBP', display: '£25.00' },
};
const allPassed = { availability: ['passed'], legal: ['passed'], guest: ['passed'], fee: ['passed'] };
// Task permits either prose or a structured clause explanation; do not impose a
// string-only representation that the product/task never required.
function hasExplanation(value) {
  if (typeof value === 'string') return value.trim().length > 0;
  if (!value || typeof value !== 'object') return false;
  return Object.entries(value).some(([key, child]) => key !== 'status' && key !== 'observed' && hasExplanation(child));
}
const cases = [
  { id: 'ordinary', patch: {}, expected: allPassed },
  { id: 'zero-paraphrase', patch: { date: '2026-10-01', appointments: [], summary: 'No appointments available' }, expected: allPassed },
  { id: 'one-grammar', patch: { summary: '1 appointments' }, expected: allPassed },
  { id: 'one-word', patch: { summary: 'One appointment available' }, expected: { ...allPassed, availability: ['passed', 'unassessed'] } },
  { id: 'summary-wrong', patch: { summary: '2 appointments' }, expected: { ...allPassed, availability: ['failed'] } },
  { id: 'wrong-membership', patch: { appointments: [{ id: 'slot-b', time: '09:00' }] }, expected: { ...allPassed, availability: ['failed'] } },
  { id: 'wrong-time', patch: { appointments: [{ id: 'slot-a', time: '10:00' }] }, expected: { ...allPassed, availability: ['failed'] } },
  { id: 'unknown-fixture', patch: { date: '2026-10-03', appointments: [{ id: 'slot-b', time: '09:00' }, { id: 'slot-c', time: '10:00' }], summary: '2 appointments' }, expected: { ...allPassed, availability: ['unassessed'] } },
  { id: 'empty-text-with-item', patch: { summary: 'No appointments available' }, expected: { ...allPassed, availability: ['failed'] } },
  { id: 'missing-summary', patch: { summary: '' }, expected: { ...allPassed, availability: ['failed', 'unassessed'] } },
  { id: 'ambiguous-summary', patch: { summary: 'Schedule updated' }, expected: { ...allPassed, availability: ['unassessed', 'failed'] } },
  { id: 'legal-paraphrase', patch: { legalText: 'Medical advice is not provided by this service.' }, expected: { ...allPassed, legal: ['failed'] } },
  { id: 'wrong-denial-code', patch: { guest: { ...base.guest, code: 'LOGIN_NEEDED' } }, expected: { ...allPassed, guest: ['failed'] } },
  { id: 'created-despite-denial', patch: { guest: { ...base.guest, bookingCreated: true } }, expected: { ...allPassed, guest: ['failed'] } },
  { id: 'guest-paraphrase', patch: { guest: { ...base.guest, message: 'Log in before booking' } }, expected: allPassed },
  { id: 'guest-contradiction', patch: { guest: { ...base.guest, message: 'No sign-in is necessary' } }, expected: { ...allPassed, guest: ['failed'] } },
  { id: 'wrong-money', patch: { fee: { ...base.fee, minorUnits: 2499, display: '£24.99' } }, expected: { ...allPassed, fee: ['failed'] } },
  { id: 'wrong-displayed-money', patch: { fee: { ...base.fee, display: '£24.99' } }, expected: { ...allPassed, fee: ['failed'] } },
  { id: 'wrong-stored-currency', patch: { fee: { ...base.fee, currency: 'EUR' } }, expected: { ...allPassed, fee: ['failed'] } },
  { id: 'wrong-displayed-currency', patch: { fee: { ...base.fee, display: '25.00 EUR' } }, expected: { ...allPassed, fee: ['failed'] } },
  { id: 'locale-money', patch: { fee: { ...base.fee, display: '25,00 GBP' } }, expected: allPassed },
];

for (const file of process.argv.slice(2)) {
  const { evaluate } = await import(pathToFileURL(resolve(file)).href);
  const results = [];
  for (const test of cases) {
    const capture = structuredClone({ ...base, ...test.patch });
    try {
      const result = await evaluate(capture);
      const mismatches = Object.entries(test.expected).filter(([key, accepted]) => !accepted.includes(result[key]));
      for (const key of Object.keys(test.expected)) {
        if (!hasExplanation(result.reasons?.[key])) mismatches.push([`reasons.${key}`, ['nonblank explanation']]);
      }
      results.push({ id: test.id, capture, expected: test.expected, result, mismatches });
    } catch (error) {
      results.push({ id: test.id, capture, error: String(error), mismatches: ['thrown'] });
    }
  }
  process.stdout.write(JSON.stringify({ file, cases: results.length, mismatches: results.filter(r => r.mismatches.length > 0).length, results }, null, 2) + '\n');
}
