const PASSED = 'passed';
const FAILED = 'failed';
const UNASSESSED = 'unassessed';

const LEGAL_COPY = 'This service does not provide medical advice.';

const FIXTURES = new Map([
  ['2026-10-01', []],
  ['2026-10-02', [{ id: 'slot-a', time: '09:00' }]],
]);

const COUNT_WORDS = new Map([
  ['no', 0],
  ['zero', 0],
  ['one', 1],
  ['two', 2],
  ['three', 3],
  ['four', 4],
  ['five', 5],
  ['six', 6],
  ['seven', 7],
  ['eight', 8],
  ['nine', 9],
  ['ten', 10],
  ['eleven', 11],
  ['twelve', 12],
  ['thirteen', 13],
  ['fourteen', 14],
  ['fifteen', 15],
  ['sixteen', 16],
  ['seventeen', 17],
  ['eighteen', 18],
  ['nineteen', 19],
  ['twenty', 20],
]);

const COUNT_TOKEN = String.raw`(?:\d(?:[\d\s\u00a0\u202f'’.,]*\d)?|no|zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty)`;

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function hasOwn(value, key) {
  return isRecord(value) && Object.prototype.hasOwnProperty.call(value, key);
}

function clause(status, expected, actual, explanation) {
  return { status, expected, actual, explanation };
}

function combine(clauses) {
  const statuses = Object.values(clauses).map((entry) => entry.status);
  if (statuses.includes(FAILED)) return FAILED;
  if (statuses.length > 0 && statuses.every((status) => status === PASSED)) return PASSED;
  return UNASSESSED;
}

function validAppointmentEntry(entry) {
  return isRecord(entry) && typeof entry.id === 'string' && typeof entry.time === 'string';
}

function sameAppointments(actual, expected) {
  return actual.length === expected.length && actual.every((entry, index) => (
    entry.id === expected[index].id && entry.time === expected[index].time
  ));
}

function decodeIntegerToken(token) {
  const normalized = token.normalize('NFKC').trim().toLowerCase();
  if (COUNT_WORDS.has(normalized)) return COUNT_WORDS.get(normalized);

  const compact = normalized.replace(/[\s\u00a0\u202f'’]/gu, '');
  if (/^\d+$/u.test(compact)) return Number.parseInt(compact, 10);
  if (/^\d{1,3}(?:[.,]\d{3})+$/u.test(compact)) {
    return Number.parseInt(compact.replace(/[.,]/gu, ''), 10);
  }
  return null;
}

function summaryCount(summary) {
  const normalized = summary.normalize('NFKC').toLowerCase();
  const expressions = [
    new RegExp(`\\b(${COUNT_TOKEN})\\s+(?:available\\s+)?appointments?\\b`, 'giu'),
    new RegExp(`\\bappointments?\\s*(?:available\\s*)?(?::|[-–—])?\\s*(${COUNT_TOKEN})\\b`, 'giu'),
  ];
  const counts = [];

  for (const expression of expressions) {
    for (const match of normalized.matchAll(expression)) {
      const count = decodeIntegerToken(match[1]);
      if (count !== null && Number.isSafeInteger(count)) counts.push(count);
    }
  }

  const distinct = [...new Set(counts)];
  if (distinct.length === 1) return { kind: 'known', value: distinct[0] };
  if (distinct.length > 1) return { kind: 'ambiguous', values: distinct };
  return { kind: 'unavailable' };
}

function availabilityAssessment(input) {
  let fixture;
  if (!hasOwn(input, 'date') || typeof input.date !== 'string' || input.date.length === 0) {
    fixture = clause(
      UNASSESSED,
      'A selected date with accepted fixture data',
      hasOwn(input, 'date') ? input.date : 'not supplied',
      'The selected date is unavailable, so the date-specific appointment set cannot be evaluated.',
    );
  } else if (!FIXTURES.has(input.date)) {
    fixture = clause(
      UNASSESSED,
      'Exact appointments from an accepted fixture for the selected date',
      input.date,
      'No accepted fixture defines the exact appointment set for this date. The October 3 render is an observation, not a reusable fixture oracle.',
    );
  } else if (!hasOwn(input, 'appointments') || !Array.isArray(input.appointments)) {
    fixture = clause(
      UNASSESSED,
      FIXTURES.get(input.date),
      hasOwn(input, 'appointments') ? input.appointments : 'not supplied',
      'The captured appointment list is unavailable or is not an array.',
    );
  } else if (!input.appointments.every(validAppointmentEntry)) {
    fixture = clause(
      UNASSESSED,
      FIXTURES.get(input.date),
      input.appointments,
      'One or more captured entries do not contain string id and time fields, so exact comparison is unavailable.',
    );
  } else {
    const expected = FIXTURES.get(input.date);
    const matches = sameAppointments(input.appointments, expected);
    fixture = clause(
      matches ? PASSED : FAILED,
      expected,
      input.appointments,
      matches
        ? 'The captured appointments exactly match the accepted fixture for the selected date.'
        : 'The captured appointments do not exactly match the accepted fixture for the selected date.',
    );
  }

  let summary;
  if (!hasOwn(input, 'appointments') || !Array.isArray(input.appointments)) {
    summary = clause(
      UNASSESSED,
      'A visible summary whose count agrees with the captured appointment list',
      hasOwn(input, 'summary') ? input.summary : 'not supplied',
      'The appointment-list count is unavailable.',
    );
  } else if (!input.appointments.every(validAppointmentEntry)) {
    summary = clause(
      UNASSESSED,
      'A visible summary whose count agrees with the captured appointment list',
      hasOwn(input, 'summary') ? input.summary : 'not supplied',
      'The captured list contains invalid entries, so its count is not trusted as an observation.',
    );
  } else if (!hasOwn(input, 'summary') || input.summary === null || typeof input.summary !== 'string') {
    summary = clause(
      UNASSESSED,
      input.appointments.length,
      hasOwn(input, 'summary') ? input.summary : 'not supplied',
      'No usable rendered summary observation was supplied.',
    );
  } else if (input.summary.trim().length === 0) {
    summary = clause(
      FAILED,
      input.appointments.length,
      input.summary,
      'The captured summary is empty, violating the requirement for a visible summary.',
    );
  } else {
    const interpreted = summaryCount(input.summary);
    if (interpreted.kind === 'known') {
      const matches = interpreted.value === input.appointments.length;
      summary = clause(
        matches ? PASSED : FAILED,
        input.appointments.length,
        { text: input.summary, interpretedCount: interpreted.value },
        matches
          ? 'The English summary conveys the same count as the captured list; wording and plurality are not constrained.'
          : 'The summary count disagrees with the captured appointment-list count.',
      );
    } else {
      summary = clause(
        UNASSESSED,
        input.appointments.length,
        interpreted.kind === 'ambiguous'
          ? { text: input.summary, interpretedCounts: interpreted.values }
          : input.summary,
        interpreted.kind === 'ambiguous'
          ? 'The summary conveys more than one possible appointment count.'
          : 'The summary is present, but this bounded English count interpreter cannot determine its appointment count.',
      );
    }
  }

  const clauses = { fixture, summary };
  return {
    status: combine(clauses),
    reason: {
      outcome: combine(clauses),
      source: 'Accepted product brief plus the read-only fixtures for 2026-10-01 and 2026-10-02.',
      clauses,
    },
  };
}

function legalAssessment(input) {
  let exactCopy;
  if (!hasOwn(input, 'legalText') || input.legalText === null || typeof input.legalText !== 'string') {
    exactCopy = clause(
      UNASSESSED,
      LEGAL_COPY,
      hasOwn(input, 'legalText') ? input.legalText : 'not supplied',
      'No usable complete legal-copy observation was supplied.',
    );
  } else {
    const matches = input.legalText === LEGAL_COPY;
    exactCopy = clause(
      matches ? PASSED : FAILED,
      LEGAL_COPY,
      input.legalText,
      matches
        ? 'The captured legal copy matches exactly, including punctuation.'
        : 'The captured legal copy differs from the approved exact text.',
    );
  }

  const clauses = { exactCopy };
  return {
    status: combine(clauses),
    reason: {
      outcome: combine(clauses),
      source: 'Accepted product brief: approved legal copy is exact, including punctuation.',
      clauses,
    },
  };
}

function guestAssessment(input) {
  const guest = isRecord(input.guest) ? input.guest : null;
  let denialCode;
  let noBooking;
  let explanation;

  if (!guest || !hasOwn(guest, 'code') || guest.code === null || typeof guest.code !== 'string') {
    denialCode = clause(
      UNASSESSED,
      'AUTH_REQUIRED',
      guest && hasOwn(guest, 'code') ? guest.code : 'not supplied',
      'No usable API denial-code observation was supplied.',
    );
  } else {
    const matches = guest.code === 'AUTH_REQUIRED';
    denialCode = clause(
      matches ? PASSED : FAILED,
      'AUTH_REQUIRED',
      guest.code,
      matches ? 'The API denial code matches exactly.' : 'The API denial code does not match the required exact code.',
    );
  }

  if (!guest || !hasOwn(guest, 'bookingCreated') || typeof guest.bookingCreated !== 'boolean') {
    noBooking = clause(
      UNASSESSED,
      false,
      guest && hasOwn(guest, 'bookingCreated') ? guest.bookingCreated : 'not supplied',
      'No usable booking-creation observation was supplied.',
    );
  } else {
    noBooking = clause(
      guest.bookingCreated === false ? PASSED : FAILED,
      false,
      guest.bookingCreated,
      guest.bookingCreated === false
        ? 'The observation says no booking was created.'
        : 'A booking was created for a guest, violating the prohibition.',
    );
  }

  if (!guest || !hasOwn(guest, 'message') || guest.message === null || typeof guest.message !== 'string') {
    explanation = clause(
      UNASSESSED,
      'A complete user-facing explanation conveying that sign-in is needed',
      guest && hasOwn(guest, 'message') ? guest.message : 'not supplied',
      'No usable complete rendered explanation was supplied.',
    );
  } else if (guest.message.trim().length === 0) {
    explanation = clause(
      FAILED,
      'A user-facing explanation conveying that sign-in is needed',
      guest.message,
      'The captured explanation is empty and therefore cannot convey the required meaning.',
    );
  } else {
    explanation = clause(
      UNASSESSED,
      'A user-facing explanation conveying that sign-in is needed',
      guest.message,
      'The copy is present, but unrestricted wording requires review of the complete rendered text in context; this oracle does not treat guessed keywords as proof of meaning.',
    );
  }

  const clauses = { denialCode, noBooking, explanation };
  return {
    status: combine(clauses),
    reason: {
      outcome: combine(clauses),
      source: 'Accepted product brief: exact AUTH_REQUIRED code, no booking creation, and a user-facing sign-in explanation.',
      clauses,
    },
  };
}

function parseLocalizedAmountToken(token) {
  let value = token.normalize('NFKC').trim();
  let sign = 1;
  if (value.startsWith('+')) value = value.slice(1);
  if (value.startsWith('-')) {
    sign = -1;
    value = value.slice(1);
  }
  value = value.replace(/[\s\u00a0\u202f'’]/gu, '');
  if (!/^\d[\d.,]*$/u.test(value)) return { kind: 'unavailable' };

  const dots = [...value.matchAll(/\./gu)].map((match) => match.index);
  const commas = [...value.matchAll(/,/gu)].map((match) => match.index);
  let canonical;

  if (dots.length > 0 && commas.length > 0) {
    const decimalMark = dots.at(-1) > commas.at(-1) ? '.' : ',';
    const decimalIndex = value.lastIndexOf(decimalMark);
    const decimalDigits = value.length - decimalIndex - 1;
    if (decimalDigits < 1 || decimalDigits > 2) return { kind: 'unavailable' };
    const integerPart = value.slice(0, decimalIndex).replace(/[.,]/gu, '');
    const fractionPart = value.slice(decimalIndex + 1);
    canonical = `${integerPart}.${fractionPart}`;
  } else if (dots.length > 0 || commas.length > 0) {
    const mark = dots.length > 0 ? '.' : ',';
    const pieces = value.split(mark);
    if (pieces.some((piece) => piece.length === 0)) return { kind: 'unavailable' };
    if (pieces.length === 2 && pieces[1].length <= 2) {
      canonical = `${pieces[0]}.${pieces[1]}`;
    } else if (pieces.slice(1).every((piece) => piece.length === 3)) {
      return { kind: 'ambiguous' };
    } else if (pieces.at(-1).length <= 2 && pieces.slice(1, -1).every((piece) => piece.length === 3)) {
      canonical = `${pieces.slice(0, -1).join('')}.${pieces.at(-1)}`;
    } else {
      return { kind: 'unavailable' };
    }
  } else {
    canonical = value;
  }

  const amount = sign * Number(canonical);
  return Number.isFinite(amount) ? { kind: 'known', value: amount } : { kind: 'unavailable' };
}

function displayedAmount(display) {
  const tokens = display.match(/[+-]?\d(?:[\d\s\u00a0\u202f'’.,]*\d)?/gu) ?? [];
  if (tokens.length === 0) return { kind: 'unavailable' };
  const parsed = tokens.map(parseLocalizedAmountToken);
  if (parsed.some((entry) => entry.kind === 'ambiguous')) return { kind: 'ambiguous' };
  const known = parsed.filter((entry) => entry.kind === 'known').map((entry) => entry.value);
  if (known.length !== 1) return { kind: 'unavailable' };
  return { kind: 'known', value: known[0] };
}

function feeAssessment(input) {
  const fee = isRecord(input.fee) ? input.fee : null;
  let storedAmount;
  let storedCurrency;
  let displayAmount;
  let displayCurrency;

  if (!fee || !hasOwn(fee, 'minorUnits') || typeof fee.minorUnits !== 'number' || !Number.isFinite(fee.minorUnits)) {
    storedAmount = clause(
      UNASSESSED,
      2500,
      fee && hasOwn(fee, 'minorUnits') ? fee.minorUnits : 'not supplied',
      'No usable numeric minor-unit observation was supplied.',
    );
  } else {
    storedAmount = clause(
      fee.minorUnits === 2500 ? PASSED : FAILED,
      2500,
      fee.minorUnits,
      fee.minorUnits === 2500 ? 'The stored minor-unit amount matches.' : 'The stored minor-unit amount is not 2500.',
    );
  }

  if (!fee || !hasOwn(fee, 'currency') || fee.currency === null || typeof fee.currency !== 'string') {
    storedCurrency = clause(
      UNASSESSED,
      'GBP',
      fee && hasOwn(fee, 'currency') ? fee.currency : 'not supplied',
      'No usable stored currency-code observation was supplied.',
    );
  } else {
    storedCurrency = clause(
      fee.currency === 'GBP' ? PASSED : FAILED,
      'GBP',
      fee.currency,
      fee.currency === 'GBP' ? 'The stored currency code matches exactly.' : 'The stored currency code is not GBP.',
    );
  }

  if (!fee || !hasOwn(fee, 'display') || fee.display === null || typeof fee.display !== 'string') {
    displayAmount = clause(
      UNASSESSED,
      'A displayed amount numerically equal to GBP 25.00',
      fee && hasOwn(fee, 'display') ? fee.display : 'not supplied',
      'No usable complete fee display observation was supplied.',
    );
    displayCurrency = clause(
      UNASSESSED,
      'A displayed GBP currency indication',
      fee && hasOwn(fee, 'display') ? fee.display : 'not supplied',
      'No usable complete fee display observation was supplied.',
    );
  } else if (fee.display.trim().length === 0) {
    displayAmount = clause(
      FAILED,
      'A displayed amount numerically equal to 25.00',
      fee.display,
      'The captured display is empty, so the required amount is absent.',
    );
    displayCurrency = clause(
      FAILED,
      'A displayed GBP currency indication',
      fee.display,
      'The captured display is empty, so the required currency is absent.',
    );
  } else {
    const amount = displayedAmount(fee.display);
    if (amount.kind === 'known') {
      const matches = Math.abs(amount.value - 25) < Number.EPSILON;
      displayAmount = clause(
        matches ? PASSED : FAILED,
        25,
        { text: fee.display, interpretedMajorUnits: amount.value },
        matches
          ? 'The displayed amount is numerically GBP 25.00; locale-specific separators and optional zero decimals are not prescribed.'
          : 'The displayed numeric amount is not 25 major units.',
      );
    } else {
      displayAmount = clause(
        UNASSESSED,
        25,
        fee.display,
        amount.kind === 'ambiguous'
          ? 'The numeric display is ambiguous between decimal and grouping conventions.'
          : 'The bounded locale-aware parser cannot determine a single numeric amount from the display.',
      );
    }

    const normalized = fee.display.normalize('NFKC');
    const hasGbp = /(?:£|\bGBP\b|\bpounds?\s+sterling\b|\bsterling\s+pounds?\b)/iu.test(normalized);
    const hasOtherCurrency = /(?:[$€¥]|\b(?:USD|EUR|JPY|AUD|CAD|CHF|CNY)\b)/iu.test(normalized);
    if (hasGbp && !hasOtherCurrency) {
      displayCurrency = clause(
        PASSED,
        'GBP',
        fee.display,
        'The display contains an unambiguous GBP code, symbol, or sterling name.',
      );
    } else if (hasOtherCurrency || (hasGbp && hasOtherCurrency)) {
      displayCurrency = clause(
        FAILED,
        'GBP only',
        fee.display,
        hasGbp
          ? 'The display mixes GBP with another currency indication.'
          : 'The display indicates a currency other than GBP.',
      );
    } else {
      displayCurrency = clause(
        FAILED,
        'A displayed GBP currency indication',
        fee.display,
        'The complete captured display contains no GBP currency indication.',
      );
    }
  }

  const clauses = { storedAmount, storedCurrency, displayAmount, displayCurrency };
  return {
    status: combine(clauses),
    reason: {
      outcome: combine(clauses),
      source: 'Accepted product brief: 2500 minor units, GBP, with a displayed amount and currency that agree; locale formatting is not prescribed.',
      clauses,
    },
  };
}

export function evaluate(capture) {
  const input = isRecord(capture) ? capture : {};
  const availability = availabilityAssessment(input);
  const legal = legalAssessment(input);
  const guest = guestAssessment(input);
  const fee = feeAssessment(input);

  return {
    availability: availability.status,
    legal: legal.status,
    guest: guest.status,
    fee: fee.status,
    reasons: {
      availability: availability.reason,
      legal: legal.reason,
      guest: guest.reason,
      fee: fee.reason,
    },
  };
}
