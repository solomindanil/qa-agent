const LEGAL_COPY = 'This service does not provide medical advice.';

const FIXTURES = new Map([
  ['2026-10-01', []],
  ['2026-10-02', [{ id: 'slot-a', time: '09:00' }]],
]);

const hasOwn = (value, key) =>
  value !== null && typeof value === 'object' &&
  Object.prototype.hasOwnProperty.call(value, key);

function result(status, reason) {
  return { status, reason };
}

function evaluateAvailability(capture) {
  if (!hasOwn(capture, 'date') || typeof capture.date !== 'string' ||
      !hasOwn(capture, 'appointments') || !Array.isArray(capture.appointments)) {
    return result(
      'unassessed',
      'A rendered date and appointments array were not both available.'
    );
  }

  const expected = FIXTURES.get(capture.date);
  if (!expected) {
    return result(
      'unassessed',
      `No authoritative appointment fixture was supplied for ${capture.date}; the observed list and summary are retained for review.`
    );
  }

  const actual = capture.appointments;
  const fixtureMatches = actual.length === expected.length && expected.every(
    (slot, index) => {
      const observed = actual[index];
      return observed !== null && typeof observed === 'object' &&
        observed.id === slot.id && observed.time === slot.time;
    }
  );

  if (!fixtureMatches) {
    const expectedDescription = expected.length === 0
      ? 'no appointments'
      : expected.map(({ id, time }) => `${id} at ${time}`).join(', ');
    return result(
      'failed',
      `The rendered appointments do not match the supplied fixture for ${capture.date} (${expectedDescription}).`
    );
  }

  if (!hasOwn(capture, 'summary') || typeof capture.summary !== 'string') {
    return result(
      'unassessed',
      `The appointment fixture matches for ${capture.date}, but no rendered summary text was available.`
    );
  }

  if (capture.summary.trim() === '') {
    return result(
      'failed',
      `The appointment fixture matches for ${capture.date}, but the required visible summary was empty.`
    );
  }

  return result(
    'unassessed',
    `The appointment fixture matches for ${capture.date}; summary meaning is unrestricted prose and must be checked against the observed count (${actual.length}) by an agent review. Observed summary: ${JSON.stringify(capture.summary)}.`
  );
}

function evaluateLegal(capture) {
  if (!hasOwn(capture, 'legalText') || typeof capture.legalText !== 'string') {
    return result('unassessed', 'Rendered consent-banner text was not available.');
  }

  if (capture.legalText === LEGAL_COPY) {
    return result('passed', 'The consent banner exactly matches the approved legal copy.');
  }

  return result(
    'failed',
    `The consent banner does not exactly match ${JSON.stringify(LEGAL_COPY)}.`
  );
}

function evaluateGuest(capture) {
  if (!hasOwn(capture, 'guest') || capture.guest === null ||
      typeof capture.guest !== 'object') {
    return result('unassessed', 'Guest booking API and rendered-message observations were not available.');
  }

  const guest = capture.guest;
  if (!hasOwn(guest, 'code') || typeof guest.code !== 'string' ||
      !hasOwn(guest, 'bookingCreated') || typeof guest.bookingCreated !== 'boolean') {
    return result(
      'unassessed',
      'The denial code and booking-created observation were not both available.'
    );
  }

  const violations = [];
  if (guest.code !== 'AUTH_REQUIRED') {
    violations.push(`denial code was ${JSON.stringify(guest.code)}, not "AUTH_REQUIRED"`);
  }
  if (guest.bookingCreated !== false) {
    violations.push('a booking was created for the guest attempt');
  }
  if (violations.length > 0) {
    return result('failed', `Guest-booking requirement violated: ${violations.join('; ')}.`);
  }

  if (!hasOwn(guest, 'message') || typeof guest.message !== 'string') {
    return result(
      'unassessed',
      'The exact API denial and no-booking clauses passed, but rendered explanation text was not available.'
    );
  }
  if (guest.message.trim() === '') {
    return result(
      'failed',
      'The API denial and no-booking clauses passed, but no user-facing explanation was rendered.'
    );
  }

  return result(
    'unassessed',
    `The exact API denial and no-booking clauses passed; whether the unrestricted message conveys the need to sign in requires agent review. Observed message: ${JSON.stringify(guest.message)}.`
  );
}

function parseFixedFeeDisplay(display) {
  const normalized = display.normalize('NFKC').replace(/[\u00a0\u202f]/gu, ' ').trim();
  if (normalized === '') return { kind: 'mismatch', detail: 'the displayed fee was empty' };

  const hasGbp = /(?:^|[^A-Z])GBP(?:$|[^A-Z])/iu.test(normalized) || normalized.includes('£');
  const hasContradictoryCurrency = /(?:^|[^A-Z])(?:USD|EUR|JPY|CAD|AUD)(?:$|[^A-Z])/iu.test(normalized) ||
    /[$€¥]/u.test(normalized);

  if (hasContradictoryCurrency) {
    return { kind: 'mismatch', detail: 'the display contains a non-GBP currency marker' };
  }
  if (!hasGbp) {
    return { kind: 'mismatch', detail: 'the display does not show GBP or the pound-sterling symbol' };
  }

  const numericTokens = normalized.match(/\d+(?:[.,]\d+)?/gu) ?? [];
  if (numericTokens.length !== 1) {
    return {
      kind: 'unavailable',
      detail: 'the displayed amount could not be interpreted unambiguously as one number'
    };
  }

  const token = numericTokens[0];
  const separator = token.match(/[.,](\d+)$/u);
  if (separator && separator[1].length > 2) {
    return {
      kind: 'unavailable',
      detail: `the numeric token ${JSON.stringify(token)} has an ambiguous locale separator`
    };
  }

  if (Number(token.replace(',', '.')) === 25) {
    return { kind: 'match', detail: `recognized GBP 25.00 in ${JSON.stringify(display)}` };
  }

  return { kind: 'mismatch', detail: `the displayed numeric amount was ${JSON.stringify(token)}, not 25.00` };
}

function evaluateFee(capture) {
  if (!hasOwn(capture, 'fee') || capture.fee === null || typeof capture.fee !== 'object') {
    return result('unassessed', 'Stored and rendered fee observations were not available.');
  }

  const fee = capture.fee;
  if (!hasOwn(fee, 'minorUnits') || typeof fee.minorUnits !== 'number' ||
      !hasOwn(fee, 'currency') || typeof fee.currency !== 'string') {
    return result('unassessed', 'Stored fee amount and currency were not both available.');
  }

  const violations = [];
  if (fee.minorUnits !== 2500) violations.push(`stored minor units were ${fee.minorUnits}, not 2500`);
  if (fee.currency !== 'GBP') violations.push(`stored currency was ${JSON.stringify(fee.currency)}, not "GBP"`);
  if (violations.length > 0) {
    return result('failed', `Fee requirement violated: ${violations.join('; ')}.`);
  }

  if (!hasOwn(fee, 'display') || typeof fee.display !== 'string') {
    return result(
      'unassessed',
      'Stored fee is GBP 2500 minor units, but rendered fee text was not available.'
    );
  }

  const parsed = parseFixedFeeDisplay(fee.display);
  if (parsed.kind === 'match') {
    return result('passed', `Stored and displayed fee agree: ${parsed.detail}.`);
  }
  if (parsed.kind === 'mismatch') {
    return result('failed', `Stored fee is GBP 25.00, but ${parsed.detail}.`);
  }
  return result(
    'unassessed',
    `Stored fee is GBP 25.00, but ${parsed.detail}; inspect the complete display without imposing a locale format.`
  );
}

export function evaluate(capture) {
  const safeCapture = capture !== null && typeof capture === 'object' ? capture : {};
  const availability = evaluateAvailability(safeCapture);
  const legal = evaluateLegal(safeCapture);
  const guest = evaluateGuest(safeCapture);
  const fee = evaluateFee(safeCapture);

  return {
    availability: availability.status,
    legal: legal.status,
    guest: guest.status,
    fee: fee.status,
    reasons: {
      availability: availability.reason,
      legal: legal.reason,
      guest: guest.reason,
      fee: fee.reason,
    },
  };
}
