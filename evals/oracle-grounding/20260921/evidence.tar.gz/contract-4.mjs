const PASS = 'passed'
const FAIL = 'failed'
const UNASSESSED = 'unassessed'

const hasOwn = (value, key) =>
  value !== null && typeof value === 'object' && Object.prototype.hasOwnProperty.call(value, key)

function combine(results) {
  if (results.includes(FAIL)) return FAIL
  if (results.every((result) => result === PASS)) return PASS
  return UNASSESSED
}

function parseOneInteger(text) {
  // This recognizes one unambiguous numeric count; it does not infer meaning
  // from unrestricted prose such as "none available".
  const tokens = text.match(/\d+(?:[,.'\u2019\u00a0\u202f ]\d+)*/gu) ?? []
  if (tokens.length !== 1) return null

  const parts = tokens[0].split(/[,.'\u2019\u00a0\u202f ]/u)
  if (parts.some((part) => part.length === 0)) return null
  if (parts.length > 1 && !parts.slice(1).every((part) => part.length === 3)) return null

  const digits = parts.join('')
  const number = Number(digits)
  return Number.isSafeInteger(number) ? number : null
}

function evaluateAvailability(capture) {
  const details = []
  const clauses = []

  const fixtures = {
    '2026-10-01': [],
    '2026-10-02': [{ id: 'slot-a', time: '09:00' }],
  }

  const date = hasOwn(capture, 'date') && typeof capture.date === 'string' ? capture.date : null
  const appointments = hasOwn(capture, 'appointments') && Array.isArray(capture.appointments)
    ? capture.appointments
    : null

  if (date === null || appointments === null) {
    clauses.push(UNASSESSED)
    details.push('The date or appointments array is unavailable in the capture.')
  } else if (!hasOwn(fixtures, date)) {
    clauses.push(UNASSESSED)
    details.push(`No authoritative appointment fixture was supplied for ${date}.`)
  } else {
    const observed = appointments.map((entry) => {
      if (entry === null || typeof entry !== 'object' ||
          typeof entry.id !== 'string' || typeof entry.time !== 'string') return null
      return `${entry.id}\u0000${entry.time}`
    })

    if (observed.includes(null)) {
      clauses.push(UNASSESSED)
      details.push('At least one appointment lacks a usable id or time in the capture.')
    } else {
      const expected = fixtures[date].map((entry) => `${entry.id}\u0000${entry.time}`)
      const actualSorted = [...observed].sort()
      const expectedSorted = [...expected].sort()
      const matches = actualSorted.length === expectedSorted.length &&
        actualSorted.every((entry, index) => entry === expectedSorted[index])
      clauses.push(matches ? PASS : FAIL)
      details.push(matches
        ? `The rendered appointments exactly match the supplied fixture for ${date}.`
        : `The rendered appointments do not match the supplied fixture for ${date}.`)
    }
  }

  if (!hasOwn(capture, 'summary') || typeof capture.summary !== 'string') {
    clauses.push(UNASSESSED)
    details.push('Rendered summary text is unavailable.')
  } else if (capture.summary.trim() === '') {
    clauses.push(FAIL)
    details.push('The observed rendered summary is empty.')
  } else if (appointments === null) {
    clauses.push(UNASSESSED)
    details.push('The nonempty summary cannot be compared because the appointment list is unavailable.')
  } else {
    const statedCount = parseOneInteger(capture.summary)
    if (statedCount === null) {
      clauses.push(UNASSESSED)
      details.push(`The complete summary ${JSON.stringify(capture.summary)} has no single unambiguous numeric count; its meaning needs separate review.`)
    } else if (statedCount !== appointments.length) {
      clauses.push(FAIL)
      details.push(`The summary states ${statedCount}, but ${appointments.length} appointments were captured.`)
    } else {
      clauses.push(PASS)
      details.push(`The summary's numeric count agrees with the ${appointments.length} captured appointments.`)
    }
  }

  return { result: combine(clauses), reason: details.join(' ') }
}

function evaluateLegal(capture) {
  const required = 'This service does not provide medical advice.'
  if (!hasOwn(capture, 'legalText') || typeof capture.legalText !== 'string') {
    return { result: UNASSESSED, reason: 'Rendered legal text is unavailable.' }
  }
  if (capture.legalText === required) {
    return { result: PASS, reason: 'The rendered legal text exactly matches the approved copy, including punctuation.' }
  }
  return {
    result: FAIL,
    reason: `The rendered legal text ${JSON.stringify(capture.legalText)} does not exactly match the approved copy.`,
  }
}

function evaluateGuest(capture) {
  if (!hasOwn(capture, 'guest') || capture.guest === null || typeof capture.guest !== 'object') {
    return { result: UNASSESSED, reason: 'Guest denial evidence is unavailable.' }
  }

  const guest = capture.guest
  const clauses = []
  const details = []

  if (!hasOwn(guest, 'code')) {
    clauses.push(UNASSESSED)
    details.push('The API denial code is unavailable.')
  } else if (guest.code === 'AUTH_REQUIRED') {
    clauses.push(PASS)
    details.push('The API denial code is exactly AUTH_REQUIRED.')
  } else {
    clauses.push(FAIL)
    details.push(`The API denial code ${JSON.stringify(guest.code)} is not AUTH_REQUIRED.`)
  }

  if (!hasOwn(guest, 'bookingCreated') || typeof guest.bookingCreated !== 'boolean') {
    clauses.push(UNASSESSED)
    details.push('Whether a booking was created is unavailable.')
  } else if (guest.bookingCreated === false) {
    clauses.push(PASS)
    details.push('No booking was created.')
  } else {
    clauses.push(FAIL)
    details.push('A booking was created for a guest.')
  }

  if (!hasOwn(guest, 'message') || typeof guest.message !== 'string') {
    clauses.push(UNASSESSED)
    details.push('The user-facing explanation is unavailable.')
  } else if (guest.message.trim() === '') {
    clauses.push(FAIL)
    details.push('The observed user-facing explanation is empty.')
  } else {
    clauses.push(UNASSESSED)
    details.push(`The complete message ${JSON.stringify(guest.message)} needs a separate semantic review because its wording is unrestricted.`)
  }

  return { result: combine(clauses), reason: details.join(' ') }
}

function evaluateFee(capture) {
  if (!hasOwn(capture, 'fee') || capture.fee === null || typeof capture.fee !== 'object') {
    return { result: UNASSESSED, reason: 'Fee evidence is unavailable.' }
  }

  const fee = capture.fee
  const clauses = []
  const details = []

  if (!hasOwn(fee, 'minorUnits') || !Number.isInteger(fee.minorUnits)) {
    clauses.push(UNASSESSED)
    details.push('Stored minor units are unavailable or not an integer.')
  } else if (fee.minorUnits === 2500) {
    clauses.push(PASS)
    details.push('Stored minor units are exactly 2500.')
  } else {
    clauses.push(FAIL)
    details.push(`Stored minor units are ${fee.minorUnits}, not 2500.`)
  }

  if (!hasOwn(fee, 'currency') || typeof fee.currency !== 'string') {
    clauses.push(UNASSESSED)
    details.push('Stored currency is unavailable.')
  } else if (fee.currency === 'GBP') {
    clauses.push(PASS)
    details.push('Stored currency is exactly GBP.')
  } else {
    clauses.push(FAIL)
    details.push(`Stored currency ${JSON.stringify(fee.currency)} is not GBP.`)
  }

  if (!hasOwn(fee, 'display') || typeof fee.display !== 'string') {
    clauses.push(UNASSESSED)
    details.push('Rendered fee text is unavailable.')
  } else if (fee.display.trim() === '') {
    clauses.push(FAIL)
    details.push('The observed rendered fee text is empty.')
  } else {
    const display = fee.display.normalize('NFKC')
    const hasGbp = /\bGBP\b/iu.test(display) || display.includes('£')
    const hasOtherCurrency = /[$€¥]/u.test(display) ||
      [...display.matchAll(/\b[A-Z]{3}\b/giu)].some((match) => match[0].toUpperCase() !== 'GBP')
    const amounts = display.match(/[+-]?\d+(?:[.,]\d+)?/gu) ?? []

    if (hasOtherCurrency) {
      clauses.push(FAIL)
      details.push(`The rendered fee ${JSON.stringify(fee.display)} contains a conflicting currency marker.`)
    } else if (amounts.length === 1 && hasGbp) {
      const amount = amounts[0]
      if (/^\+?25(?:[.,]0{1,2})?$/u.test(amount)) {
        clauses.push(PASS)
        details.push('The rendered fee unambiguously shows GBP 25 with an allowed locale decimal separator.')
      } else if (/^\+?25[.,]0{3}$/u.test(amount)) {
        clauses.push(UNASSESSED)
        details.push(`The rendered fee amount ${JSON.stringify(amount)} is ambiguous between decimal and grouping conventions.`)
      } else {
        clauses.push(FAIL)
        details.push(`The rendered fee amount ${JSON.stringify(amount)} does not equal 25.00.`)
      }
    } else {
      clauses.push(UNASSESSED)
      details.push(`The rendered fee ${JSON.stringify(fee.display)} cannot be interpreted unambiguously without assuming a locale or currency wording.`)
    }
  }

  return { result: combine(clauses), reason: details.join(' ') }
}

export function evaluate(capture) {
  const observed = capture !== null && typeof capture === 'object' ? capture : {}
  const availability = evaluateAvailability(observed)
  const legal = evaluateLegal(observed)
  const guest = evaluateGuest(observed)
  const fee = evaluateFee(observed)

  return {
    availability: availability.result,
    legal: legal.result,
    guest: guest.result,
    fee: fee.result,
    reasons: {
      availability: availability.reason,
      legal: legal.reason,
      guest: guest.reason,
      fee: fee.reason,
    },
  }
}
