// Additional whole-summary counterexample, not part of frozen21.
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
const capture = {
  date: '2026-10-02', appointments: [{ id: 'slot-a', time: '09:00' }],
  summary: 'No appointments available. Booking 1 appointment is not possible.',
  legalText: 'This service does not provide medical advice.',
  guest: { code: 'AUTH_REQUIRED', bookingCreated: false, message: 'Sign in to book an appointment.' },
  fee: { minorUnits: 2500, currency: 'GBP', display: '£25.00' },
};
for (const file of process.argv.slice(2)) {
  const { evaluate } = await import(pathToFileURL(resolve(file)).href);
  const result = await evaluate(structuredClone(capture));
  console.log(JSON.stringify({
    file, capture, result, allowed: ['failed', 'unassessed'],
    wrongDefinitiveVerdict: result.availability === 'passed',
  }));
}
