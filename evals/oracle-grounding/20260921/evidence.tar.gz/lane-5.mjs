const STATUS = Object.freeze({
  PASSED: 'passed',
  FAILED: 'failed',
  UNASSESSED: 'unassessed',
});

const AVAILABILITY_FIXTURES = Object.freeze({
  '2026-10-01': Object.freeze([]),
  '2026-10-02': Object.freeze([
    Object.freeze({ id: 'slot-a', time: '09:00' }),
  ]),
});

const LEGAL_COPY = 'This service does not provide medical advice.';

function outcome(status, reason) {
  return { status, reason };
}

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function appointmentKey(value) {
  if (!isRecord(value) || typeof value.id !== 'string' || typeof value.time !== 'string') {
    return null;
  }
  return JSON.stringify([value.id, value.time]);
}

function sameAppointmentMultiset(actual, expected) {
  if (!Array.isArray(actual) || actual.length !== expected.length) return false;

  const counts = new Map();
  for (const appointment of expected) {
    const key = appointmentKey(appointment);
    counts.set(key, (counts.get(key) ?? 0) + 1);
  }

  for (const appointment of actual) {
    const key = appointmentKey(appointment);
    if (key === null || !counts.has(key)) return false;
    const remaining = counts.get(key) - 1;
    if (remaining === 0) counts.delete(key);
    else counts.set(key, remaining);
  }

  return counts.size === 0;
}

function parseDisplayedCount(text) {
  const tokens = text.match(/[+-]?\d(?:[\d\s\u00a0\u202f,.'’]*\d)?/g);
  if (!tokens || tokens.length !== 1) return null;

  const token = tokens[0].trim();
  if (/^[+-]?\d+$/.test(token)) return Number(token);

  // Counts may use a locale grouping separator, but never a decimal fraction.
  if (/^[+-]?\d{1,3}(?:[\s\u00a0\u202f,.'’]\d{3})+$/.test(token)) {
    return Number(token.replace(/[\s\u00a0\u202f,.'’]/g, ''));
  }

  return null;
}

function evaluateAvailability(capture) {
  if (!isRecord(capture)) {
    return outcome(STATUS.UNASSESSED, 'No capture object was supplied.');
  }

  const failures = [];
  const gaps = [];
  const confirmations = [];
  const appointments = capture.appointments;

  if (!Array.isArray(appointments)) {
    gaps.push('the rendered appointment collection is unavailable');
  } else {
    confirmations.push(`the capture contains ${appointments.length} appointment(s)`);
  }

  if (typeof capture.summary !== 'string') {
    gaps.push('the rendered summary text is unavailable');
  } else if (capture.summary.length === 0 || capture.summary.trim().length === 0) {
    failures.push('the captured summary is blank, so no visible count summary is evidenced');
  } else if (Array.isArray(appointments)) {
    const displayedCount = parseDisplayedCount(capture.summary);
    if (displayedCount === null || !Number.isSafeInteger(displayedCount) || displayedCount < 0) {
      gaps.push('the summary count cannot be interpreted unambiguously as a non-negative integer');
    } else if (displayedCount !== appointments.length) {
      failures.push(`the summary reports ${displayedCount} while ${appointments.length} appointment(s) were captured`);
    } else {
      confirmations.push('the visible summary count agrees with the captured appointment count');
    }
  } else {
    gaps.push('summary agreement cannot be checked without the appointment collection');
  }

  if (typeof capture.date !== 'string') {
    gaps.push('the selected date is unavailable');
  } else if (!Object.prototype.hasOwnProperty.call(AVAILABILITY_FIXTURES, capture.date)) {
    gaps.push(`no independent expected appointment set was supplied for ${capture.date}`);
  } else if (Array.isArray(appointments)) {
    const expected = AVAILABILITY_FIXTURES[capture.date];
    if (!sameAppointmentMultiset(appointments, expected)) {
      failures.push(`the appointments do not exactly match the accepted fixture for ${capture.date}`);
    } else {
      confirmations.push(`the appointment set exactly matches the accepted fixture for ${capture.date}`);
    }
  } else {
    gaps.push(`the accepted fixture for ${capture.date} cannot be compared without captured appointments`);
  }

  if (failures.length > 0) {
    return outcome(STATUS.FAILED, `Definite violation: ${failures.join('; ')}.`);
  }
  if (gaps.length > 0) {
    const confirmed = confirmations.length > 0 ? ` Confirmed: ${confirmations.join('; ')}.` : '';
    return outcome(STATUS.UNASSESSED, `Unavailable evidence: ${gaps.join('; ')}.${confirmed}`);
  }
  return outcome(STATUS.PASSED, `${confirmations.join('; ')}.`);
}

function evaluateLegal(capture) {
  if (!isRecord(capture) || typeof capture.legalText !== 'string') {
    return outcome(STATUS.UNASSESSED, 'The captured legal text is unavailable.');
  }
  if (capture.legalText !== LEGAL_COPY) {
    return outcome(STATUS.FAILED, 'The captured legal text is not the exact approved copy, including punctuation.');
  }
  return outcome(STATUS.PASSED, 'The captured legal text exactly matches the approved copy, including punctuation.');
}

function evaluateGuest(capture) {
  if (!isRecord(capture) || !isRecord(capture.guest)) {
    return outcome(STATUS.UNASSESSED, 'The guest booking/API observation is unavailable.');
  }

  const { guest } = capture;
  const failures = [];
  const gaps = [];

  if (typeof guest.code !== 'string') gaps.push('the API denial code is unavailable');
  else if (guest.code !== 'AUTH_REQUIRED') failures.push(`the API denial code is ${JSON.stringify(guest.code)}, not "AUTH_REQUIRED"`);

  if (typeof guest.bookingCreated !== 'boolean') gaps.push('booking creation state is unavailable');
  else if (guest.bookingCreated) failures.push('a booking was created for the guest');

  if (typeof guest.message !== 'string') {
    gaps.push('the complete user-facing explanation is unavailable');
  } else if (guest.message.trim().length === 0) {
    failures.push('the user-facing explanation is blank');
  } else {
    gaps.push('whether the complete explanation conveys that sign-in is needed requires a contextual semantic assessment');
  }

  if (failures.length > 0) {
    return outcome(STATUS.FAILED, `Definite violation: ${failures.join('; ')}.`);
  }
  return outcome(STATUS.UNASSESSED, `Unavailable interpretation/evidence: ${gaps.join('; ')}.`);
}

function possibleLocalizedAmounts(token) {
  const compact = token.replace(/[\s\u00a0\u202f'’]/g, '');
  if (!/^[+-]?[\d.,]+$/.test(compact)) return [];

  const values = new Set();
  const add = (candidate) => {
    if (/^[+-]?\d+(?:\.\d+)?$/.test(candidate)) {
      const value = Number(candidate);
      if (Number.isFinite(value)) values.add(value);
    }
  };

  const commaCount = (compact.match(/,/g) ?? []).length;
  const dotCount = (compact.match(/\./g) ?? []).length;

  if (commaCount === 0 && dotCount === 0) {
    add(compact);
  } else if (commaCount > 0 && dotCount > 0) {
    const decimal = compact.lastIndexOf(',') > compact.lastIndexOf('.') ? ',' : '.';
    const grouping = decimal === ',' ? '.' : ',';
    const normalized = compact.split(grouping).join('').replace(decimal, '.');
    add(normalized);
  } else {
    const separator = commaCount > 0 ? ',' : '.';
    const unsigned = compact.replace(/^[+-]/, '');
    const groups = unsigned.split(separator);

    if (groups.length === 2 && /^\d+$/.test(groups[0]) && /^\d{1,2}$/.test(groups[1])) {
      add(compact.replace(separator, '.'));
    }
    if (groups.length > 1 && /^\d{1,3}$/.test(groups[0]) && groups.slice(1).every((part) => /^\d{3}$/.test(part))) {
      add(compact.split(separator).join(''));
    }
  }

  return [...values];
}

function assessFeeDisplay(display) {
  if (display.length === 0 || display.trim().length === 0) {
    return outcome(STATUS.FAILED, 'the fee display is blank');
  }

  const hasGbp = /£/.test(display) || /(^|[^A-Za-z])GBP(?=$|[^A-Za-z])/i.test(display);
  const hasOtherCurrency = /[$€¥₹]/.test(display)
    || /(^|[^A-Za-z])(USD|EUR|CAD|AUD|JPY|CNY)(?=$|[^A-Za-z])/i.test(display);
  if (!hasGbp) return outcome(STATUS.FAILED, 'the fee display does not identify GBP (by code or pound sign)');
  if (hasOtherCurrency) return outcome(STATUS.FAILED, 'the fee display also identifies a conflicting currency');

  const numericTokens = display.match(/[+-]?\d(?:[\d\s\u00a0\u202f,.'’]*\d)?/g);
  if (!numericTokens || numericTokens.length === 0) {
    return outcome(STATUS.FAILED, 'the fee display contains no amount');
  }
  if (numericTokens.length !== 1) {
    return outcome(STATUS.UNASSESSED, 'the fee display contains multiple numeric values, so the fee amount is ambiguous');
  }

  const possibilities = possibleLocalizedAmounts(numericTokens[0]);
  if (possibilities.length === 0) {
    return outcome(STATUS.UNASSESSED, 'the displayed amount cannot be interpreted under the supported locale-neutral forms');
  }
  if (!possibilities.includes(25)) {
    return outcome(STATUS.FAILED, `the displayed numeric amount (${numericTokens[0].trim()}) does not equal 25`);
  }
  if (possibilities.some((value) => value !== 25)) {
    return outcome(STATUS.UNASSESSED, 'the displayed amount has both 25 and non-25 plausible locale interpretations');
  }

  return outcome(STATUS.PASSED, 'the display identifies GBP and an unambiguous numeric amount of 25');
}

function evaluateFee(capture) {
  if (!isRecord(capture) || !isRecord(capture.fee)) {
    return outcome(STATUS.UNASSESSED, 'The fee observation is unavailable.');
  }

  const { fee } = capture;
  const failures = [];
  const gaps = [];
  const confirmations = [];

  if (typeof fee.minorUnits !== 'number' || !Number.isFinite(fee.minorUnits)) {
    gaps.push('stored minor units are unavailable');
  } else if (fee.minorUnits !== 2500) {
    failures.push(`stored minor units are ${fee.minorUnits}, not 2500`);
  } else {
    confirmations.push('stored minor units are 2500');
  }

  if (typeof fee.currency !== 'string') {
    gaps.push('stored currency is unavailable');
  } else if (fee.currency !== 'GBP') {
    failures.push(`stored currency is ${JSON.stringify(fee.currency)}, not "GBP"`);
  } else {
    confirmations.push('stored currency is exactly GBP');
  }

  if (typeof fee.display !== 'string') {
    gaps.push('rendered fee text is unavailable');
  } else {
    const display = assessFeeDisplay(fee.display);
    if (display.status === STATUS.FAILED) failures.push(display.reason);
    else if (display.status === STATUS.UNASSESSED) gaps.push(display.reason);
    else confirmations.push(display.reason);
  }

  if (failures.length > 0) {
    return outcome(STATUS.FAILED, `Definite violation: ${failures.join('; ')}.`);
  }
  if (gaps.length > 0) {
    const confirmed = confirmations.length > 0 ? ` Confirmed: ${confirmations.join('; ')}.` : '';
    return outcome(STATUS.UNASSESSED, `Unavailable evidence: ${gaps.join('; ')}.${confirmed}`);
  }
  return outcome(STATUS.PASSED, `${confirmations.join('; ')}.`);
}

export function evaluate(capture) {
  const availabilityResult = evaluateAvailability(capture);
  const legalResult = evaluateLegal(capture);
  const guestResult = evaluateGuest(capture);
  const feeResult = evaluateFee(capture);

  return {
    availability: availabilityResult.status,
    legal: legalResult.status,
    guest: guestResult.status,
    fee: feeResult.status,
    reasons: {
      availability: availabilityResult.reason,
      legal: legalResult.reason,
      guest: guestResult.reason,
      fee: feeResult.reason,
    },
  };
}

