# Appointment-preview oracle contract

`contract-2.mjs` exports `evaluate(capture)`. It is an offline test-design artifact: it evaluates independent clauses and aggregates them so that a definite violation wins (`failed`), all supported clauses must pass for `passed`, and any remaining interpretation/evidence gap yields `unassessed`.

## Oracle grounding

| Oracle | Requirement source | Deterministic scope | Limits and next action for unavailable evidence |
| --- | --- | --- | --- |
| Availability | Accepted product brief; supplied read-only fixtures for 2026-10-01 and 2026-10-02 | Exact fixture membership for those two dates, including id/time and zero availability; an observed empty summary is a failure | No authoritative fixture defines other dates. Summary wording is not prescribed, so the module captures the complete text/count but does not invent a keyword/regex semantic oracle. Review its rendered visibility and meaning separately; obtain a source-backed fixture before deciding exact appointments for another date. |
| Legal | Accepted product brief's approved legal copy | Exact equality to `This service does not provide medical advice.` including punctuation | Missing/non-text evidence is unassessed. Capture the freshly rendered visible legal text. |
| Guest | Accepted product brief | Exact API code `AUTH_REQUIRED`; strict `bookingCreated === false`; an observed empty explanation is a failure | The user-facing wording is deliberately unrestricted. Review the complete rendered message semantically to establish that it conveys sign-in is required. Missing code/creation evidence requires a fresh read-only API/result observation. |
| Fee | Accepted product brief | Stored 2500 minor units and exact `GBP`; conservative parsing of one rendered amount plus explicit `GBP` or `£`, accepting decimal point/comma and common spacing | Locale is not prescribed. Ambiguous amount/currency text stays unassessed rather than being forced through a locale assumption. Capture the complete rendered text plus stored/API values, then review any unrecognized locale form. |

The prior continuation note is not used as requirement authority: it has no attached source and none of its checks were executed. Likewise, the supplied 2026-10-03 render is an observation, not an authoritative fixture definition for future captures.

## Concrete limits

- The input contract contains text but no independent visibility, screenshot, deployment identity, or capture-time attestation. The caller must supply fresh rendered/API observations; this module does not prove freshness or visibility.
- Exact availability can be decided only for the two supplied fixture dates. Ordering of appointment entries is ignored; duplicate/missing id-time pairs still fail exact comparison.
- Nonempty free-form summary and guest explanation text is preserved in `reasons` and remains unassessed pending semantic review. Independent hard-clause failures are still returned as failures.
- The fee display parser is intentionally conservative. It does not treat unknown prose or an unrecognized currency spelling as GBP.
- No browser, network, account, booking, product mutation, campaign receipt, or acceptance decision is performed. Writing or running this pure evaluator is not release or product acceptance.

