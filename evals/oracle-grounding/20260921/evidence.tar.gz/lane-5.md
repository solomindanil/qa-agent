# Appointment-preview oracle report (lane 5)

## Artifact and scope

`lane-5.mjs` exports `evaluate(capture)` and evaluates four clauses independently. It is an offline test-design artifact over fresh rendered/API observations; it does not execute the product, create accounts, book appointments, attest a deployment, or establish release acceptance.

Status composition is conservative: any grounded violation makes that oracle `failed`; otherwise, any missing or ambiguous evidence makes it `unassessed`; `passed` requires every material clause to be grounded and satisfied. The `reasons` object records the decisive failure or remaining evidence gap for each oracle.

## Oracle grounding

| Oracle | Requirement source | Implemented expectation | Limits and next action when unavailable |
| --- | --- | --- | --- |
| Availability | Accepted product brief; accepted read-only fixture data for 2026-10-01 and 2026-10-02 | The summary must be nonblank and contain one unambiguous non-negative integer equal to the captured appointment count. For 2026-10-01 the exact set is empty. For 2026-10-02 the exact set is one `{ id: "slot-a", time: "09:00" }` entry; order and unrelated extra entry fields are not prescribed. | A matching summary alone cannot prove that an arbitrary date's captured set is complete. Supply an independently sourced expected set for that date, then add it to the fixture map and re-review the oracle. Missing/malformed observation fields remain `unassessed`. |
| Legal | Accepted product brief, approved legal copy | Rendered text must equal `This service does not provide medical advice.` exactly, including punctuation. | Supply the complete freshly rendered text. No whitespace or punctuation normalization is applied because the source says the copy is exact. |
| Guest | Accepted product brief | Definite failures are a denial code other than exact `AUTH_REQUIRED`, `bookingCreated: true`, or a blank user-facing explanation. | The source constrains the explanation by meaning, not literal wording. This offline deterministic module does not promote a keyword/regex guess to proof, so a nonblank message remains `unassessed` even when the strict API/state clauses match. Next, assess the complete fresh message in context in the accepted agent-observation lane; retain the exact code and no-booking evidence. |
| Fee | Accepted product brief | Stored values must be exact `2500` and `GBP`. The display must identify GBP via `GBP` or `£` and contain one unambiguous localized numeric amount equal to 25. Dot/comma decimal forms and common grouping separators are supported; no one locale layout is required. | Multiple numeric values or a locale form with more than one plausible value remains `unassessed`; inspect the complete rendered fee in context or supply its locale/number semantics. A missing GBP marker, conflicting currency, or clear non-25 amount fails. |

## Source limitations retained

- The prior continuation note is not an independent requirement source. Its literal `0 appointments` / `1 appointment` wording is therefore not enforced; the accepted brief requires count agreement, not exact summary copy or pluralization.
- The supplied 2026-10-03 render is an observation, not independent fixture truth. Its internally agreeing count does not prove that exactly the correct appointments were rendered, so this date cannot receive an availability pass without a sourced expected set.
- The module deliberately does not turn partial clause success into whole-oracle success. Each unavailable interpretation is isolated so it does not prevent the other three oracles from being evaluated.

No product checks were executed while authoring this module, and no product or release verdict is claimed.
