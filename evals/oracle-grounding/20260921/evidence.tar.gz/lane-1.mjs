const EXPECTED_LEGAL_TEXT = 'This service does not provide medical advice.';

const AVAILABILITY_FIXTURES = new Map([
  ['2026-10-01', []],
  ['2026-10-02', [{ id: 'slot-a', time: '09:00' }]],
]);

function clause(status, explanation) {
  return { status, explanation };
}

function combine(clauses) {
  const statuses = Object.values(clauses).map((item) => item.status);
  if (statuses.includes('failed')) return 'failed';
  if (statuses.length > 0 && statuses.every((status) => status === 'passed')) {
    return 'passed';
  }
  return 'unassessed';
}

function own(object, key) {
  return Object.prototype.hasOwnProperty.call(object, key);
}

function sameAppointment(actual, expected) {
  return (
    actual !== null &&
    typeof actual === 'object' &&
    actual.id === expected.id &&
    actual.time === expected.time
  );
}

function evaluateFixture(date, appointments) {
  if (typeof date !== 'string' || date.length === 0) {
    return clause('unassessed', 'No date was captured, so no fixture can be selected.');
  }
  if (!Array.isArray(appointments)) {
    return clause('unassessed', `Appointments for ${date} were not captured as a list.`);
  }

  const expected = AVAILABILITY_FIXTURES.get(date);
  if (!expected) {
    return clause(
      'unassessed',
      `No authoritative fixture listing was supplied for ${date}; the captured list cannot prove exhaustive availability.`,
    );
  }

  const matches =
    appointments.length === expected.length &&
    expected.every((item) => appointments.some((actual) => sameAppointment(actual, item))) &&
    appointments.every((item) => expected.some((wanted) => sameAppointment(item, wanted)));

  if (!matches) {
    const expectedDescription =
      expected.length === 0
        ? 'no appointments'
        : expected.map(({ id, time }) => `${id} at ${time}`).join(', ');
    return clause(
      'failed',
      `The captured appointments for ${date} do not exactly match the supplied fixture (${expectedDescription}).`,
    );
  }

  return clause('passed', `The captured appointments exactly match the supplied fixture for ${date}.`);
}

function parseGroupedInteger(raw) {
  const digits = raw.replace(/[^0-9]/gu, '');
  if (digits.length === 0) return null;
  const value = Number(digits);
  return Number.isSafeInteger(value) ? value : null;
}

function summaryCounts(text) {
  const tokens = [];
  const beforeNoun = /(\d(?:[\d\s\u00a0\u202f,.'’]*\d)?)\s+appointments?\b/giu;
  const afterNoun = /\bappointments?\s*[:=\-–—]?\s*(\d(?:[\d\s\u00a0\u202f,.'’]*\d)?)/giu;

  for (const pattern of [beforeNoun, afterNoun]) {
    for (const match of text.matchAll(pattern)) {
      const value = parseGroupedInteger(match[1]);
      if (value !== null) tokens.push(value);
    }
  }
  return [...new Set(tokens)];
}

function evaluateSummary(summary, appointments) {
  if (typeof summary !== 'string') {
    return clause('unassessed', 'Rendered summary text was not captured.');
  }
  if (summary.trim().length === 0) {
    return clause('failed', 'The captured rendered summary is empty.');
  }
  if (!Array.isArray(appointments)) {
    return clause('unassessed', 'The summary is present, but no appointment list is available for comparison.');
  }

  const counts = summaryCounts(summary);
  if (counts.length === 0) {
    return clause(
      'unassessed',
      'The English summary contains no deterministically readable numeric appointment count.',
    );
  }
  if (counts.length > 1) {
    return clause('unassessed', `The summary contains conflicting appointment counts: ${counts.join(', ')}.`);
  }
  if (counts[0] !== appointments.length) {
    return clause(
      'failed',
      `The summary says ${counts[0]} appointment(s), but the captured list contains ${appointments.length}.`,
    );
  }
  return clause('passed', `The summary count agrees with the ${appointments.length}-item captured list.`);
}

function evaluateAvailability(capture) {
  const clauses = {
    exactDateAvailability: evaluateFixture(capture.date, capture.appointments),
    summaryCount: evaluateSummary(capture.summary, capture.appointments),
  };
  return { status: combine(clauses), clauses };
}

function evaluateLegal(capture) {
  let exactCopy;
  if (typeof capture.legalText !== 'string') {
    exactCopy = clause('unassessed', 'Rendered legal text was not captured.');
  } else if (capture.legalText === EXPECTED_LEGAL_TEXT) {
    exactCopy = clause('passed', 'The legal copy exactly matches the approved text, including punctuation.');
  } else {
    exactCopy = clause('failed', 'The captured legal copy is not an exact match for the approved text.');
  }
  return { status: exactCopy.status, clauses: { exactCopy } };
}

function evaluateGuest(capture) {
  const guest = capture.guest;
  if (guest === null || typeof guest !== 'object' || Array.isArray(guest)) {
    const unavailable = clause('unassessed', 'No guest-denial observation was captured.');
    const clauses = { denialCode: unavailable, noBookingCreated: unavailable, signInExplanation: unavailable };
    return { status: 'unassessed', clauses };
  }

  let denialCode;
  if (!own(guest, 'code')) {
    denialCode = clause('unassessed', 'The API denial code was not captured.');
  } else if (guest.code === 'AUTH_REQUIRED') {
    denialCode = clause('passed', 'The API denial code is exactly AUTH_REQUIRED.');
  } else {
    denialCode = clause('failed', `The API denial code is not AUTH_REQUIRED (received ${String(guest.code)}).`);
  }

  let noBookingCreated;
  if (typeof guest.bookingCreated !== 'boolean') {
    noBookingCreated = clause('unassessed', 'Booking creation state was not captured as a boolean.');
  } else if (guest.bookingCreated === false) {
    noBookingCreated = clause('passed', 'The observation confirms that no booking was created.');
  } else {
    noBookingCreated = clause('failed', 'A booking was created for a guest.');
  }

  let signInExplanation;
  if (typeof guest.message !== 'string') {
    signInExplanation = clause('unassessed', 'No rendered user-facing denial message was captured.');
  } else if (guest.message.trim().length === 0) {
    signInExplanation = clause('failed', 'The rendered user-facing denial message is empty.');
  } else {
    signInExplanation = clause(
      'unassessed',
      'A message was captured, but whether its complete wording conveys that sign-in is needed requires semantic review; no exact copy was approved.',
    );
  }

  const clauses = { denialCode, noBookingCreated, signInExplanation };
  return { status: combine(clauses), clauses };
}

function parseLocalizedNumber(raw) {
  const compact = raw.replace(/[\s\u00a0\u202f'’]/gu, '');
  const dot = compact.lastIndexOf('.');
  const comma = compact.lastIndexOf(',');

  if (dot !== -1 && comma !== -1) {
    const decimalAt = Math.max(dot, comma);
    const integer = compact.slice(0, decimalAt).replace(/[.,]/gu, '');
    const fraction = compact.slice(decimalAt + 1);
    if (!/^\d+$/u.test(integer) || !/^\d{1,2}$/u.test(fraction)) return null;
    return Number(`${integer}.${fraction}`);
  }

  const separator = dot !== -1 ? '.' : comma !== -1 ? ',' : null;
  if (separator === null) return /^\d+$/u.test(compact) ? Number(compact) : null;

  const parts = compact.split(separator);
  if (parts.some((part) => !/^\d+$/u.test(part))) return null;
  if (parts.length === 2 && parts[1].length <= 2) return Number(`${parts[0]}.${parts[1]}`);
  if (parts.slice(1).every((part) => part.length === 3)) return Number(parts.join(''));
  return null;
}

function displayAmounts(display) {
  const tokens = display.match(/\d(?:[\d\s\u00a0\u202f,.'’]*\d)?/gu) ?? [];
  const values = tokens.map(parseLocalizedNumber).filter((value) => Number.isFinite(value));
  return [...new Set(values)];
}

function evaluateFeeDisplay(display) {
  if (typeof display !== 'string') {
    return clause('unassessed', 'Rendered fee text was not captured.');
  }
  if (display.trim().length === 0) {
    return clause('failed', 'The rendered fee text is empty.');
  }

  const hasGbp = /\bGBP\b/iu.test(display) || /£/u.test(display) || /\b(?:British\s+pounds?|pounds?\s+sterling|sterling)\b/iu.test(display);
  const hasConflictingCurrency = /\b(?:USD|EUR|CAD|AUD|JPY)\b/iu.test(display) || /[$€¥]/u.test(display);
  const currencyStatus = hasConflictingCurrency
    ? clause('failed', 'The rendered fee includes a currency marker that conflicts with GBP.')
    : hasGbp
      ? clause('passed', 'The rendered fee identifies GBP (or pounds sterling).')
      : clause('failed', 'The rendered fee does not identify GBP or pounds sterling.');

  const amounts = displayAmounts(display);
  let amountStatus;
  if (amounts.length === 0) {
    amountStatus = clause('unassessed', 'No deterministic numeric amount could be read from the fee text.');
  } else if (amounts.length > 1) {
    amountStatus = clause('unassessed', `The fee text contains multiple numeric amounts: ${amounts.join(', ')}.`);
  } else if (Math.round(amounts[0] * 100) === 2500) {
    amountStatus = clause('passed', 'The rendered amount equals GBP 25.00 under a supported locale format.');
  } else {
    amountStatus = clause('failed', `The rendered amount is ${amounts[0]}, not 25.00.`);
  }

  return {
    status: combine({ currency: currencyStatus, amount: amountStatus }),
    explanation: `${currencyStatus.explanation} ${amountStatus.explanation}`,
  };
}

function evaluateFee(capture) {
  const fee = capture.fee;
  if (fee === null || typeof fee !== 'object' || Array.isArray(fee)) {
    const unavailable = clause('unassessed', 'No fee observation was captured.');
    const clauses = { storedMinorUnits: unavailable, storedCurrency: unavailable, renderedFee: unavailable };
    return { status: 'unassessed', clauses };
  }

  let storedMinorUnits;
  if (!own(fee, 'minorUnits')) {
    storedMinorUnits = clause('unassessed', 'Stored minor units were not captured.');
  } else if (fee.minorUnits === 2500) {
    storedMinorUnits = clause('passed', 'Stored fee is exactly 2500 minor units.');
  } else {
    storedMinorUnits = clause('failed', `Stored fee is not 2500 minor units (received ${String(fee.minorUnits)}).`);
  }

  let storedCurrency;
  if (!own(fee, 'currency')) {
    storedCurrency = clause('unassessed', 'Stored currency was not captured.');
  } else if (fee.currency === 'GBP') {
    storedCurrency = clause('passed', 'Stored currency is exactly GBP.');
  } else {
    storedCurrency = clause('failed', `Stored currency is not GBP (received ${String(fee.currency)}).`);
  }

  const renderedFee = evaluateFeeDisplay(fee.display);
  const clauses = { storedMinorUnits, storedCurrency, renderedFee };
  return { status: combine(clauses), clauses };
}

export function evaluate(capture) {
  const safeCapture = capture !== null && typeof capture === 'object' && !Array.isArray(capture) ? capture : {};
  const availabilityResult = evaluateAvailability(safeCapture);
  const legalResult = evaluateLegal(safeCapture);
  const guestResult = evaluateGuest(safeCapture);
  const feeResult = evaluateFee(safeCapture);

  return {
    availability: availabilityResult.status,
    legal: legalResult.status,
    guest: guestResult.status,
    fee: feeResult.status,
    reasons: {
      availability: availabilityResult,
      legal: legalResult,
      guest: guestResult,
      fee: feeResult,
    },
  };
}
