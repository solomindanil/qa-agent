const EXPECTED_APPOINTMENTS = Object.freeze({
  '2026-10-01': Object.freeze([]),
  '2026-10-02': Object.freeze([
    Object.freeze({ id: 'slot-a', time: '09:00' }),
  ]),
});

const LEGAL_COPY = 'This service does not provide medical advice.';

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function aggregate(clauses) {
  const outcomes = Object.values(clauses).map((clause) => clause.outcome);
  if (outcomes.includes('failed')) return 'failed';
  if (outcomes.length > 0 && outcomes.every((outcome) => outcome === 'passed')) {
    return 'passed';
  }
  return 'unassessed';
}

function sameAppointments(actual, expected) {
  if (!Array.isArray(actual)) return null;
  if (
    actual.some(
      (entry) =>
        !isRecord(entry) ||
        typeof entry.id !== 'string' ||
        typeof entry.time !== 'string',
    )
  ) {
    return null;
  }

  const actualKeys = actual.map(({ id, time }) => `${id}\u0000${time}`).sort();
  const expectedKeys = expected.map(({ id, time }) => `${id}\u0000${time}`).sort();
  return (
    actualKeys.length === expectedKeys.length &&
    actualKeys.every((key, index) => key === expectedKeys[index])
  );
}

function parseGroupedInteger(raw) {
  const value = raw.trim();
  if (/^\d+$/.test(value)) return Number(value);

  // Accept common grouping forms (1,000 / 1.000 / 1 000 / 1'000), but
  // never reinterpret a decimal-looking value such as 1.5 as a count.
  const grouped = value.match(/^(\d{1,3})([ ,.\u00a0\u202f'’])(\d{3}(?:\2\d{3})*)$/);
  if (!grouped) return null;
  return Number(value.replace(/[ ,.\u00a0\u202f'’]/g, ''));
}

function explicitAppointmentCount(summary) {
  if (typeof summary !== 'string') return { kind: 'unavailable' };
  if (summary.length === 0) return { kind: 'absent' };

  const values = [];
  const pattern = /([0-9](?:[0-9]|[ ,.\u00a0\u202f'’](?=[0-9]))*)\s+appointments?\b/gi;
  for (const match of summary.matchAll(pattern)) {
    const parsed = parseGroupedInteger(match[1]);
    if (parsed !== null && Number.isSafeInteger(parsed)) values.push(parsed);
  }

  const unique = [...new Set(values)];
  if (unique.length === 1) return { kind: 'value', value: unique[0] };
  if (unique.length > 1) return { kind: 'ambiguous', values: unique };
  return { kind: 'uninterpreted' };
}

function availabilityOracle(capture) {
  const clauses = {};
  const date = typeof capture.date === 'string' ? capture.date : null;
  const expected = date === null ? undefined : EXPECTED_APPOINTMENTS[date];

  if (date === null || !Array.isArray(capture.appointments)) {
    clauses.fixture = {
      outcome: 'unassessed',
      explanation: 'The date or rendered appointment list was not observed in the required shape.',
    };
  } else if (expected === undefined) {
    clauses.fixture = {
      outcome: 'unassessed',
      explanation: `No authoritative appointment fixture was supplied for ${date}.`,
    };
  } else {
    const matches = sameAppointments(capture.appointments, expected);
    clauses.fixture =
      matches === null
        ? {
            outcome: 'unassessed',
            explanation: 'At least one appointment lacks a string id or time, so the fixture comparison is unavailable.',
          }
        : matches
          ? {
              outcome: 'passed',
              explanation: `The rendered appointments exactly match the supplied fixture for ${date}.`,
            }
          : {
              outcome: 'failed',
              explanation: `The rendered appointments do not exactly match the supplied fixture for ${date}.`,
            };
  }

  if (!Array.isArray(capture.appointments)) {
    clauses.summary = {
      outcome: 'unassessed',
      explanation: 'The appointment count was not observed, so the summary cannot be compared with it.',
    };
  } else {
    const count = explicitAppointmentCount(capture.summary);
    if (count.kind === 'value') {
      clauses.summary =
        count.value === capture.appointments.length
          ? {
              outcome: 'passed',
              explanation: `The summary states ${count.value} appointment(s), matching the ${capture.appointments.length} rendered entr${capture.appointments.length === 1 ? 'y' : 'ies'}.`,
            }
          : {
              outcome: 'failed',
              explanation: `The summary states ${count.value} appointment(s), but ${capture.appointments.length} entr${capture.appointments.length === 1 ? 'y was' : 'ies were'} rendered.`,
            };
    } else if (count.kind === 'absent') {
      clauses.summary = {
        outcome: 'failed',
        explanation: 'The observed summary is empty, so no visible count agreement was shown.',
      };
    } else {
      clauses.summary = {
        outcome: 'unassessed',
        explanation:
          count.kind === 'ambiguous'
            ? `The summary contains conflicting explicit appointment counts: ${count.values.join(', ')}.`
            : 'The summary was missing or did not expose one unambiguous numeric appointment count; semantic prose needs separate review.',
      };
    }
  }

  return { outcome: aggregate(clauses), clauses };
}

function legalOracle(capture) {
  if (typeof capture.legalText !== 'string') {
    return {
      outcome: 'unassessed',
      clauses: {
        exactCopy: {
          outcome: 'unassessed',
          explanation: 'No rendered legal text was supplied.',
        },
      },
    };
  }

  const passed = capture.legalText === LEGAL_COPY;
  const clauses = {
    exactCopy: {
      outcome: passed ? 'passed' : 'failed',
      explanation: passed
        ? 'The rendered text exactly matches the approved legal copy, including punctuation.'
        : `The rendered text does not exactly equal ${JSON.stringify(LEGAL_COPY)}.`,
    },
  };
  return { outcome: aggregate(clauses), clauses };
}

function guestOracle(capture) {
  const guest = isRecord(capture.guest) ? capture.guest : null;
  const clauses = {};

  clauses.denialCode =
    guest === null || typeof guest.code !== 'string'
      ? {
          outcome: 'unassessed',
          explanation: 'The guest API denial code was not observed.',
        }
      : guest.code === 'AUTH_REQUIRED'
        ? {
            outcome: 'passed',
            explanation: 'The guest API denial code is exactly AUTH_REQUIRED.',
          }
        : {
            outcome: 'failed',
            explanation: `The guest API denial code was ${JSON.stringify(guest.code)}, not AUTH_REQUIRED.`,
          };

  clauses.noBookingCreated =
    guest === null || typeof guest.bookingCreated !== 'boolean'
      ? {
          outcome: 'unassessed',
          explanation: 'Booking creation was not observed as a boolean postcondition.',
        }
      : guest.bookingCreated === false
        ? {
            outcome: 'passed',
            explanation: 'The observation reports that no booking was created.',
          }
        : {
            outcome: 'failed',
            explanation: 'A booking was created for a guest.',
          };

  if (guest === null || typeof guest.message !== 'string') {
    clauses.explanation = {
      outcome: 'unassessed',
      explanation: 'No rendered user-facing explanation was supplied.',
    };
  } else if (guest.message.trim().length === 0) {
    clauses.explanation = {
      outcome: 'failed',
      explanation: 'The observed user-facing explanation is empty.',
      actual: guest.message,
    };
  } else {
    clauses.explanation = {
      outcome: 'unassessed',
      explanation: 'The wording is not prescribed; whether it conveys that sign-in is needed requires a separate semantic review.',
      actual: guest.message,
    };
  }

  return { outcome: aggregate(clauses), clauses };
}

function parseDisplayedNumber(raw) {
  const compact = raw.replace(/[\u00a0\u202f\s'’]/g, '');
  if (!/^\d[\d.,]*$/.test(compact)) return null;
  if (/^\d+$/.test(compact)) return Number(compact);

  const lastDot = compact.lastIndexOf('.');
  const lastComma = compact.lastIndexOf(',');
  const decimalIndex = Math.max(lastDot, lastComma);
  const fractionalLength = compact.length - decimalIndex - 1;

  if (fractionalLength === 1 || fractionalLength === 2) {
    const whole = compact.slice(0, decimalIndex).replace(/[.,]/g, '');
    const fraction = compact.slice(decimalIndex + 1);
    if (!/^\d+$/.test(whole) || !/^\d+$/.test(fraction)) return null;
    return Number(`${whole}.${fraction}`);
  }

  if (/^\d{1,3}(?:[.,]\d{3})+$/.test(compact)) {
    return Number(compact.replace(/[.,]/g, ''));
  }
  return null;
}

function displayedAmounts(display) {
  if (typeof display !== 'string') return { kind: 'unavailable' };
  if (display.length === 0) return { kind: 'absent' };

  const tokens = display.match(/\d(?:[\d.,]|[\u00a0\u202f\s'’](?=\d))*/g) ?? [];
  const parsed = tokens
    .map((token) => parseDisplayedNumber(token.trim()))
    .filter((value) => value !== null && Number.isFinite(value));
  const unique = [...new Set(parsed)];
  if (unique.length === 1) return { kind: 'value', value: unique[0] };
  if (unique.length > 1) return { kind: 'ambiguous', values: unique };
  return { kind: 'uninterpreted' };
}

function displayedCurrency(display) {
  if (typeof display !== 'string') return { kind: 'unavailable' };
  if (display.length === 0) return { kind: 'absent' };
  if (/£|\bGBP\b|\bpounds?(?:\s+sterling)?\b/i.test(display)) {
    return { kind: 'value', value: 'GBP' };
  }
  if (/[$€¥]|\b(?:USD|EUR|JPY|CAD|AUD|CHF|CNY|INR)\b/i.test(display)) {
    return { kind: 'other' };
  }
  return { kind: 'uninterpreted' };
}

function feeOracle(capture) {
  const fee = isRecord(capture.fee) ? capture.fee : null;
  const clauses = {};

  clauses.minorUnits =
    fee === null || typeof fee.minorUnits !== 'number'
      ? {
          outcome: 'unassessed',
          explanation: 'Stored minor units were not observed as a number.',
        }
      : fee.minorUnits === 2500
        ? {
            outcome: 'passed',
            explanation: 'The stored fee is exactly 2500 minor units.',
          }
        : {
            outcome: 'failed',
            explanation: `The stored fee is ${fee.minorUnits} minor units, not 2500.`,
          };

  clauses.currency =
    fee === null || typeof fee.currency !== 'string'
      ? {
          outcome: 'unassessed',
          explanation: 'The stored currency code was not observed.',
        }
      : fee.currency === 'GBP'
        ? {
            outcome: 'passed',
            explanation: 'The stored currency code is exactly GBP.',
          }
        : {
            outcome: 'failed',
            explanation: `The stored currency code was ${JSON.stringify(fee.currency)}, not GBP.`,
          };

  const amount = displayedAmounts(fee?.display);
  if (amount.kind === 'value') {
    clauses.displayedAmount = {
      outcome: amount.value === 25 ? 'passed' : 'failed',
      explanation:
        amount.value === 25
          ? 'The displayed major-unit amount is 25, consistent with 2500 minor units.'
          : `The displayed major-unit amount was interpreted as ${amount.value}, not 25.`,
    };
  } else if (amount.kind === 'absent') {
    clauses.displayedAmount = {
      outcome: 'failed',
      explanation: 'The observed fee display is empty.',
    };
  } else {
    clauses.displayedAmount = {
      outcome: 'unassessed',
      explanation:
        amount.kind === 'ambiguous'
          ? `The fee display contains conflicting numeric values: ${amount.values.join(', ')}.`
          : 'No single locale-independent numeric amount could be interpreted from the fee display.',
    };
  }

  const currency = displayedCurrency(fee?.display);
  if (currency.kind === 'value') {
    clauses.displayedCurrency = {
      outcome: 'passed',
      explanation: 'The display identifies GBP via GBP, £, or English pound wording.',
    };
  } else if (currency.kind === 'other') {
    clauses.displayedCurrency = {
      outcome: 'failed',
      explanation: 'The display explicitly identifies a non-GBP currency.',
    };
  } else if (currency.kind === 'absent') {
    clauses.displayedCurrency = {
      outcome: 'failed',
      explanation: 'The observed fee display is empty.',
    };
  } else {
    clauses.displayedCurrency = {
      outcome: 'unassessed',
      explanation: 'No unambiguous GBP marker could be interpreted from the fee display.',
    };
  }

  return { outcome: aggregate(clauses), clauses };
}

export function evaluate(capture) {
  const observed = isRecord(capture) ? capture : {};
  const availability = availabilityOracle(observed);
  const legal = legalOracle(observed);
  const guest = guestOracle(observed);
  const fee = feeOracle(observed);

  return {
    availability: availability.outcome,
    legal: legal.outcome,
    guest: guest.outcome,
    fee: fee.outcome,
    reasons: {
      availability: availability.clauses,
      legal: legal.clauses,
      guest: guest.clauses,
      fee: fee.clauses,
    },
  };
}

