const FIXTURES = Object.freeze({
  '2026-10-01': Object.freeze([]),
  '2026-10-02': Object.freeze([
    Object.freeze({ id: 'slot-a', time: '09:00' }),
  ]),
});

const LEGAL_COPY = 'This service does not provide medical advice.';

function item(clause, status, detail) {
  return { clause, status, detail };
}

function outcome(items) {
  if (items.some((entry) => entry.status === 'failed')) return 'failed';
  if (items.some((entry) => entry.status === 'unassessed')) return 'unassessed';
  return 'passed';
}

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function sameFixture(actual, expected) {
  if (!Array.isArray(actual)) return false;

  const canonical = (entry) => {
    if (!isRecord(entry) || typeof entry.id !== 'string' || typeof entry.time !== 'string') {
      return null;
    }
    return `${entry.id}\u0000${entry.time}`;
  };

  const actualKeys = actual.map(canonical);
  const expectedKeys = expected.map(canonical);
  if (actualKeys.some((key) => key === null)) return false;
  actualKeys.sort();
  expectedKeys.sort();
  return actualKeys.length === expectedKeys.length
    && actualKeys.every((key, index) => key === expectedKeys[index]);
}

function readSummaryCount(summary) {
  if (typeof summary !== 'string' || summary.trim() === '') {
    return { kind: 'unavailable', detail: 'No visible summary text was supplied.' };
  }

  // The capture field is defined as the summary element's visible English text.
  // Accept one unambiguous integer token without prescribing surrounding copy.
  const tokens = summary.match(/[+-]?\d+(?:[,.\u00a0 ]\d+)*/g) ?? [];
  if (tokens.length !== 1) {
    return {
      kind: 'unavailable',
      detail: 'The summary does not contain exactly one unambiguous numeric count.',
    };
  }

  const token = tokens[0].trim();
  if (!/^\+?\d+$/.test(token)) {
    return {
      kind: 'unavailable',
      detail: `The count token ${JSON.stringify(token)} is locale-ambiguous or is not an integer.`,
    };
  }

  const value = Number(token.replace(/^\+/, ''));
  if (!Number.isSafeInteger(value)) {
    return { kind: 'unavailable', detail: 'The numeric count is outside the safe integer range.' };
  }
  return { kind: 'value', value };
}

function availabilityReasons(capture) {
  const items = [];
  const date = capture?.date;
  const appointments = capture?.appointments;

  if (typeof date !== 'string' || date === '') {
    items.push(item(
      'date availability',
      'unassessed',
      'No selected date was supplied, so date-specific availability cannot be checked.',
    ));
  } else if (Object.hasOwn(FIXTURES, date)) {
    if (!Array.isArray(appointments)) {
      items.push(item(
        'date availability',
        'unassessed',
        `No rendered appointment list was supplied for the known fixture date ${date}.`,
      ));
    } else if (sameFixture(appointments, FIXTURES[date])) {
      items.push(item(
        'date availability',
        'passed',
        `The rendered appointments exactly match the accepted fixture for ${date}.`,
      ));
    } else {
      items.push(item(
        'date availability',
        'failed',
        `The rendered appointments do not exactly match the accepted fixture for ${date}.`,
      ));
    }
  } else {
    items.push(item(
      'date availability',
      'unassessed',
      `No authoritative availability fixture was supplied for ${JSON.stringify(date)}.`,
    ));
  }

  const parsedSummary = readSummaryCount(capture?.summary);
  if (!Array.isArray(appointments)) {
    items.push(item(
      'summary count',
      'unassessed',
      'No rendered appointment list was supplied for comparison with the summary.',
    ));
  } else if (parsedSummary.kind === 'unavailable') {
    items.push(item('summary count', 'unassessed', parsedSummary.detail));
  } else if (parsedSummary.value === appointments.length) {
    items.push(item(
      'summary count',
      'passed',
      `The visible summary count ${parsedSummary.value} agrees with ${appointments.length} rendered appointment(s).`,
    ));
  } else {
    items.push(item(
      'summary count',
      'failed',
      `The visible summary count ${parsedSummary.value} disagrees with ${appointments.length} rendered appointment(s).`,
    ));
  }

  return items;
}

function legalReasons(capture) {
  if (typeof capture?.legalText !== 'string') {
    return [item('approved legal copy', 'unassessed', 'No visible legal text was supplied.')];
  }
  if (capture.legalText === LEGAL_COPY) {
    return [item('approved legal copy', 'passed', 'The captured text exactly matches the approved copy, including punctuation.')];
  }
  return [item('approved legal copy', 'failed', 'The captured text is not an exact character-for-character match for the approved copy.')];
}

function guestReasons(capture) {
  const guest = capture?.guest;
  if (!isRecord(guest)) {
    return [
      item('API denial code', 'unassessed', 'No guest API observation was supplied.'),
      item('no booking created', 'unassessed', 'No booking-creation observation was supplied.'),
      item('sign-in explanation', 'unassessed', 'No user-facing guest message was supplied.'),
    ];
  }

  const items = [];
  if (typeof guest.code !== 'string') {
    items.push(item('API denial code', 'unassessed', 'The denial code was not captured.'));
  } else if (guest.code === 'AUTH_REQUIRED') {
    items.push(item('API denial code', 'passed', 'The guest denial code is exactly AUTH_REQUIRED.'));
  } else {
    items.push(item('API denial code', 'failed', `Expected AUTH_REQUIRED; observed ${JSON.stringify(guest.code)}.`));
  }

  if (typeof guest.bookingCreated !== 'boolean') {
    items.push(item('no booking created', 'unassessed', 'Whether a booking was created was not captured as a boolean.'));
  } else if (guest.bookingCreated === false) {
    items.push(item('no booking created', 'passed', 'The capture reports that no booking was created.'));
  } else {
    items.push(item('no booking created', 'failed', 'A booking was created for the guest denial attempt.'));
  }

  if (typeof guest.message !== 'string') {
    items.push(item('sign-in explanation', 'unassessed', 'No user-facing message text was captured.'));
  } else if (guest.message.trim() === '') {
    items.push(item('sign-in explanation', 'failed', 'The captured user-facing explanation is empty.'));
  } else {
    items.push(item(
      'sign-in explanation',
      'unassessed',
      'The requirement is semantic and prescribes no exact wording; a raw string cannot be safely classified by keywords.',
    ));
  }

  return items;
}

function amountCandidates(token) {
  if (!/^[+-]?\d+(?:[.,]\d+)*$/.test(token)) return [];

  const sign = token.startsWith('-') ? -1 : 1;
  const unsigned = token.replace(/^[+-]/, '');
  const values = new Set();
  const digitsOnly = unsigned.replace(/[.,]/g, '');
  values.add(sign * Number(digitsOnly));

  const lastSeparator = Math.max(unsigned.lastIndexOf('.'), unsigned.lastIndexOf(','));
  if (lastSeparator >= 0) {
    const whole = unsigned.slice(0, lastSeparator).replace(/[.,]/g, '');
    const fraction = unsigned.slice(lastSeparator + 1);
    if (whole !== '' && fraction !== '') {
      values.add(sign * Number(`${whole}.${fraction}`));
    }
  }

  return [...values].filter(Number.isFinite);
}

function inspectFeeDisplay(display) {
  if (typeof display !== 'string' || display.trim() === '') {
    return {
      currency: item('displayed currency', 'unassessed', 'No displayed fee text was supplied.'),
      amount: item('displayed amount', 'unassessed', 'No displayed fee text was supplied.'),
    };
  }

  const hasGbp = /\bGBP\b/i.test(display) || display.includes('£');
  const hasOtherCurrency = /\b(?:AED|AUD|CAD|CHF|CNY|EUR|INR|JPY|RUB|USD)\b/i.test(display)
    || /[€$¥₹₽]/u.test(display);

  let currency;
  if (hasGbp && !hasOtherCurrency) {
    currency = item('displayed currency', 'passed', 'The display contains an unambiguous GBP code or pound sign.');
  } else if (hasOtherCurrency) {
    currency = item('displayed currency', 'failed', 'The display contains a non-GBP or conflicting currency marker.');
  } else {
    currency = item(
      'displayed currency',
      'unassessed',
      'The display has no unambiguous GBP code or pound sign; free-form currency wording is not classified.',
    );
  }

  const tokens = display.match(/[+-]?\d+(?:[.,]\d+)*/g) ?? [];
  let amount;
  if (tokens.length !== 1) {
    amount = item(
      'displayed amount',
      'unassessed',
      'The display does not contain exactly one numeric amount token.',
    );
  } else {
    const candidates = amountCandidates(tokens[0]);
    if (candidates.includes(25)) {
      amount = item('displayed amount', 'passed', 'At least one locale-valid interpretation of the sole amount token is 25.00.');
    } else if (candidates.length > 0) {
      amount = item('displayed amount', 'failed', `The displayed numeric amount ${JSON.stringify(tokens[0])} cannot represent 25.00.`);
    } else {
      amount = item('displayed amount', 'unassessed', 'The displayed amount token could not be interpreted safely.');
    }
  }

  return { currency, amount };
}

function feeReasons(capture) {
  const fee = capture?.fee;
  if (!isRecord(fee)) {
    return [
      item('stored minor units', 'unassessed', 'No fee observation was supplied.'),
      item('stored currency', 'unassessed', 'No fee observation was supplied.'),
      item('displayed currency', 'unassessed', 'No displayed fee text was supplied.'),
      item('displayed amount', 'unassessed', 'No displayed fee text was supplied.'),
    ];
  }

  const items = [];
  if (typeof fee.minorUnits !== 'number' || !Number.isInteger(fee.minorUnits)) {
    items.push(item('stored minor units', 'unassessed', 'Stored minor units were not captured as an integer.'));
  } else if (fee.minorUnits === 2500) {
    items.push(item('stored minor units', 'passed', 'Stored fee is exactly 2500 minor units.'));
  } else {
    items.push(item('stored minor units', 'failed', `Expected 2500 minor units; observed ${fee.minorUnits}.`));
  }

  if (typeof fee.currency !== 'string') {
    items.push(item('stored currency', 'unassessed', 'Stored currency was not captured.'));
  } else if (fee.currency === 'GBP') {
    items.push(item('stored currency', 'passed', 'Stored currency is exactly GBP.'));
  } else {
    items.push(item('stored currency', 'failed', `Expected stored currency GBP; observed ${JSON.stringify(fee.currency)}.`));
  }

  const display = inspectFeeDisplay(fee.display);
  items.push(display.currency, display.amount);
  return items;
}

export function evaluate(capture) {
  const safeCapture = isRecord(capture) ? capture : {};
  const reasons = {
    availability: availabilityReasons(safeCapture),
    legal: legalReasons(safeCapture),
    guest: guestReasons(safeCapture),
    fee: feeReasons(safeCapture),
  };

  return {
    availability: outcome(reasons.availability),
    legal: outcome(reasons.legal),
    guest: outcome(reasons.guest),
    fee: outcome(reasons.fee),
    reasons,
  };
}
