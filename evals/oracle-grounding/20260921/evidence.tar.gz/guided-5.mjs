const STATUS = Object.freeze({
  PASSED: 'passed',
  FAILED: 'failed',
  UNASSESSED: 'unassessed',
});

const FIXTURES = Object.freeze({
  '2026-10-01': [],
  '2026-10-02': [{ id: 'slot-a', time: '09:00' }],
});

const NUMBER_WORDS = Object.freeze({
  no: 0,
  none: 0,
  zero: 0,
  an: 1,
  a: 1,
  one: 1,
  two: 2,
  three: 3,
  four: 4,
  five: 5,
  six: 6,
  seven: 7,
  eight: 8,
  nine: 9,
  ten: 10,
  eleven: 11,
  twelve: 12,
  thirteen: 13,
  fourteen: 14,
  fifteen: 15,
  sixteen: 16,
  seventeen: 17,
  eighteen: 18,
  nineteen: 19,
  twenty: 20,
});

function combineClauses(clauses) {
  if (clauses.some((clause) => clause.result === false)) return STATUS.FAILED;
  if (clauses.length > 0 && clauses.every((clause) => clause.result === true)) {
    return STATUS.PASSED;
  }
  return STATUS.UNASSESSED;
}

function describeClauses(clauses) {
  return clauses.map(({ label, result, detail }) => {
    const disposition = result === true ? 'met' : result === false ? 'not met' : 'unassessed';
    return `${label}: ${disposition}${detail ? ` (${detail})` : ''}`;
  }).join('; ');
}

function sameAppointments(actual, expected) {
  if (!Array.isArray(actual)) return null;
  if (!actual.every((entry) => entry && typeof entry.id === 'string' && typeof entry.time === 'string')) {
    return null;
  }

  const canonical = (entries) => entries
    .map(({ id, time }) => `${id}\u0000${time}`)
    .sort();
  const left = canonical(actual);
  const right = canonical(expected);
  return left.length === right.length && left.every((value, index) => value === right[index]);
}

function describeAppointments(entries) {
  if (!Array.isArray(entries)) return 'no captured list';
  if (entries.length === 0) return 'no appointments';
  return entries.map((entry) => entry && typeof entry === 'object'
    ? `${String(entry.id)} at ${String(entry.time)}`
    : 'a malformed entry').join(', ');
}

function parseIntegerToken(token) {
  const compact = token.replace(/[\u00a0\u202f ]/g, '');
  if (/^\d+$/.test(compact)) return Number(compact);
  if (/^\d{1,3}(?:[,.]\d{3})+$/.test(compact)) {
    return Number(compact.replace(/[,.]/g, ''));
  }
  return null;
}

function summaryCount(summary) {
  if (typeof summary !== 'string' || summary.trim() === '') return null;
  const text = summary.toLowerCase().replace(/\s+/g, ' ').trim();
  const candidates = [];
  const digit = String.raw`\d+(?:[,.\u00a0\u202f ]\d+)*`;
  const word = Object.keys(NUMBER_WORDS).join('|');
  const patterns = [
    new RegExp(String.raw`\b(${digit})\s+(?:available\s+)?(?:appointments?|slots?)\b`, 'g'),
    new RegExp(String.raw`\b(?:appointments?|slots?)(?:\s+available)?\s*[:=-]?\s*(${digit})\b`, 'g'),
  ];

  for (const pattern of patterns) {
    for (const match of text.matchAll(pattern)) {
      const count = parseIntegerToken(match[1]);
      if (count !== null) candidates.push(count);
    }
  }

  const wordPatterns = [
    new RegExp(String.raw`\b(${word})\s+(?:available\s+)?(?:appointments?|slots?)\b`, 'g'),
    new RegExp(String.raw`\b(?:appointments?|slots?)(?:\s+available)?\s*[:=-]?\s*(${word})\b`, 'g'),
  ];
  for (const pattern of wordPatterns) {
    for (const match of text.matchAll(pattern)) candidates.push(NUMBER_WORDS[match[1]]);
  }

  if (/\b(?:no availability|nothing available|fully booked)\b/.test(text)) candidates.push(0);
  if (candidates.length === 0) return null;
  return candidates.every((count) => count === candidates[0]) ? candidates[0] : Number.NaN;
}

function evaluateAvailability(capture) {
  const appointments = capture?.appointments;
  const expected = FIXTURES[capture?.date];
  const fixtureResult = expected === undefined ? null : sameAppointments(appointments, expected);
  const fixtureDetail = expected === undefined
    ? `no authoritative fixture for ${String(capture?.date ?? 'the captured date')}`
    : fixtureResult === null
      ? 'appointment records are missing or malformed'
      : `expected ${describeAppointments(expected)}; observed ${describeAppointments(appointments)}`;

  const parsedSummary = summaryCount(capture?.summary);
  let summaryResult = null;
  let summaryDetail = 'summary count could not be interpreted';
  if (Array.isArray(appointments) && Number.isNaN(parsedSummary)) {
    summaryResult = false;
    summaryDetail = 'summary contains contradictory appointment counts';
  } else if (Array.isArray(appointments) && parsedSummary !== null) {
    summaryResult = parsedSummary === appointments.length;
    summaryDetail = `summary says ${parsedSummary}; rendered list contains ${appointments.length}`;
  } else if (!Array.isArray(appointments)) {
    summaryDetail = 'rendered appointment list is unavailable';
  }

  const clauses = [
    { label: 'dated appointment list', result: fixtureResult, detail: fixtureDetail },
    { label: 'summary/list agreement', result: summaryResult, detail: summaryDetail },
  ];
  return { status: combineClauses(clauses), reason: describeClauses(clauses) };
}

function evaluateLegal(capture) {
  const result = typeof capture?.legalText === 'string'
    ? capture.legalText === 'This service does not provide medical advice.'
    : null;
  const clauses = [{
    label: 'approved legal copy',
    result,
    detail: result === null ? 'rendered legal text is unavailable' : 'exact text and punctuation compared',
  }];
  return { status: combineClauses(clauses), reason: describeClauses(clauses) };
}

function authMessageMeaning(message) {
  if (typeof message !== 'string' || message.trim() === '') return null;
  const text = message.toLowerCase()
    .replace(/[’]/g, "'")
    .replace(/\b(sign|log)-in\b/g, '$1 in')
    .replace(/\s+/g, ' ')
    .trim();
  const contradiction = [
    /\b(?:do not|don't|does not|doesn't)\s+(?:need|have)\s+to\s+(?:sign|log)\s*in\b/,
    /\bno\s+need\s+to\s+(?:sign|log)\s*in\b/,
    /\b(?:sign|log)\s*in\s+(?:is\s+)?(?:not required|optional)\b/,
    /\bnot required\s+to\s+(?:sign|log)\s*in\b/,
    /\bwithout\s+(?:signing|logging)\s*in\b/,
    /\bguests?\s+(?:can|may|are allowed to)\s+book\b/,
    /\b(?:can|may)\s+book\s+as\s+(?:a\s+)?guest\b/,
  ].some((pattern) => pattern.test(text));
  if (contradiction) return false;

  const conveysRequirement = [
    /\b(?:must|need(?:ed)?|have)\s+to\s+(?:sign|log)\s*in\b/,
    /\b(?:sign|log)\s*in\s+(?:is\s+)?(?:required|needed)\b/,
    /\b(?:please\s+)?(?:sign|log)\s*in\s+(?:to|before|in order to)\b/,
    /\b(?:authentication|an authenticated (?:account|session))\s+(?:is\s+)?(?:required|needed)\b/,
    /\b(?:an?\s+)?account\s+(?:is\s+)?(?:required|needed)\s+(?:to|for)\b/,
    /\bneed\s+(?:an?\s+)?account\s+(?:to|for)\b/,
    /\b(?:create|use)\s+(?:an?\s+)?account\s+(?:to|before)\b/,
  ].some((pattern) => pattern.test(text));
  return conveysRequirement ? true : null;
}

function evaluateGuest(capture) {
  const guest = capture?.guest;
  const codeResult = guest && Object.prototype.hasOwnProperty.call(guest, 'code')
    ? guest.code === 'AUTH_REQUIRED'
    : null;
  const creationResult = guest && typeof guest.bookingCreated === 'boolean'
    ? guest.bookingCreated === false
    : null;
  const messageResult = authMessageMeaning(guest?.message);
  const clauses = [
    { label: 'API denial code', result: codeResult, detail: codeResult === null ? 'code is unavailable' : 'compared exactly with AUTH_REQUIRED' },
    { label: 'booking side effect', result: creationResult, detail: creationResult === null ? 'bookingCreated evidence is unavailable' : `bookingCreated is ${guest.bookingCreated}` },
    { label: 'sign-in explanation', result: messageResult, detail: messageResult === null ? 'wording needs semantic review' : messageResult ? 'wording conveys that sign-in is required' : 'wording contradicts the sign-in requirement' },
  ];
  return { status: combineClauses(clauses), reason: describeClauses(clauses) };
}

const MONEY_NUMBER = String.raw`(?:\d{1,3}(?:[.'’\u00a0\u202f ]\d{3})+(?:[.,]\d+)?|\d+(?:[.,]\d+)?)`;

function parseLocalizedAmount(token) {
  let value = token.replace(/[\u00a0\u202f '’]/g, '');
  const dot = value.lastIndexOf('.');
  const comma = value.lastIndexOf(',');
  if (dot >= 0 && comma >= 0) {
    const decimal = dot > comma ? '.' : ',';
    const grouping = decimal === '.' ? /,/g : /\./g;
    value = value.replace(grouping, '').replace(decimal, '.');
  } else {
    const separator = dot >= 0 ? '.' : comma >= 0 ? ',' : null;
    if (separator) {
      const pieces = value.split(separator);
      if (pieces.length > 2 && pieces.slice(1).every((piece) => piece.length === 3)) {
        value = pieces.join('');
      } else if (pieces.length === 2 && pieces[1].length === 3) {
        value = pieces.join('');
      } else if (pieces.length === 2 && pieces[1].length >= 1 && pieces[1].length <= 2) {
        value = `${pieces[0]}.${pieces[1]}`;
      } else {
        return null;
      }
    }
  }
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function displayedFeeMatches(display) {
  if (typeof display !== 'string' || display.trim() === '') return null;
  if (!/(?:£|\bGBP\b)/i.test(display)) return false;

  const amounts = [];
  const patterns = [
    new RegExp(String.raw`(?:£|\bGBP\b)\s*(${MONEY_NUMBER})`, 'gi'),
    new RegExp(String.raw`(${MONEY_NUMBER})\s*(?:£|\bGBP\b)`, 'gi'),
  ];
  for (const pattern of patterns) {
    for (const match of display.matchAll(pattern)) {
      const amount = parseLocalizedAmount(match[1]);
      if (amount !== null) amounts.push(amount);
    }
  }
  if (amounts.length === 0) return null;
  return amounts.every((amount) => amount === 25);
}

function evaluateFee(capture) {
  const fee = capture?.fee;
  const minorUnitsResult = fee && Object.prototype.hasOwnProperty.call(fee, 'minorUnits')
    ? fee.minorUnits === 2500
    : null;
  const currencyResult = fee && Object.prototype.hasOwnProperty.call(fee, 'currency')
    ? fee.currency === 'GBP'
    : null;
  const displayResult = displayedFeeMatches(fee?.display);
  const clauses = [
    { label: 'stored minor units', result: minorUnitsResult, detail: minorUnitsResult === null ? 'minorUnits evidence is unavailable' : `observed ${String(fee.minorUnits)}` },
    { label: 'stored currency', result: currencyResult, detail: currencyResult === null ? 'currency evidence is unavailable' : `observed ${String(fee.currency)}` },
    { label: 'displayed fee', result: displayResult, detail: displayResult === null ? 'display cannot be interpreted without review' : displayResult ? 'display conveys GBP 25.00 in an accepted locale form' : 'display does not agree with GBP 25.00' },
  ];
  return { status: combineClauses(clauses), reason: describeClauses(clauses) };
}

export function evaluate(capture) {
  const input = capture && typeof capture === 'object' ? capture : {};
  const availability = evaluateAvailability(input);
  const legal = evaluateLegal(input);
  const guest = evaluateGuest(input);
  const fee = evaluateFee(input);

  return {
    availability: availability.status,
    legal: legal.status,
    guest: guest.status,
    fee: fee.status,
    reasons: {
      availability: availability.reason,
      legal: legal.reason,
      guest: guest.reason,
      fee: fee.reason,
    },
  };
}
