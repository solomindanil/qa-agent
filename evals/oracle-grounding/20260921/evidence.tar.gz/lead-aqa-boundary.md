# Lead AQA boundary review

Date: 2026-09-21. Read-only review of Console base `c421160a71c0679a357f29828029ec3550791d16`, its two identical reference-file additions, and the supplied offline task/probe/control-1..5/guided-1..3 artifacts. No product, network, Git mutation, source adoption, or additional actor execution. This report is the only write. Writing-skills criteria informed the distinction between demonstrated behavior change and unproven wording.

## Decision

**The proposed boundary clarification is justified as a narrow existing-skill correction; the current candidate is not demonstrated successful.** Select deterministic versus agent-led interpretation before synthesizing an oracle. Existing `qa-product-v0/SKILL.md:32-40,54-56` already supports separate lanes and incomplete coverage; `references/agent-observations.md:3,7,25-27` already supports bounded agent interpretation without a new runner or receipt promotion. Making that choice explicit in the existing assertion paragraph needs no framework, schema, runtime change, new permission, or automatic human escalation.

The evidence supports correcting semantic assertion boundaries, not claiming a causal repair of the original catalog literal-count failure: none of these five controls reproduced that failure.

## Actionable findings

### 1. High: current candidate still makes unsound semantic claims

The retained results show control-1/2/3/5 and guided-1/2/3 passing `No sign-in is necessary`. Control-4 falsely fails `Log in before booking`. Guided-3 abstains on that valid paraphrase; this is different from control-4's false failure.

The source explains the false passes: guided-1:150-170, guided-2:156-173, and guided-3:139-153 enumerate some negative phrases, then match an unanchored positive authentication/necessity pattern. None establishes the whole sentence's meaning. A few counterexamples do not validate that parser outside the examples. The current paragraph at `product-analysis.md:34` still starts with designing a “reusable textual oracle” and routes to the agent lane only after the author decides the tool cannot assess it. Authors plainly overestimate that capability. Move the lane decision before parser construction; do not append one more negation exception.

### 2. High: executable-only scoring penalizes legitimate abstention

`task.md:20,33` permits `unassessed`, asks for clause separation, limits and next actions. Nevertheless `probe.mjs:22,29,35,36` demands definitive semantic verdicts for natural-language cases; `allPassed` also demands semantic completion in unrelated strict-control rows. A sound module that retains exact API/state checks and leaves message interpretation to an agent is therefore marked mismatched repeatedly. Control-5's two availability abstentions and guided-3's paraphrase abstention concretely expose this conflation.

Requiring a dependency-free reusable executable module, with no structured summary input and varied wording (`task.md:20-33`), creates pressure to invent a language parser. That is a task-design bias, not evidence that agents are prohibited from abstaining. It also is not proof that the same failure occurs in normal agent-led product QA. The current three contradictory-message passes remain real false passes under any honest abstention-aware rubric.

Small correction: preserve all current raw results, version the rubric, and separately record **wrong definitive verdicts**, **honest unresolved clauses**, and **semantic coverage achieved**. Permit `unassessed` on a semantic clause only with retained deterministic subresults, a concrete limitation and next action. Do not simply turn every mismatch into an allowed result or count abstention as assessed PASS. Apply any corrected rubric equally to preserved control and candidate outputs before drawing comparisons.

### 3. High: unknown semantics must not hide a known deterministic failure

“Keep the whole status unassessed until agent interpretation” needs a precise boundary. For a compound conjunction: a supported violation is `failed`; otherwise any unresolved required clause prevents `passed`; all required clauses need evidence for `passed`. For example `bookingCreated: true` must still fail the guest check even if its message remains unassessed. Preserve exact legal copy, denial code, inventory membership/time, stored amount/currency and supported displayed-value checks. The probe's strict mutations must continue requiring `failed` for their affected checks. Do not promote an entire fee check from stored fields while leaving display unassessed.

### 4. Medium: agent-first does not mean permanent deferral of readable evidence

On an actual authorized capture, an agent can interpret the message in context, cite the observed text and requirement, and record a bounded assessment through the existing lane or report fallback. An executable module cannot itself invent that interpretation. In this offline exercise, semantic review of supplied fixture evidence is an offline assessment, not deployed acceptance. If the writing agent has not received future probe captures, it should name the pending review rather than claim it performed one. Human help is only for a concrete capability or authority gap, not for the existence of natural-language copy.

### 5. Medium: retain useful deterministic parsing, but distinguish its scope

Do not ban all regex or require agent interpretation for every textual field. Exact legal strings, identifiers and explicitly bounded numeric/currency representations can support deterministic checks. Regex can extract candidates without proving free-form meaning. A parser's declared coverage must be narrower than arbitrary prose, with unsupported forms unresolved rather than automatically defective. Unknown wording alone is neither a product failure nor proof of success. The task supplies no authoritative grammar for the guest explanation.

## Smallest next move

1. Finish/preserve the already-running first-candidate samples without feedback or patching their outputs. Keep this first candidate unsuccessful on the observed false-pass evidence.
2. Freeze the minimal soundness-versus-coverage scoring clarification above, document it as an evaluator correction, and reclassify existing artifacts without replacing the original results.
3. Replace only the two matching paragraph additions with a short source-conditioned lane rule. Suggested substance: **Use deterministic checks for source-defined exact values and supported observable state. When judging unrestricted wording requires interpreting meaning, assess the captured evidence in the existing agent-led lane; do not manufacture semantic authority from keyword/negation patterns. Keep deterministic clause results, retain unresolved interpretation explicitly, and do not pass a compound check until every required clause is assessed. A proven violation still fails it.** Preserve exact-copy and locale-format qualifications already present.
4. Re-run the bounded fresh-context wording comparison after the rubric is frozen. The writing-skills sampling criterion is at least five samples per variant; three partial samples cannot establish candidate success. Manually inspect every apparent mismatch and every claimed semantic PASS. A brief agent-led interpretation of a held-out valid/contradictory pair should accompany module soundness checks so the remedy is not rewarded merely for avoiding all semantic work. This can remain an offline pressure scenario, not a new framework or product run.

No root manifest/source adoption is justified yet. Source parity and structural tests can verify a clean edit, but not its behavioral effect. This review makes no reliability percentage or cross-domain qualification claim.
