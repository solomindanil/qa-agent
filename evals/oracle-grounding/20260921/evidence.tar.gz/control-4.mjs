const STATUS = Object.freeze({
  PASSED: 'passed',
  FAILED: 'failed',
  UNASSESSED: 'unassessed',
});

const LEGAL_COPY = 'This service does not provide medical advice.';

const AVAILABILITY_FIXTURES = Object.freeze({
  '2026-10-01': Object.freeze([]),
  '2026-10-02': Object.freeze([
    Object.freeze({ id: 'slot-a', time: '09:00' }),
  ]),
});

function aggregate(clauses) {
  const outcomes = Object.values(clauses).map((clause) => clause.status);
  if (outcomes.includes(STATUS.FAILED)) return STATUS.FAILED;
  if (outcomes.includes(STATUS.UNASSESSED)) return STATUS.UNASSESSED;
  return STATUS.PASSED;
}

function safeCapture(capture) {
  return capture !== null && typeof capture === 'object' && !Array.isArray(capture)
    ? capture
    : {};
}

function parseUnsignedInteger(token) {
  const compact = token.replace(/[\s,\u00a0\u202f]/g, '');
  if (!/^\d+$/.test(compact)) return null;
  const value = Number(compact);
  return Number.isSafeInteger(value) ? value : null;
}

function appointmentCountFromSummary(summary) {
  const counts = new Set();
  if (/\bno\s+appointments?\b/i.test(summary)) counts.add(0);

  const patterns = [
    /(\d[\d,\s\u00a0\u202f]*)\s+appointments?\b/gi,
    /\bappointments?\s*(?:available\s*)?(?:[:(=\-]\s*)?(\d[\d,\s\u00a0\u202f]*)/gi,
  ];

  for (const pattern of patterns) {
    for (const match of summary.matchAll(pattern)) {
      const value = parseUnsignedInteger(match[1]);
      if (value !== null) counts.add(value);
    }
  }

  return counts.size === 1 ? [...counts][0] : null;
}

function canonicalAppointments(appointments) {
  if (!Array.isArray(appointments)) return null;
  const canonical = [];
  for (const appointment of appointments) {
    if (
      appointment === null
      || typeof appointment !== 'object'
      || Array.isArray(appointment)
      || typeof appointment.id !== 'string'
      || typeof appointment.time !== 'string'
    ) {
      return null;
    }
    canonical.push(`${appointment.id}\u0000${appointment.time}`);
  }
  return canonical.sort();
}

function evaluateAvailability(capture) {
  let fixture;
  if (typeof capture.date !== 'string') {
    fixture = {
      status: STATUS.UNASSESSED,
      explanation: 'No date observation was supplied, so no dated fixture can be selected.',
    };
  } else if (!Object.prototype.hasOwnProperty.call(AVAILABILITY_FIXTURES, capture.date)) {
    fixture = {
      status: STATUS.UNASSESSED,
      explanation: `No authoritative slot fixture is supplied for ${capture.date}; list correctness cannot be inferred from its count.`,
    };
  } else if (!Array.isArray(capture.appointments)) {
    fixture = {
      status: STATUS.UNASSESSED,
      explanation: `The ${capture.date} appointments observation is unavailable.`,
    };
  } else {
    const actual = canonicalAppointments(capture.appointments);
    const expected = canonicalAppointments(AVAILABILITY_FIXTURES[capture.date]);
    const matches = actual !== null
      && actual.length === expected.length
      && actual.every((entry, index) => entry === expected[index]);
    fixture = {
      status: matches ? STATUS.PASSED : STATUS.FAILED,
      explanation: matches
        ? `The rendered list exactly matches the supplied ${capture.date} fixture.`
        : `The rendered list does not exactly match the supplied ${capture.date} fixture.`,
    };
  }

  let summary;
  if (!Array.isArray(capture.appointments) || typeof capture.summary !== 'string') {
    summary = {
      status: STATUS.UNASSESSED,
      explanation: 'Both an appointments array and rendered summary text are required to compare their counts.',
    };
  } else if (capture.summary.length === 0) {
    summary = {
      status: STATUS.FAILED,
      explanation: 'The rendered summary text is empty.',
    };
  } else {
    const statedCount = appointmentCountFromSummary(capture.summary);
    if (statedCount === null) {
      summary = {
        status: STATUS.UNASSESSED,
        explanation: 'The rendered summary does not contain one unambiguous supported English appointment count.',
      };
    } else {
      const matches = statedCount === capture.appointments.length;
      summary = {
        status: matches ? STATUS.PASSED : STATUS.FAILED,
        explanation: matches
          ? `The summary count ${statedCount} agrees with the ${capture.appointments.length} rendered appointments.`
          : `The summary count ${statedCount} disagrees with the ${capture.appointments.length} rendered appointments.`,
      };
    }
  }

  const clauses = { fixture, summary };
  return {
    status: aggregate(clauses),
    source: 'Accepted product brief and supplied read-only fixtures for 2026-10-01 and 2026-10-02.',
    clauses,
  };
}

function evaluateLegal(capture) {
  if (typeof capture.legalText !== 'string') {
    return {
      status: STATUS.UNASSESSED,
      source: 'Accepted product brief: approved legal copy, including punctuation.',
      explanation: 'Rendered legal text was not supplied.',
    };
  }

  const matches = capture.legalText === LEGAL_COPY;
  return {
    status: matches ? STATUS.PASSED : STATUS.FAILED,
    source: 'Accepted product brief: approved legal copy, including punctuation.',
    explanation: matches
      ? 'The rendered legal text is an exact character-for-character match.'
      : 'The rendered legal text is not an exact character-for-character match.',
  };
}

function guestMessageClause(message) {
  if (typeof message !== 'string') {
    return {
      status: STATUS.UNASSESSED,
      explanation: 'No user-facing guest denial message was supplied.',
    };
  }
  if (message.trim().length === 0) {
    return {
      status: STATUS.FAILED,
      explanation: 'The user-facing guest denial message is empty.',
    };
  }

  const contradictsSignIn = /\b(?:without|need(?:s)?\s+not\s+to|do(?:es)?\s+not\s+need\s+to|no\s+need\s+to)\s+(?:sign|log)[\s-]?in\b/i.test(message);
  const conveysSignIn = [
    /\b(?:must|need(?:s|ed)?\s+to|required\s+to|please)\s+(?:sign|log)[\s-]?in\b/i,
    /\b(?:sign|log)[\s-]?in\s+(?:is\s+)?required\b/i,
    /\b(?:sign|log)[\s-]?in\s+to\s+(?:book|continue|proceed|make\s+(?:an\s+)?appointment)\b/i,
    /\bauthentication\s+(?:is\s+)?required\b/i,
    /\bmust\s+be\s+authenticated\b/i,
    /\bauthenticate\s+to\s+(?:book|continue|proceed)\b/i,
    /\b(?:an\s+)?account\s+(?:is\s+)?required\s+to\s+book\b/i,
    /\bneed(?:s)?\s+(?:an\s+)?account\s+to\s+book\b/i,
  ].some((pattern) => pattern.test(message));

  const matches = conveysSignIn && !contradictsSignIn;
  return {
    status: matches ? STATUS.PASSED : STATUS.FAILED,
    explanation: matches
      ? 'The English message conveys that authentication or sign-in is needed to book.'
      : 'The English message does not unambiguously convey that authentication or sign-in is needed to book.',
  };
}

function evaluateGuest(capture) {
  const guest = capture.guest !== null
    && typeof capture.guest === 'object'
    && !Array.isArray(capture.guest)
    ? capture.guest
    : {};

  const code = typeof guest.code !== 'string'
    ? {
        status: STATUS.UNASSESSED,
        explanation: 'No guest API denial code was supplied.',
      }
    : {
        status: guest.code === 'AUTH_REQUIRED' ? STATUS.PASSED : STATUS.FAILED,
        explanation: guest.code === 'AUTH_REQUIRED'
          ? 'The guest API denial code is exactly AUTH_REQUIRED.'
          : 'The guest API denial code is not exactly AUTH_REQUIRED.',
      };

  const noBooking = typeof guest.bookingCreated !== 'boolean'
    ? {
        status: STATUS.UNASSESSED,
        explanation: 'No boolean booking-created observation was supplied.',
      }
    : {
        status: guest.bookingCreated === false ? STATUS.PASSED : STATUS.FAILED,
        explanation: guest.bookingCreated === false
          ? 'The observation says no booking was created.'
          : 'The observation says a booking was created for the guest denial attempt.',
      };

  const message = guestMessageClause(guest.message);
  const clauses = { code, noBooking, message };
  return {
    status: aggregate(clauses),
    source: 'Accepted product brief: guests cannot book; exact API code AUTH_REQUIRED; no booking created; explanation conveys sign-in is needed.',
    clauses,
  };
}

function parseDisplayNumber(token) {
  let compact = token.replace(/[\s\u00a0\u202f'’]/g, '');
  if (!/^[+-]?\d[\d.,]*$/.test(compact)) return null;

  const comma = compact.lastIndexOf(',');
  const dot = compact.lastIndexOf('.');
  if (comma !== -1 && dot !== -1) {
    const decimalIndex = Math.max(comma, dot);
    const integer = compact.slice(0, decimalIndex).replace(/[.,]/g, '');
    const fraction = compact.slice(decimalIndex + 1);
    compact = `${integer}.${fraction}`;
  } else {
    const separator = comma !== -1 ? ',' : dot !== -1 ? '.' : null;
    if (separator !== null) {
      const pieces = compact.split(separator);
      const final = pieces.at(-1);
      compact = final.length >= 1 && final.length <= 2
        ? `${pieces.slice(0, -1).join('')}.${final}`
        : pieces.join('');
    }
  }

  const value = Number(compact);
  return Number.isFinite(value) ? value : null;
}

function evaluateFee(capture) {
  const fee = capture.fee !== null
    && typeof capture.fee === 'object'
    && !Array.isArray(capture.fee)
    ? capture.fee
    : {};

  const minorUnits = typeof fee.minorUnits !== 'number' || !Number.isFinite(fee.minorUnits)
    ? {
        status: STATUS.UNASSESSED,
        explanation: 'No finite numeric minor-unit value was supplied.',
      }
    : {
        status: fee.minorUnits === 2500 ? STATUS.PASSED : STATUS.FAILED,
        explanation: fee.minorUnits === 2500
          ? 'The stored fee is exactly 2500 minor units.'
          : 'The stored fee is not exactly 2500 minor units.',
      };

  const currency = typeof fee.currency !== 'string'
    ? {
        status: STATUS.UNASSESSED,
        explanation: 'No stored currency code was supplied.',
      }
    : {
        status: fee.currency === 'GBP' ? STATUS.PASSED : STATUS.FAILED,
        explanation: fee.currency === 'GBP'
          ? 'The stored currency code is exactly GBP.'
          : 'The stored currency code is not exactly GBP.',
      };

  let displayCurrency;
  let displayAmount;
  if (typeof fee.display !== 'string') {
    displayCurrency = {
      status: STATUS.UNASSESSED,
      explanation: 'No rendered fee display was supplied.',
    };
    displayAmount = {
      status: STATUS.UNASSESSED,
      explanation: 'No rendered fee display was supplied.',
    };
  } else if (fee.display.trim().length === 0) {
    displayCurrency = {
      status: STATUS.FAILED,
      explanation: 'The rendered fee display is empty and does not show GBP.',
    };
    displayAmount = {
      status: STATUS.FAILED,
      explanation: 'The rendered fee display is empty and does not show 25.00 GBP.',
    };
  } else {
    const showsGbp = /(?:\bGBP\b|£|\bBritish\s+pounds?\b|\bpounds?\s+sterling\b)/i.test(fee.display);
    displayCurrency = {
      status: showsGbp ? STATUS.PASSED : STATUS.FAILED,
      explanation: showsGbp
        ? 'The rendered fee identifies GBP using a supported code, symbol, or English currency name.'
        : 'The rendered fee does not identify GBP using a supported code, symbol, or English currency name.',
    };

    const numberTokens = fee.display.match(/[+-]?\d(?:[\d\s\u00a0\u202f,.'’]*\d)?/g) ?? [];
    const numbers = numberTokens
      .map(parseDisplayNumber)
      .filter((value) => value !== null);
    if (numbers.length === 0) {
      displayAmount = {
        status: STATUS.UNASSESSED,
        explanation: 'The rendered fee has no numeric amount in a supported locale form.',
      };
    } else {
      const showsExpectedAmount = numbers.some((value) => value === 25);
      displayAmount = {
        status: showsExpectedAmount ? STATUS.PASSED : STATUS.FAILED,
        explanation: showsExpectedAmount
          ? 'The rendered fee includes 25 in a supported locale form, agreeing with 2500 minor units.'
          : 'The rendered numeric fee does not agree with 2500 minor units (GBP 25.00).',
      };
    }
  }

  const clauses = { minorUnits, currency, displayCurrency, displayAmount };
  return {
    status: aggregate(clauses),
    source: 'Accepted product brief: GBP 25.00, stored as 2500 minor units; locale formatting is not prescribed.',
    clauses,
  };
}

export function evaluate(input) {
  const capture = safeCapture(input);
  const availabilityReason = evaluateAvailability(capture);
  const legalReason = evaluateLegal(capture);
  const guestReason = evaluateGuest(capture);
  const feeReason = evaluateFee(capture);

  return {
    availability: availabilityReason.status,
    legal: legalReason.status,
    guest: guestReason.status,
    fee: feeReason.status,
    reasons: {
      availability: availabilityReason,
      legal: legalReason,
      guest: guestReason,
      fee: feeReason,
    },
  };
}
