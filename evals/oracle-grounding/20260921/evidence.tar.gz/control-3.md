# Appointment-preview oracle report

## Result

`control-3.mjs` is a dependency-free test-design module. It evaluates one fresh rendered/API capture and returns clause-level reasons plus the required `passed`, `failed`, or `unassessed` outcome for availability, legal copy, guest denial, and fee. It performs no browsing, account creation, booking, product write, or network access. Writing this module is not a product run and does not establish release or product acceptance.

Aggregation is conservative: any supported contradiction makes the relevant oracle `failed`; otherwise every clause must be assessable and pass for that oracle to be `passed`. A missing or ambiguous clause therefore remains `unassessed` without preventing independent clauses from being evaluated.

## Requirement sources

| Oracle | Requirement and source used |
| --- | --- |
| Availability | The accepted product brief requires the selected date's appointments and a visible summary whose number agrees, including zero. The supplied read-only fixtures establish `2026-10-01` as empty and `2026-10-02` as exactly `slot-a` at `09:00`. The module compares fixture entries as an unordered id/time set and independently compares the interpreted summary count with the captured array length. |
| Legal | The accepted product brief supplies the approved exact copy: `This service does not provide medical advice.` Punctuation, capitalization, and whitespace are checked exactly. |
| Guest | The accepted product brief requires exact API code `AUTH_REQUIRED`, `bookingCreated === false`, and a user-facing explanation conveying that sign-in is needed. These are separate clauses. |
| Fee | The accepted product brief requires stored value `2500`, currency `GBP`, and a display whose amount and currency agree. The display parser accepts `GBP` or `£`, whole pounds, one/two decimal digits, and common dot/comma/space/apostrophe grouping variants; it does not require one locale format. |

The continuation note is not treated as a requirement or execution record because no source or run evidence accompanies it. Its October 1 and 2 examples happen to agree with the accepted brief and fixture data, which are the actual oracle sources. The supplied October 3 render is retained as an observation only: it supports designing the generic summary-count comparison, but it is not promoted into an approved date-specific inventory fixture.

## Limits and next actions

- Only October 1 and 2 have authoritative date-specific fixtures. For any other date, summary agreement can still be assessed, but availability remains `unassessed` because exact date membership cannot be proved. Next action: supply or bind an approved fixture for that date, then add it deliberately.
- The input contract says the values are fresh rendered/API observations; the module cannot prove capture time, deployment identity, selected UI state, DOM visibility, or API provenance. Next action: collect an authorized fresh capture with those facts in the accepted evidence lane, then evaluate it and retain the capture with the result.
- The English summary parser supports unambiguous Arabic numerals with common grouping separators and English zero-through-twelve words adjacent to “appointment(s)”. Unusual prose or ambiguous counts remain `unassessed`. Next action: inspect the rendered summary and either provide a scoped numeric observation or extend the parser from an approved example.
- Guest-message interpretation is intentionally bounded. Direct sign-in/log-in/authentication-required wording passes, direct absence or irrelevant wording fails, and ambiguous authentication wording is `unassessed`. Next action: review ambiguous copy against the brief or provide an approved phrase set; do not weaken the exact API/no-booking clauses.
- Fee display assessment requires a single interpretable numeric amount and an explicit `GBP` or `£` marker. Multiple amounts, word-only prices, or unsupported formatting remain `unassessed`. Next action: capture the isolated price element or provide an approved formatting example. A conflicting amount or currency is `failed`.
- No accessibility, responsive layout, interaction mechanics, authorization persistence, concurrency, performance, security probing, or whole-product coverage is claimed. Those areas need separate requirements, capabilities, and evidence.
