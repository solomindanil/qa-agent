# Appointment-preview oracle report

This is an offline test-design artifact. Writing it does not execute a product check or establish product/release acceptance. Each top-level result is `passed`, `failed`, or `unassessed`; a definite failed clause dominates an unavailable clause, while a fully passing result requires every clause in that oracle to be assessable and pass.

## Availability

- **Requirement source:** the accepted product brief requires the selected date's exact available appointments and a visible summary whose count agrees, including zero. The accepted read-only fixtures establish `2026-10-01` as empty and `2026-10-02` as exactly `slot-a` at `09:00`.
- **Oracle:** fixture inventory is compared as an order-independent exact list. The English summary is checked semantically for one unambiguous count adjacent to “appointment(s),” accepting digits with common grouping and common English number words. Literal `0 appointments` / `1 appointment` wording is not required because the prior continuation note has no additional source and the accepted brief does not prescribe summary copy.
- **Limits:** no accepted exact inventory was supplied for `2026-10-03`; its current two-item render is an observation, not a normative fixture. For that date the count-agreement clause can fail independently, but matching two items remains `unassessed` overall. The module trusts `summary` to be a fresh rendered-text observation and cannot independently prove CSS visibility. Ambiguous or unsupported wording is `unassessed`, not silently passed.
- **Next action when unavailable:** supply an accepted fixture for the selected date and/or a fresh visible-summary observation with an unambiguous count. Review unfamiliar valid phrasing before extending the parser.

## Legal

- **Requirement source:** the accepted brief's approved legal copy, including punctuation.
- **Oracle:** exact string equality with `This service does not provide medical advice.`; no trimming or punctuation normalization.
- **Limits:** the field proves only the captured text. The module cannot independently prove that the banner was visible.
- **Next action when unavailable:** capture the actual visible banner text (and visibility evidence if that property is in question).

## Guest denial

- **Requirement source:** the accepted brief requires exact API code `AUTH_REQUIRED`, no booking creation, and a user-facing explanation that conveys sign-in is needed without prescribing exact copy.
- **Oracle:** the code and boolean creation result are checked separately. The English message oracle accepts common imperative, required/needed, and “cannot book without…” forms; explicit optional/no-need language fails. A contradictory code or created booking fails even if message interpretation is unavailable.
- **Limits:** the semantic parser is deliberately conservative and does not turn an unfamiliar authentication phrase into a pass. This artifact does not attempt a booking and does not prove persistence beyond the supplied `bookingCreated` observation.
- **Next action when unavailable:** obtain the API denial observation, a read-only booking non-creation observation, and the rendered message; manually review any unfamiliar but potentially valid phrasing.

## Fee

- **Requirement source:** the accepted brief fixes the stored fee at 2500 minor units, currency `GBP`, and requires the rendered amount/currency to agree; locale formatting is not prescribed.
- **Oracle:** stored amount and currency are exact checks. Display accepts `GBP`, `£`, or explicit sterling wording, before or after a numeric 25 with either decimal separator and optional decimals. Recognized foreign codes/symbols or a recognized non-25 amount fail.
- **Limits:** multiple numeric values or a non-numeric amount spelling are `unassessed` because the compact parser cannot reliably identify the fee. The capture contract does not independently prove where the stored fields came from or that the text was visible.
- **Next action when unavailable:** provide structured rendered amount/currency metadata or a reviewed localized fee sample, then extend the parser only for that evidenced format.
